#BUISNESS PROBLEM
#Prepare rules for the all the data sets 
# 1) Try different values of support and confidence. Observe the change in number of rules for different support,confidence values
# 2) Change the minimum length in apriori algorithm
# 3) Visulize the obtained rules using different plots 
# BOOKS.CSV DATASET

#used for building association rules
install.packages("arules")
library(arules)

#for visualizing rules
install.packages("arulesViz")
library(arulesViz)

#loading dataset to variable arbooks
arbooks <- book

#viewing dataset
View(arbooks)

#applying apriori algorithm to generate association rules
#Provided the rules with 2 % Support, 50 % Confidence and Minimum to purchase 
#5 books 
rules <- apriori(as.matrix(arbooks),parameter=list(support=0.02, confidence = 0.5,minlen=5))
# Apriori
# 
# Parameter specification:
#   confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target   ext
# 0.5    0.1    1 none FALSE            TRUE       5    0.02      5     10  rules FALSE
# 
# Algorithmic control:
#   filter tree heap memopt load sort verbose
# 0.1 TRUE TRUE  FALSE TRUE    2    TRUE
# 
# Absolute minimum support count: 40 
# 
# set item appearances ...[0 item(s)] done [0.00s].
# set transactions ...[11 item(s), 2000 transaction(s)] done [0.00s].
# sorting and recoding items ... [11 item(s)] done [0.00s].
# creating transaction tree ... done [0.00s].
# checking subsets of size 1 2 3 4 5 6 done [0.00s].
# writing ... [186 rule(s)] done [0.00s].
# creating S4 object  ... done [0.00s].

#view the generated rules
rules
#set of 186 rules 

inspect(head(sort(rules, by = "lift")))  
#     lhs                                   rhs        support confidence lift      count
# [1] {CookBks,DoItYBks,ArtBks,ItalCook} => {ItalArt}  0.0250  0.6849315  14.122299 50   
# [2] {CookBks,ArtBks,GeogBks,ItalCook}  => {ItalArt}  0.0240  0.6666667  13.745704 48   
# [3] {ChildBks,CookBks,ArtBks,ItalCook} => {ItalArt}  0.0285  0.6263736  12.914920 57   
# [4] {CookBks,ArtBks,GeogBks,ItalArt}   => {ItalCook} 0.0240  0.9600000   8.458150 48   
# [5] {ChildBks,CookBks,ArtBks,ItalArt}  => {ItalCook} 0.0285  0.9500000   8.370044 57   
# [6] {CookBks,DoItYBks,ArtBks,ItalArt}  => {ItalCook} 0.0250  0.9259259   8.157938 50 

head(quality(rules))
#   support confidence     lift count
# 1   0.020  1.0000000 2.320186    40
# 2   0.020  0.8695652 2.055710    40
# 3   0.020  1.0000000 4.662005    40
# 4   0.020  0.8888889 7.831620    40
# 5   0.025  1.0000000 2.320186    50
# 6   0.025  0.6666667 2.364066    50

plot(rules,method = "scatterplot")


plot(rules,method = "grouped")

# The Art books are being sold at a larger extent along with other Cook, art, geo, child books
# Cook books are also being sold at a larger extent along with other chld, art, geo, Doit books)
plot(rules,method = "graph")

## Warning: plot: Too many rules supplied. Only plotting the best 100 rules
## using 'support' (change control parameter max if needed)

#applying apriori algorithm to generate association rules
#Provided the rules with 1 % Support, 70 % Confidence and Minimum to purchase 
#5 books 
rules <- apriori(as.matrix(arbooks),parameter=list(support=0.01, confidence = 0.7,minlen=5))
# Apriori
# 
# Parameter specification:
#   confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target   ext
# 0.7    0.1    1 none FALSE            TRUE       5    0.01      5     10  rules FALSE
# 
# Algorithmic control:
#   filter tree heap memopt load sort verbose
# 0.1 TRUE TRUE  FALSE TRUE    2    TRUE
# 
# Absolute minimum support count: 20 
# 
# set item appearances ...[0 item(s)] done [0.00s].
# set transactions ...[11 item(s), 2000 transaction(s)] done [0.00s].
# sorting and recoding items ... [11 item(s)] done [0.00s].
# creating transaction tree ... done [0.00s].
# checking subsets of size 1 2 3 4 5 6 7 done [0.00s].
# writing ... [469 rule(s)] done [0.00s].
# creating S4 object  ... done [0.00s].

#view the generated rules
rules
#set of 469 rules

inspect(head(sort(rules, by = "lift")))  
# lhs                                         rhs         support confidence lift     count
# [1] {RefBks,ArtBks,GeogBks,ItalArt}          => {ItalAtlas} 0.0115  0.8518519  23.02302 23   
# [2] {ChildBks,RefBks,GeogBks,ItalArt}        => {ItalAtlas} 0.0100  0.8333333  22.52252 20   
# [3] {ChildBks,RefBks,ArtBks,GeogBks,ItalArt} => {ItalAtlas} 0.0100  0.8333333  22.52252 20   
# [4] {ChildBks,RefBks,ArtBks,ItalArt}         => {ItalAtlas} 0.0145  0.8055556  21.77177 29   
# [5] {CookBks,RefBks,ArtBks,ItalArt}          => {ItalAtlas} 0.0130  0.7878788  21.29402 26   
# [6] {RefBks,ArtBks,ItalCook,ItalArt}         => {ItalAtlas} 0.0125  0.7812500  21.11486 25    

head(quality(rules))
# support confidence      lift count
# 1  0.0125  1.0000000  4.149378    25
# 2  0.0125  1.0000000  4.662005    25
# 3  0.0125  0.7575758  6.674676    25
# 4  0.0125  0.9615385 19.825535    25
# 5  0.0125  0.7812500 21.114865    25
# 6  0.0110  0.8800000  2.080378    22


plot(rules,method = "scatterplot")


plot(rules,method = "grouped")


plot(rules,method = "graph")

## Warning: plot: Too many rules supplied. Only plotting the best 100 rules
## using 'support' (change control parameter max if needed)

#applying apriori algorithm to generate association rules
#Provided the rules with 20 % Support, 70 % Confidence and Minimum to purchase 
#3 books 
rules <- apriori(as.matrix(arbooks),parameter=list(support=0.03, confidence = 0.7,minlen=3))
# #Apriori
# 
# Parameter specification:
#   confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target   ext
# 0.7    0.1    1 none FALSE            TRUE       5    0.03      3     10  rules FALSE
# 
# Algorithmic control:
#   filter tree heap memopt load sort verbose
# 0.1 TRUE TRUE  FALSE TRUE    2    TRUE
# 
# Absolute minimum support count: 60 
# 
# set item appearances ...[0 item(s)] done [0.00s].
# set transactions ...[11 item(s), 2000 transaction(s)] done [0.00s].
# sorting and recoding items ... [11 item(s)] done [0.00s].
# creating transaction tree ... done [0.00s].
# checking subsets of size 1 2 3 4 5 6 done [0.02s].
# writing ... [151 rule(s)] done [0.00s].
# creating S4 object  ... done [0.00s].

#view the generated rules
rules
#set of of 151 rules 

inspect(head(sort(rules, by = "lift"))) 
# lhs                         rhs        support confidence lift     count
# [1] {CookBks,ItalArt}        => {ItalCook} 0.0375  0.9146341  8.058451 75   
# [2] {CookBks,ArtBks,ItalArt} => {ItalCook} 0.0375  0.9146341  8.058451 75   
# [3] {ArtBks,ItalArt}         => {ItalCook} 0.0375  0.7731959  6.812298 75   
# [4] {ItalCook,ItalArt}       => {ArtBks}   0.0375  1.0000000  4.149378 75   
# [5] {DoItYBks,ItalArt}       => {ArtBks}   0.0300  1.0000000  4.149378 60   
# [6] {ChildBks,ItalArt}       => {ArtBks}   0.0360  1.0000000  4.149378 72  

head(quality(rules))
# support confidence     lift count
# 1  0.0375  1.0000000 4.149378    75
# 2  0.0375  0.7731959 6.812298    75
# 3  0.0375  1.0000000 2.320186    75
# 4  0.0375  0.9146341 8.058451    75
# 5  0.0300  1.0000000 4.149378    60
# 6  0.0360  0.7422680 1.754771    72

plot(rules,method = "scatterplot")


plot(rules,method = "grouped")


plot(rules,method = "graph")
