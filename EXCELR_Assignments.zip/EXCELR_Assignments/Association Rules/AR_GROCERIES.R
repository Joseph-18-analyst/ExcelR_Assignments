#BUISNESS PROBLEM
#Prepare rules for the all the data sets 
# 1) Try different values of support and confidence. Observe the change in number of rules for different support,confidence values
# 2) Change the minimum length in apriori algorithm
# 3) Visulize the obtained rules using different plots 
# GROCERIES.CSV DATASET

#used for building association rules
install.packages("arules")
library(arules)

#for visualizing rules, plotting the rules which was visualized
install.packages("arulesViz")
library(arulesViz)

data()

#loading inbuilt dataset groceries(given with arules package)
data("Groceries")

#The data set contains 9835 transactions and the items are aggregated to 169 categories.
?Groceries

#structure of groceries data set
str(Groceries)
# Formal class 'transactions' [package "arules"] with 3 slots
# ..@ data       :Formal class 'ngCMatrix' [package "Matrix"] with 5 slots
# .. .. ..@ i       : int [1:43367] 13 60 69 78 14 29 98 24 15 29 ...
# .. .. ..@ p       : int [1:9836] 0 4 7 8 12 16 21 22 27 28 ...
# .. .. ..@ Dim     : int [1:2] 169 9835
# .. .. ..@ Dimnames:List of 2
# .. .. .. ..$ : NULL
# .. .. .. ..$ : NULL
# .. .. ..@ factors : list()
# ..@ itemInfo   :'data.frame':	169 obs. of  3 variables:
#   .. ..$ labels: chr [1:169] "frankfurter" "sausage" "liver loaf" "ham" ...
# .. ..$ level2: Factor w/ 55 levels "baby food","bags",..: 44 44 44 44 44 44 44 42 42 41 ...
# .. ..$ level1: Factor w/ 10 levels "canned food",..: 6 6 6 6 6 6 6 6 6 6 ...
# ..@ itemsetInfo:'data.frame':	0 obs. of  0 variables


#summary of groceries
summary(Groceries)
# transactions as itemMatrix in sparse format with
# 9835 rows (elements/itemsets/transactions) and
# 169 columns (items) and a density of 0.02609146 
# 
# most frequent items:
# whole milk other vegetables       rolls/buns             soda           yogurt 
# 2513             1903             1809             1715             1372 
# (Other) 
# 34055 
# 
# element (itemset/transaction) length distribution:
#   sizes
# 1    2    3    4    5    6    7    8    9   10   11   12   13   14   15   16   17   18   19 
# 2159 1643 1299 1005  855  645  545  438  350  246  182  117   78   77   55   46   29   14   14 
# 20   21   22   23   24   26   27   28   29   32 
# 9   11    4    6    1    1    1    1    3    1 
# 
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 1.000   2.000   3.000   4.409   6.000  32.000 
# 
# includes extended item information - examples:
#   labels  level2           level1
# 1 frankfurter sausage meat and sausage
# 2 sausage sausage meat and sausage
# 3 liver loaf sausage meat and sausage


#to displaye top 5 transactions
inspect(Groceries[1:5])
# items                     
# [1] {citrus fruit,            
#   semi-finished bread,     
#   margarine,               
#   ready soups}             
# [2] {tropical fruit,          
#   yogurt,                  
#   coffee}                  
# [3] {whole milk}              
# [4] {pip fruit,               
#   yogurt,                  
#   cream cheese ,           
#   meat spreads}            
# [5] {other vegetables,        
#   whole milk,              
#   condensed milk,          
#   long life bakery product}

#groceries is in transactions format
class(Groceries)
# [1] "transactions"
# attr(,"package")
# [1] "arules"


#building rules using apriori algorithm
arules <- apriori(Groceries, parameter =list(support = 0.003, confidence = 0.7, minlen=2))
#19 rules generated
# Apriori
# 
# Parameter specification:
#   confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target   ext
# 0.7    0.1    1 none FALSE            TRUE       5   0.003      2     10  rules FALSE
# 
# Algorithmic control:
#   filter tree heap memopt load sort verbose
# 0.1 TRUE TRUE  FALSE TRUE    2    TRUE
# 
# Absolute minimum support count: 29 
# 
# set item appearances ...[0 item(s)] done [0.00s].
# set transactions ...[169 item(s), 9835 transaction(s)] done [0.01s].
# sorting and recoding items ... [136 item(s)] done [0.00s].
# creating transaction tree ... done [0.00s].
# checking subsets of size 1 2 3 4 5 done [0.02s].
# writing ... [19 rule(s)] done [0.00s].
# creating S4 object  ... done [0.00s]. 

arules
#set of 19 rules 

#to view rules by lift values using inspect
inspect(head(sort(arules, by = "lift")))
#  lhs                     rhs                    support confidence     lift count
# [1] {citrus fruit,                                                                  
#   tropical fruit,                                                                
#   root vegetables,                                                               
#   whole milk}         => {other vegetables} 0.003152008  0.8857143 4.577509    31
# [2] {citrus fruit,                                                                  
#   tropical fruit,                                                                
#   root vegetables}    => {other vegetables} 0.004473818  0.7857143 4.060694    44
# [3] {tropical fruit,                                                                
#   root vegetables,                                                               
#   whipped/sour cream} => {other vegetables} 0.003355363  0.7333333 3.789981    33
# [4] {root vegetables,                                                               
#   butter,                                                                        
#   yogurt}             => {whole milk}       0.003050330  0.7894737 3.089723    30
# [5] {root vegetables,                                                               
#   other vegetables,                                                              
#   brown bread}        => {whole milk}       0.003152008  0.7750000 3.033078    31
# [6] {onions,                                                                        
#   butter}             => {whole milk}       0.003050330  0.7500000 2.935237    30


#overall quality
head(quality(arules))
# support confidence     lift count
# 1 0.003253686  0.7111111 2.783039    32
# 2 0.003050330  0.7500000 2.935237    30
# 3 0.003558719  0.7142857 2.795464    35
# 4 0.003355363  0.7021277 2.747881    33
# 5 0.004880529  0.7164179 2.803808    48
# 6 0.004778851  0.7343750 2.874086    47

plot(arules)
#rules having high support, confidence and lift ratio values can be targeted from plot

windows()
plot(arules,method = "grouped")
#rules with high support and high confidence is chosen

#apriori function for different support, confidence values
#support = 0.002 and confidence = 0.6
arules <- apriori(Groceries, parameter =list(support = 0.002, confidence = 0.6, minlen=2))
# Apriori
# 
# Parameter specification:
#   confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target   ext
# 0.6    0.1    1 none FALSE            TRUE       5   0.002      2     10  rules FALSE
# 
# Algorithmic control:
#   filter tree heap memopt load sort verbose
# 0.1 TRUE TRUE  FALSE TRUE    2    TRUE
# 
# Absolute minimum support count: 19 
# 
# set item appearances ...[0 item(s)] done [0.00s].
# set transactions ...[169 item(s), 9835 transaction(s)] done [0.01s].
# sorting and recoding items ... [147 item(s)] done [0.00s].
# creating transaction tree ... done [0.00s].
# checking subsets of size 1 2 3 4 5 done [0.01s].
# writing ... [376 rule(s)] done [0.00s].
# creating S4 object  ... done [0.00s].

arules
#set of 376 rules

#to view rules by lift values using inspect
inspect(head(sort(arules, by = "lift")))
# lhs                    rhs                   support confidence     lift count
# [1] {beef,                                                                        
#   citrus fruit,                                                                
#   other vegetables}  => {root vegetables} 0.002135231  0.6363636 5.838280    21
# [2] {citrus fruit,                                                                
#   tropical fruit,                                                              
#   other vegetables,                                                            
#   whole milk}        => {root vegetables} 0.003152008  0.6326531 5.804238    31
# [3] {citrus fruit,                                                                
#   other vegetables,                                                            
#   frozen vegetables} => {root vegetables} 0.002033554  0.6250000 5.734025    20
# [4] {beef,                                                                        
#   tropical fruit,                                                              
#   other vegetables}  => {root vegetables} 0.002745297  0.6136364 5.629770    27
# [5] {herbs,                                                                       
#   other vegetables,                                                            
#   whole milk}        => {root vegetables} 0.002440264  0.6000000 5.504664    24
# [6] {tropical fruit,                                                              
#   other vegetables,                                                            
#   whole milk,                                                                  
#   butter}            => {yogurt}          0.002338587  0.6969697 4.996135    23

#overall quality
head(quality(arules))
#       support confidence     lift count
# 1 0.003660397  0.6428571 2.515917    36
# 2 0.004677173  0.6133333 2.400371    46
# 3 0.002033554  0.7142857 2.795464    20
# 4 0.002236909  0.7096774 3.667723    22
# 5 0.002440264  0.7741935 3.029922    24
# 6 0.002643620  0.6666667 2.609099    26

plot(arules)
#rules having high support, confidence and lift ratio values can be targeted from plot

windows()
plot(arules,method = "grouped")
#rules with high support and high confidence is chosen

#apriori function for different support, confidence values
#support = 0.002 and confidence = 0.7
arules <- apriori(Groceries, parameter =list(support = 0.002, confidence = 0.7, minlen=2))
# Apriori
# 
# Parameter specification:
#   confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target   ext
# 0.7    0.1    1 none FALSE            TRUE       5   0.002      2     10  rules FALSE
# 
# Algorithmic control:
#   filter tree heap memopt load sort verbose
# 0.1 TRUE TRUE  FALSE TRUE    2    TRUE
# 
# Absolute minimum support count: 19 
# 
# set item appearances ...[0 item(s)] done [0.00s].
# set transactions ...[169 item(s), 9835 transaction(s)] done [0.01s].
# sorting and recoding items ... [147 item(s)] done [0.00s].
# creating transaction tree ... done [0.00s].
# checking subsets of size 1 2 3 4 5 done [0.02s].
# writing ... [94 rule(s)] done [0.00s].
# creating S4 object  ... done [0.00s].

arules
# set of 94 rules

#to view rules by lift values using inspect
inspect(head(sort(arules, by = "lift")))
# lhs                        rhs                    support confidence     lift count
# [1] {citrus fruit,                                                                     
#   tropical fruit,                                                                   
#   root vegetables,                                                                  
#   whole milk}            => {other vegetables} 0.003152008  0.8857143 4.577509    31
# [2] {tropical fruit,                                                                   
#   grapes,                                                                           
#   whole milk}            => {other vegetables} 0.002033554  0.8000000 4.134524    20
# [3] {root vegetables,                                                                  
#   whole milk,                                                                       
#   yogurt,                                                                           
#   fruit/vegetable juice} => {other vegetables} 0.002033554  0.8000000 4.134524    20
# [4] {citrus fruit,                                                                     
#   tropical fruit,                                                                   
#   root vegetables}       => {other vegetables} 0.004473818  0.7857143 4.060694    44
# [5] {tropical fruit,                                                                   
#   root vegetables,                                                                  
#   fruit/vegetable juice} => {other vegetables} 0.002541942  0.7812500 4.037622    25
# [6] {onions,                                                                           
#   whole milk,                                                                       
#   whipped/sour cream}    => {other vegetables} 0.002135231  0.7777778 4.019677    21

#overall quality
head(quality(arules))
#       support confidence     lift count
# 1 0.002033554  0.7142857 2.795464    20
# 2 0.002236909  0.7096774 3.667723    22
# 3 0.002440264  0.7741935 3.029922    24
# 4 0.002135231  0.7241379 3.742457    21
# 5 0.002338587  0.8214286 3.214783    23
# 6 0.002440264  0.8000000 3.130919    24

plot(arules)
#rules having high support, confidence and lift ratio values can be targeted from plot

windows()
plot(arules,method = "grouped")
#rules with high support and high confidence is chosen