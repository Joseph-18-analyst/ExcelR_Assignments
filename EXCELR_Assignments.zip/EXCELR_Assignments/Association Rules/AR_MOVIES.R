#BUISNESS PROBLEM
#Prepare rules for the all the data sets 
# 1) Try different values of support and confidence. Observe the change in number of rules for different support,confidence values
# 2) Change the minimum length in apriori algorithm
# 3) Visulize the obtained rules using different plots 
# MY_MOVIES.CSV DATASET

#used for building association rules
install.packages("arules")
library(arules)

#for visualizing rules, plotting the rules which was visualized
install.packages("arulesViz")
library(arulesViz)

#loading dataset to variable
armovies <- read.csv("C:\\Users\\Windows\\Desktop\\DATA SCIENCE\\ASSIGNMENTS LMS\\ASSOCIATION RULES\\my_movies.csv")

#viewing dataset
View(armovies)

#structure of dataset
str(armovies)
# 'data.frame':	10 obs. of  15 variables:
#   $ V1           : Factor w/ 4 levels "Gladiator","Harry Potter1",..: 4 1 3 1 1 1 2 1 1 4
# $ V2           : Factor w/ 5 levels "Harry Potter2",..: 3 5 4 5 5 5 1 5 5 2
# $ V3           : Factor w/ 5 levels "","Braveheart",..: 4 2 1 5 5 5 1 1 5 3
# $ V4           : Factor w/ 2 levels "","Green Mile": 2 1 1 1 1 1 1 1 1 2
# $ V5           : Factor w/ 2 levels "","LOTR2": 2 1 1 1 1 1 1 1 1 1
# $ Sixth.Sense  : int  1 0 0 1 1 1 0 0 1 1
# $ Gladiator    : int  0 1 0 1 1 1 0 1 1 1
# $ LOTR1        : int  1 0 1 0 0 0 0 0 0 0
# $ Harry.Potter1: int  1 0 0 0 0 0 1 0 0 0
# $ Patriot      : int  0 1 0 1 1 1 0 1 1 0
# $ LOTR2        : int  1 0 1 0 0 0 0 0 0 0
# $ Harry.Potter2: int  0 0 0 0 0 0 1 0 0 0
# $ LOTR         : int  0 0 0 0 0 0 0 0 0 1
# $ Braveheart   : int  0 1 0 0 0 0 0 0 0 0
# $ Green.Mile   : int  1 0 0 0 0 0 0 0 0 1

#class for armovies is in data frame format
class(armovies)
#[1] "data.frame"

#building rules ausing apriori alogirthm
rules <- apriori(as.matrix(armovies[,6:15], parameter = list(support = 0.2, confidence = 0.5, minlength=3)))
# Apriori
# 
# Parameter specification:
#   confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target   ext
# 0.8    0.1    1 none FALSE            TRUE       5     0.1      1     10  rules FALSE
# 
# Algorithmic control:
#   filter tree heap memopt load sort verbose
# 0.1 TRUE TRUE  FALSE TRUE    2    TRUE
# 
# Absolute minimum support count: 1 
# 
# set item appearances ...[0 item(s)] done [0.00s].
# set transactions ...[10 item(s), 10 transaction(s)] done [0.00s].
# sorting and recoding items ... [10 item(s)] done [0.00s].
# creating transaction tree ... done [0.00s].
# checking subsets of size 1 2 3 4 5 done [0.00s].
# writing ... [77 rule(s)] done [0.00s].
# creating S4 object  ... done [0.00s].

rules
#set of 77 rules

#to view rules by lift values using inspect
inspect(head(sort(rules, by = "lift")))
# lhs                                   rhs             support confidence lift count
# [1] {Gladiator,Green.Mile}             => {LOTR}          0.1     1          10   1    
# [2] {Sixth.Sense,Gladiator,Green.Mile} => {LOTR}          0.1     1          10   1    
# [3] {Harry.Potter2}                    => {Harry.Potter1} 0.1     1           5   1    
# [4] {LOTR}                             => {Green.Mile}    0.1     1           5   1    
# [5] {LOTR1}                            => {LOTR2}         0.2     1           5   2    
# [6] {LOTR2}                            => {LOTR1}         0.2     1           5   2    

#overall quality
head(quality(rules))
#   support confidence     lift count
# 1     0.1          1 5.000000     1
# 2     0.1          1 1.666667     1
# 3     0.1          1 1.428571     1
# 4     0.1          1 5.000000     1
# 5     0.1          1 1.428571     1
# 6     0.1          1 1.666667     1

plot(rules)
#rules having high support, confidence and lift ratio values can be targeted from plot

windows()
plot(rules,method = "grouped")
#rules with high support and high confidence is chosen

#apriori function for different support, confidence values
#support = 0.2 and confidence = 0.5
rules <- apriori(as.matrix(armovies[,6:15], parameter = list(support=0.2, confidence=0.5, minlen=5)))
# Apriori
# 
# Parameter specification:
#   confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target   ext
# 0.8    0.1    1 none FALSE            TRUE       5     0.1      1     10  rules FALSE
# 
# Algorithmic control:
#   filter tree heap memopt load sort verbose
# 0.1 TRUE TRUE  FALSE TRUE    2    TRUE
# 
# Absolute minimum support count: 1 
# 
# set item appearances ...[0 item(s)] done [0.00s].
# set transactions ...[10 item(s), 10 transaction(s)] done [0.00s].
# sorting and recoding items ... [10 item(s)] done [0.00s].
# creating transaction tree ... done [0.00s].
# checking subsets of size 1 2 3 4 5 done [0.00s].
# writing ... [77 rule(s)] done [0.00s].
# creating S4 object  ... done [0.00s].


rules
#set of 77 rules

#to view rules by lift values using inspect
inspect(head(sort(rules, by = "lift")))
# lhs                                   rhs             support confidence lift count
# [1] {Gladiator,Green.Mile}             => {LOTR}          0.1     1          10   1    
# [2] {Sixth.Sense,Gladiator,Green.Mile} => {LOTR}          0.1     1          10   1    
# [3] {Harry.Potter2}                    => {Harry.Potter1} 0.1     1           5   1    
# [4] {LOTR}                             => {Green.Mile}    0.1     1           5   1    
# [5] {LOTR1}                            => {LOTR2}         0.2     1           5   2    
# [6] {LOTR2}                            => {LOTR1}         0.2     1           5   2   

#overall quality
head(quality(rules))
#   support confidence     lift count
# 1     0.1          1 5.000000     1
# 2     0.1          1 1.666667     1
# 3     0.1          1 1.428571     1
# 4     0.1          1 5.000000     1
# 5     0.1          1 1.428571     1
# 6     0.1          1 1.666667     1

plot(rules)
#rules having high support, confidence and lift ratio values can be targeted from plot

windows()
plot(rules,method = "grouped")
#rules with high support and high confidence is chosen