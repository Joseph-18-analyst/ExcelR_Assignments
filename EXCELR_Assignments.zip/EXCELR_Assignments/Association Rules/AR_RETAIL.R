#BUISNESS PROBLEM
#Prepare rules for the all the data sets 
# 1) Try different values of support and confidence. Observe the change in number of rules for different support,confidence values
# 2) Change the minimum length in apriori algorithm
# 3) Visulize the obtained rules using different plots 
# TRANSACTION RETAIL.CSV DATASET

#used for building association rules
install.packages("arules")
library(arules)

#for visualizing rules, plotting the rules which was visualized
install.packages("arulesViz")
library(arulesViz)

#loading the transaction retail.csv dataset
transact_det <- read.csv(file.choose(), header = FALSE)

#viewing the dataset
# The Data Set has 557041 Observations (rows) with 6 Dimensions (columns)
View(transact_det)

#structure of dataset
str(transact_det)
# 'data.frame':	557041 obs. of  6 variables:
# $ V1: Factor w/ 949 levels "'''N'''","'-'",..: 719 773 461 297 722 94 677 715 584 178 ...
# $ V2: Factor w/ 1177 levels "'1'","'10'","'12'",..: 657 830 357 540 686 80 615 707 648 128 ...
# $ V3: Factor w/ 1099 levels "'17058'","'17059'",..: 386 1077 145 397 794 40 386 1055 748 113 ...
# $ V4: Factor w/ 856 levels "'BADGES'","'BERTIE'",..: 709 NA 151 213 822 336 666 814 502 372 ...
# $ V5: Factor w/ 489 levels "'CARDS'","'CATS'",..: 459 NA 37 426 474 259 366 NA 449 NA ...
# $ V6: Factor w/ 184 levels "'GIRL'","'GLASS'",..: NA NA NA 161 NA NA NA NA NA NA ...


#applying apriori alogrithm to generate rules
#support is 0.003 and confidence = 0.8
arules <- apriori(transact_det,parameter=list(support=0.003, confidence = 0.8,minlen=5))
# Apriori
# 
# Parameter specification:
#   confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target   ext
# 0.8    0.1    1 none FALSE            TRUE       5   0.003      5     10  rules FALSE
# 
# Algorithmic control:
#   filter tree heap memopt load sort verbose
# 0.1 TRUE TRUE  FALSE TRUE    2    TRUE
# 
# Absolute minimum support count: 1671 
# 
# set item appearances ...[0 item(s)] done [0.00s].
# set transactions ...[4754 item(s), 557041 transaction(s)] done [1.62s].
# sorting and recoding items ... [307 item(s)] done [0.05s].
# creating transaction tree ... done [0.50s].
# checking subsets of size 1 2 3 4 5 done [0.00s].
# writing ... [8 rule(s)] done [0.00s].
# creating S4 object  ... done [0.07s].

arules
#set of 8 rules

#to view rules by lift values using inspect
inspect(head(sort(arules, by = "lift")))
# lhs                                                  rhs            support     confidence
# [1] {V2='HEART',V3='HOLDER',V4='T-LIGHT',V5='WHITE'}  => {V1='HANGING'} 0.004252829 1         
# [2] {V1='HANGING',V2='HEART',V3='HOLDER',V5='WHITE'}  => {V4='T-LIGHT'} 0.004252829 1         
# [3] {V1='72',V2='CAKE',V3='CASES',V4='OF'}            => {V5='PACK'}    0.003703498 1         
# [4] {V1='HANGING',V2='HEART',V4='T-LIGHT',V5='WHITE'} => {V3='HOLDER'}  0.004252829 1         
# [5] {V1='72',V2='CAKE',V4='OF',V5='PACK'}             => {V3='CASES'}   0.003703498 1         
# [6] {V1='72',V3='CASES',V4='OF',V5='PACK'}            => {V2='CAKE'}    0.003703498 1         
# lift     count
# [1] 80.54381 2369 
# [2] 79.52049 2369 
# [3] 78.04974 2063 
# [4] 71.76514 2369 
# [5] 54.12895 2063 
# [6] 38.00771 2063 

#overall quality
head(quality(arules))
#       support confidence     lift count
# 1 0.003703498          1 26.93231  2063
# 2 0.003703498          1 38.00771  2063
# 3 0.003703498          1 54.12895  2063
# 4 0.003703498          1 78.04974  2063
# 5 0.004252829          1 34.41286  2369
# 6 0.004252829          1 71.76514  2369

plot(arules)
#rules having high support, confidence and lift ratio values can be targeted from plot

windows()
plot(arules,method = "grouped")
#rules with high support and high confidence is chosen

#applying apriori alogrithm to generate rules
#support is 0.02 and confidence = 0.9
arules <- apriori(transact_det,parameter=list(support=0.002, confidence = 0.6, minlen=4))
# Apriori
# 
# Parameter specification:
#   confidence minval smax arem  aval originalSupport maxtime support minlen maxlen target   ext
# 0.6    0.1    1 none FALSE            TRUE       5   0.002      4     10  rules FALSE
# 
# Algorithmic control:
#   filter tree heap memopt load sort verbose
# 0.1 TRUE TRUE  FALSE TRUE    2    TRUE
# 
# Absolute minimum support count: 1114 
# 
# set item appearances ...[0 item(s)] done [0.00s].
# set transactions ...[4754 item(s), 557041 transaction(s)] done [1.50s].
# sorting and recoding items ... [475 item(s)] done [0.04s].
# creating transaction tree ... done [0.50s].
# checking subsets of size 1 2 3 4 5 6 done [0.02s].
# writing ... [476 rule(s)] done [0.00s].
# creating S4 object  ... done [0.08s].

arules
#set of 476 rules 

#to view rules by lift values using inspect
inspect(head(sort(arules, by = "lift")))
# lhs                                                 rhs           support     confidence
# [1] {V2='FRAME',V3='PICTURE',V5='WOODEN'}            => {V1='FINISH'} 0.002026781 1         
# [2] {V3='PICTURE',V4='WHITE',V5='WOODEN'}            => {V1='FINISH'} 0.002026781 1         
# [3] {V2='FRAME',V3='PICTURE',V4='WHITE'}             => {V1='FINISH'} 0.002026781 1         
# [4] {V2='FRAME',V4='WHITE',V5='WOODEN'}              => {V1='FINISH'} 0.002026781 1         
# [5] {V2='FRAME',V3='PICTURE',V4='WHITE',V5='WOODEN'} => {V1='FINISH'} 0.002026781 1         
# [6] {V1='JAM',V3='PRINTED',V4='SET'}                 => {V2='MAKING'} 0.002121926 1         
# lift     count
# [1] 493.3933 1129 
# [2] 493.3933 1129 
# [3] 493.3933 1129 
# [4] 493.3933 1129 
# [5] 493.3933 1129 
# [6] 471.2699 1182 

plot(arules)
#rules having high support, confidence and lift ratio values can be targeted from plot

windows()
plot(arules,method = "grouped")
#rules with high support and high confidence is chosen