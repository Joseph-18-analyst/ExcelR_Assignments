#BUISNESS PROBLEM
#Perform Basic Visualizations for all the columns(numerical data only) on any 
#data set from data set folder make sure it has more data. So we can make better inferences
#for the visualizations(boxplot,histogram)

#loading the dataset
data_set <- read.csv(file.choose())

#data set has 34 observations/rows and 3 columns/dimensions

#view the dataset
View(data_set)

#getting column names of dataset
colnames(data_set)
#[1] "Newspaper" "daily"     "sunday" 

#Generating hisotgram of column daily
hist(data_set$daily)
#DISTRIBUTION IS RIGHT SKEWED, WITH LONG TAIL TO THE RIGHT
#Around 16 news papers have circulation more than 200,000 to 400,000
#it has positive skewness value as distribution is right skewed
# 2 news papers have circulation above 1000,000

#Generating box plot for column daily
boxplot(data_set$daily)
#Suspected 2 outliers above upper whisker
#Median is close to first quartile. It is right skewed data and skewness is positive

#generating histogram for column sunday
hist(data_set$sunday)
#distribution is right skewed, with long tail to right. 
#more than 20 news papers have circulation around 500,000
# 2 news papers have circulation above 1500,000 on sunday

#generating box plot of column sunday
boxplot(data_set$sunday)
#Suspected 2 outliers above upper whisker
#Median is close to first quartile. It is right skewed data and skewness is positive