q7 <-Q7
q7
mean(q7$drat)
median(q7$drat)
var(q7$drat)
sd(q7$drat)
range(q7$drat)

install.packages("readr")

mean(q7$wt)
median(q7$wt)
var(q7$wt)
sd(q7$wt)
range(q7$wt)

mean(q7$qsec)
median(q7$qsec)
var(q7$qsec)
sd(q7$qsec)
range(q7$qsec)

108+110+123+134+135+145+167+187+199
1308/9
c <- data.frame(108, 110, 123, 134, 135, 145, 167, 187, 199)
boxplot(c)
boxplot(q7$wt)


##question 9
q9 <-Q9_a
q9
install.packages ("moments")
library(moments)
skewness(q9$speed)
kurtosis(q9$speed)
hist(q9$speed)
hist(q9$dist)

cars <- Cars
skewness(cars$SP)
kurtosis(cars$SP)
skewness(cars$WT)
skewness(Cars$WT)
kurtosis(cars$WT)
hist(cars$SP)
hist(cars$WT)

library()
install.packages("xlsx")

cube <- function(x){x^x^x}
cube(2)
cube(1:4)
1:4
cube(1:4)
a  <- seq(1, 0, -0.1)
a
datasets()
data()
datasets()
data("EuStockMarkets")
View(EuStockMarkets)
install.packages("Lattice")
install.packages("lattice")
library(lattice)
data("barley")
view(barley)
View(barley)


1*0.015+4*0.20+3*0.65+0.005+5*0.005+6*0.01+2*0.120
1/21

scores <- c(34,36,36,38,38,39,39,40,40,41,41,41,41,42,42,45,49,56)
scores
mean(scores)
median(scores)
var(scores)
sd(scores)

# cars.csv question 20
mean(Cars$MPG)
sd(Cars$MPG)
pnorm (38, 34.42208, 9.131445)
1- pnorm (38, 34.42208, 9.131445) 
pnorm (40, 34.42208, 9.131445) 
pnorm (50, 34.42208, 9.131445) - pnorm (20, 34.42208, 9.131445)
hist(Cars$MPG)
qqnorm(Cars$MPG)
qqline(Cars$MPG)
qqnorm(wc.at$Waist)
qqline(wc.at$Waist)
qqnorm(wc.at$AT)
qqline(wc.at$AT)

plot <- new
median(plot$Measure.X)
var(plot$Measure.X)
sd(plot$Measure.X)
qt(0.995, 24)
