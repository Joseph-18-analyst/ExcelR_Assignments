#buisness problem
#Perform clustering (Both hierarchical and K means clustering) for the airlines data to 
#obtain optimum number of clusters. Draw the inferences from the clusters obtained.

install.packages("data.table")
library (data.table)

install.packages("corpcor")
library(corpcor)

install.packages("MASS")
library(MASS)

install.packages("WriteXLS")
library(WriteXLS)
library(xlsx)

install.packages("readxl")
library(readxl)

install.packages("cluster")
library(cluster)

#loading dataset
EastWestAirlines <- read_xlsx("C:\\Users\\Windows\\Desktop\\DATA SCIENCE\\ASSIGNMENTS LMS\\CLUSTERING\\EastWestAirlines.xlsx", sheet = "data")

#getting column names
colnames(EastWestAirlines)
#[1] "ID#"               "Balance"           "Qual_miles"        "cc1_miles"        
#[5] "cc2_miles"         "cc3_miles"         "Bonus_miles"       "Bonus_trans"      
#[9] "Flight_miles_12mo" "Flight_trans_12"   "Days_since_enroll" "Award?"  

ncol(EastWestAirlines)
#[1] 12

#excluding first column which has id numbers
sub_eastwestair <- EastWestAirlines[,2:12]

#summary of data
summary(EastWestAirlines)

#ID#          Balance          Qual_miles        cc1_miles      cc2_miles       cc3_miles    
#Min.   :   1   Min.   :      0   Min.   :    0.0   Min.   :1.00   Min.   :1.000   Min.   :1.000  
#1st Qu.:1010   1st Qu.:  18528   1st Qu.:    0.0   1st Qu.:1.00   1st Qu.:1.000   1st Qu.:1.000  
#Median :2016   Median :  43097   Median :    0.0   Median :1.00   Median :1.000   Median :1.000  
#Mean   :2015   Mean   :  73601   Mean   :  144.1   Mean   :2.06   Mean   :1.015   Mean   :1.012  
#3rd Qu.:3020   3rd Qu.:  92404   3rd Qu.:    0.0   3rd Qu.:3.00   3rd Qu.:1.000   3rd Qu.:1.000  
#Max.   :4021   Max.   :1704838   Max.   :11148.0   Max.   :5.00   Max.   :3.000   Max.   :5.000  
#Bonus_miles      Bonus_trans   Flight_miles_12mo Flight_trans_12  Days_since_enroll
#Min.   :     0   Min.   : 0.0   Min.   :    0.0   Min.   : 0.000   Min.   :   2     
#1st Qu.:  1250   1st Qu.: 3.0   1st Qu.:    0.0   1st Qu.: 0.000   1st Qu.:2330     
#Median :  7171   Median :12.0   Median :    0.0   Median : 0.000   Median :4096     
#Mean   : 17145   Mean   :11.6   Mean   :  460.1   Mean   : 1.374   Mean   :4119     
#3rd Qu.: 23801   3rd Qu.:17.0   3rd Qu.:  311.0   3rd Qu.: 1.000   3rd Qu.:5790     
#Max.   :263685   Max.   :86.0   Max.   :30817.0   Max.   :53.000   Max.   :8296     
#Award?      
#Min.   :0.0000  
#1st Qu.:0.0000  
#Median :0.0000  
#Mean   :0.3703  
#3rd Qu.:1.0000  
#Max.   :1.0000

#normalizing data using scale function
normal_airline <- scale(sub_eastwestair)

#viewing data
View(normal_airline)

#summary of data
summary(normal_airline)
#Balance          Qual_miles        cc1_miles         cc2_miles          cc3_miles       
#Min.   :-0.7303   Min.   :-0.1863   Min.   :-0.7695   Min.   :-0.09823   Min.   :-0.06276  
#1st Qu.:-0.5465   1st Qu.:-0.1863   1st Qu.:-0.7695   1st Qu.:-0.09823   1st Qu.:-0.06276  
#Median :-0.3027   Median :-0.1863   Median :-0.7695   Median :-0.09823   Median :-0.06276  
#Mean   : 0.0000   Mean   : 0.0000   Mean   : 0.0000   Mean   : 0.00000   Mean   : 0.00000  
#3rd Qu.: 0.1866   3rd Qu.:-0.1863   3rd Qu.: 0.6830   3rd Qu.:-0.09823   3rd Qu.:-0.06276  
#Max.   :16.1868   Max.   :14.2231   Max.   : 2.1356   Max.   :13.44729   Max.   :20.42477  
#Bonus_miles       Bonus_trans       Flight_miles_12mo Flight_trans_12    Days_since_enroll 
#Min.   :-0.7099   Min.   :-1.20805   Min.   :-0.3286   Min.   :-0.36212   Min.   :-1.99336  
#1st Qu.:-0.6581   1st Qu.:-0.89568   1st Qu.:-0.3286   1st Qu.:-0.36212   1st Qu.:-0.86607  
#Median :-0.4130   Median : 0.04145   Median :-0.3286   Median :-0.36212   Median :-0.01092  
#Mean   : 0.0000   Mean   : 0.00000   Mean   : 0.0000   Mean   : 0.00000   Mean   : 0.00000  
#3rd Qu.: 0.2756   3rd Qu.: 0.56208   3rd Qu.:-0.1065   3rd Qu.:-0.09849   3rd Qu.: 0.80960  
#Max.   :10.2083   Max.   : 7.74673   Max.   :21.6803   Max.   :13.61035   Max.   : 2.02284  
#Award?       
#Min.   :-0.7668  
#1st Qu.:-0.7668  
#Median :-0.7668  
#Mean   : 0.0000  
#3rd Qu.: 1.3038  
#Max.   : 1.3038

#measuring distance using euclidean
d <- dist(normal_airline, method = "euclidean")
d

str(d)

#performing heirarchical clustering
fit1 <- hclust(d, method = "complete")

#plotting it on dendrogram
plot(fit1, hang = -1)

#cutting into 5 clusters using cutree() function
groups <- cutree(fit1, k = 5)
groups

#showing clusters in red border using rect.hclust() method
rect.hclust(fit1, k=5, border = "red")

#binding the column "groups" to data set
Airlines_new <- cbind(EastWestAirlines, groups)
View(Airlines_new)

#renaming column "groups" to new column name "groups_hclust"
setnames(Airlines_new, 'groups', 'groups_hclust')
View(Airlines_new)

aggregate(Airlines_new[,2:12], by = list(Airlines_new$groups_hclust), FUN = mean)

#Group.1   Balance Qual_miles cc1_miles cc2_miles cc3_miles Bonus_miles Bonus_trans
#1       1  65902.07   137.3707  2.033580  1.000000  1.000793    15571.37    10.72448
#2       2 117123.66   255.7529  2.252941  1.341176  1.000000    37437.17    26.72941
#3       3 806433.29   383.2143  3.571429  1.000000  1.000000    58412.32    21.21429
#4       4 138061.40    78.8000  3.466667  1.000000  4.066667    93927.87    28.06667
#5       5 131999.50   347.0000  2.500000  1.000000  1.000000    65634.25    69.25000
#  Flight_miles_12mo Flight_trans_12 Days_since_enroll    Award?
#1          270.5854       0.8183501          4072.295 0.3503437
#2         4066.6235      11.8823529          4701.688 0.7058824
#3         1344.3929       5.6071429          6835.893 0.8571429
#4          506.6667       1.6000000          4613.867 0.5333333
#5        19960.0000      49.2500000          2200.250 1.0000000


#PERFROM K-MEAN CLUSTERING ON NORMALIZED DATASET: "normal_airline" USING KMEANS METHOD
#CHOSE NUMBER OF CLUSTERS I.E K =5

airline_kmeans <- kmeans(normal_airline, 5)

#structure- str tells about clusters and its centers
str(airline_kmeans)
#List of 9
#$ cluster     : int [1:3999] 3 3 3 3 2 3 2 3 1 2 ...
#$ centers     : num [1:5, 1:11] 1.188 0.471 -0.138 0.64 -0.367 ...
#..- attr(*, "dimnames")=List of 2
#.. ..$ : chr [1:5] "1" "2" "3" "4" ...
#.. ..$ : chr [1:11] "Balance" "Qual_miles" "cc1_miles" "cc2_miles" ...
#$ totss       : num 43978
#$ withinss    : num [1:5] 5025 7886 7601 389 4272
#$ tot.withinss: num 25173
#$ betweenss   : num 18805
#$ size        : int [1:5] 156 1105 1241 15 1482
#$ iter        : int 4
#$ ifault      : int 0
#- attr(*, "class")= chr "kmeans"

airline_kmeans$centers 
#     Balance   Qual_miles   cc1_miles   cc2_miles   cc3_miles Bonus_miles Bonus_trans
#1  1.1876857  0.841891007  0.08713096  0.16226123 -0.06275873   0.6271981   1.6687444
#2  0.4712650  0.008454157  1.31925175 -0.07984201 -0.05348836   1.0589883   0.7945470
#3 -0.1378472 -0.041149296 -0.50905894  0.14190055 -0.05863151  -0.4495302  -0.3336842
#4  0.6396393 -0.084422366  1.02195660 -0.09822960 15.64434291   3.1792937   1.7143993
#5 -0.3674447 -0.059611490 -0.57689124 -0.07537953 -0.06275873  -0.5113680  -0.5060138
#  Flight_miles_12mo Flight_trans_12 Days_since_enroll     Award?
#1        3.62101257      3.91175076         0.2757743  0.9321128
#2       -0.07000028     -0.07964315         0.3154072  0.6629064
#3       -0.14407091     -0.14926293         0.7727248 -0.1461504
#4        0.03328853      0.05968793         0.2398426  0.3374851
#5       -0.20866057     -0.22799424        -0.9136942 -0.4734216

#adding column - "airline_kmeans$cluster" to data set Airlines_new
Airlines_new <- cbind(Airlines_new, airline_kmeans$cluster)

#viewing the data
View(Airlines_new)

#getting columnames
colnames(Airlines_new)
#[1]"ID#"                    "Balance"                "Qual_miles"            
#[4]"cc1_miles"              "cc2_miles"              "cc3_miles"             
#[7]"Bonus_miles"            "Bonus_trans"            "Flight_miles_12mo"     
#[10]"Flight_trans_12"       "Days_since_enroll"      "Award?"                
#[13]"groups_hclust"         "airline_kmeans$cluster"


#Aggregating for kemans clustering
aggregate(Airlines_new[,2:12], by = list(Airlines_new$`airline_kmeans$cluster`), FUN =  mean)
#Group.1     Balance Qual_miles cc1_miles cc2_miles cc3_miles Bonus_miles Bonus_trans
#1       1 193291.15  795.45513  2.179487  1.038462  1.000000   32292.288    27.62821
#2       2 121093.37  150.65520  3.876018  1.002715  1.001810   42720.438    19.23258
#3       3  59709.68  112.27881  1.358582  1.035455  1.000806    6288.257     8.39726
#4       4 138061.40   78.80000  3.466667  1.000000  4.066667   93927.867    28.06667
#5       5  36571.85   97.99528  1.265182  1.003374  1.000000    4794.814     6.74224
#  Flight_miles_12mo Flight_trans_12 Days_since_enroll    Award?
#1         5530.2308      16.2115385          4688.071 0.8205128
#2          362.0407       1.0714932          4769.918 0.6904977
#3          258.3263       0.8074134          5714.340 0.2997583
#4          506.6667       1.6000000          4613.867 0.5333333
#5          167.8873       0.5087719          2231.658 0.1417004

#Building SCREE PLOT to check optimum cluster K value
#creating a variable and assigning it to NULL 

twss <- NULL
for (i in 2:8) {twss <- c(twss,kmeans(normal_airline, centers =  i)$tot.withinss)}
twss

#[1] 35400.65 33472.48 28587.01 26790.98 25694.64 19161.07 18614.76

#using twss va;ues give above, we will be plotting scree-plot or elbow curve to perfrom k(cluster) Selection
# x- axis will have K values(clusters) and Y-axis will have within sum of squares(wss) values
# k:2= 35400.65, K:3= 33472.48, K:4= 28587.01, K:5= 26790.98, K:6= 25694.64, K:7= 19161.07, K:8= 18614.76
plot(twss, type = "b", xlab = "NUmber of Clusters", ylab = "within group sum of squares")
title(sub = "k-means Clustering scree plot")

#from scree plot from K value 5 (in graph it is 4) to K Value 6( in graph it is 5) we can see maximum 
#net reduction in similarities. We can conclude saying k = 6 cluster will be optimum clusters

# 6 IS OPTIMUM NUMBER OF CLUSTERS OBTAINED FROM SCREE-PLOT/ELBOW PLOT.

#PERFROM K-MEAN CLUSTERING ON NORMALIZED DATASET: "normal_airline" USING KMEANS METHOD
#CHOSE NUMBER OF CLUSTERS I.E K =6
airline_kmeans1 <- kmeans(normal_airline, 6)
#structure- str tells about clusters and its centers
str(airline_kmeans1)
#after performing 3 iteration of line "airline_kmeans1 <- kmeans(normal_airline, 6)", considering 3rd iteration
# as it is having less tot.withinss 21751 value compared to 3 iterations, so less variances within each clusters
# betweenss value is 22227 is higher than 3 iterations, higher this value , better it is
#List of 9
#$ cluster     : int [1:3999] 4 4 4 4 3 4 3 4 1 3 ...
#$ centers     : num [1:6, 1:11] -0.0469 1.1689 0.4705 -0.1366 0.6396 ...
#..- attr(*, "dimnames")=List of 2
#.. ..$ : chr [1:6] "1" "2" "3" "4" ...
#.. ..$ : chr [1:11] "Balance" "Qual_miles" "cc1_miles" "cc2_miles" ...
#$ totss       : num 43978
#$ withinss    : num [1:6] 727 4529 7719 4490 389 ...
#$ tot.withinss: num 21751
#$ betweenss   : num 22227
#$ size        : int [1:6] 43 152 1102 1220 15 1467
#$ iter        : int 4
#$ ifault      : int 0
#- attr(*, "class")= chr "kmeans"

airline_kmeans1$centers 

#getting clusters
airline_kmeans1$cluster

#adding column - "airline_kmeans$cluster" to data set Airlines_new
Airlines_new <- cbind(Airlines_new, airline_kmeans1$cluster)

#renaming the column "airline_kmeans1$cluster" to "kmeans_final"
setnames(Airlines_new, 'airline_kmeans1$cluster', 'kmeans_final')

#viewing final data
View(Airlines_new)

# 6 IS OPTIMUM NUMBER OF CLUSTERS OBTAINED FROM SCREE-PLOT/ELBOW PLOT.
