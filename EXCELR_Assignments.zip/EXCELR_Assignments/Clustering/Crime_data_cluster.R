#BUISNESS PROBLEM
#Perform Clustering for the crime data and identify the number of clusters formed and draw inferences.

install.packages("data.table")
library (data.table)

install.packages("corpcor")
library(corpcor)

install.packages("MASS")
library(MASS)

install.packages("WriteXLS")
library(WriteXLS)
library(xlsx)

#loading dataset
crimecl <- crime_data

#viewing the data set, data set has 50 observations, 5 dimesnions
View(crimecl)

#summary of data
summary(crimecl)

#X                   Murder          Assault         UrbanPop          Rape      
#Alabama   : 1   Min.   : 0.800   Min.   : 45.0   Min.   :32.00   Min.   : 7.30  
#Alaska    : 1   1st Qu.: 4.075   1st Qu.:109.0   1st Qu.:54.50   1st Qu.:15.07  
#Arizona   : 1   Median : 7.250   Median :159.0   Median :66.00   Median :20.10  
#Arkansas  : 1   Mean   : 7.788   Mean   :170.8   Mean   :65.54   Mean   :21.23  
#California: 1   3rd Qu.:11.250   3rd Qu.:249.0   3rd Qu.:77.75   3rd Qu.:26.18  
#Colorado  : 1   Max.   :17.400   Max.   :337.0   Max.   :91.00   Max.   :46.00  
#(Other)   :44     

#from above summary we see ranges for each column is different, wherein Assault can contribute more
#so standardizing the data to Z scale or normal scale

#normalizing data using scale() function
normal_crimecl <- scale(crimecl[,2:5])

#viewing normalized data
View(normal_crimecl)

#summary of standardized data
summary(normal_crimecl)
#Murder           Assault           UrbanPop             Rape        
#Min.   :-1.6044   Min.   :-1.5090   Min.   :-2.31714   Min.   :-1.4874  
#1st Qu.:-0.8525   1st Qu.:-0.7411   1st Qu.:-0.76271   1st Qu.:-0.6574  
#Median :-0.1235   Median :-0.1411   Median : 0.03178   Median :-0.1209  
#Mean   : 0.0000   Mean   : 0.0000   Mean   : 0.00000   Mean   : 0.0000  
#3rd Qu.: 0.7949   3rd Qu.: 0.9388   3rd Qu.: 0.84354   3rd Qu.: 0.5277  
#Max.   : 2.2069   Max.   : 1.9948   Max.   : 1.75892   Max.   : 2.6444 

#measuring distance using euclidean 
d <- dist(normal_crimecl, method = "euclidean")  #distance matrix is available
d

str(d)

#about hierarchical clustering
?hclust

fit1 <- hclust(d, method = "complete")

#plotting it on dendorgram
plot(fit1)
plot(fit1, hang = -1)

#grouping means cutting into 4 clusters using cutree() function
groups <- cutree(fit1, k = 4)
groups

#[1] 1 1 2 3 2 2 3 3 2 1 3 4 2 3 4 3 3 1 4 2 3 2 3 1 3 4 4 2 4 3 2 2 1 4 3 3 3 3 3 1 4 1 2 3 4 3 3
#[48] 4 3 3

#showing clusters in red border using rect.hclust() method
rect.hclust(fit1, k=4, border = "red")

crime_data_final <- cbind(crimecl, groups)

#converting rows created in groups into columns
membership <- as.matrix(groups)
membership

#attaching dataset created columnwise to dataset crimecl
finalx <- data.frame(membership, crimecl)
View(finalx)
#above dataset "finalx" has new column membership as first column, with cluster id's

aggregate(crimecl[,2:5], by=list(finalx$membership), FUN = mean)

#Group.1    Murder  Assault UrbanPop     Rape
#1       1 14.087500 252.7500 53.50000 24.53750
#2       2 11.054545 264.0909 79.09091 32.61818
#3       3  5.871429 134.4762 70.76190 18.58095
#4       4  3.180000  78.7000 49.30000 11.63000

#AS PER SUMMARY WE CAN SAY GROUP 2 HAS HIGHER CRIMATE