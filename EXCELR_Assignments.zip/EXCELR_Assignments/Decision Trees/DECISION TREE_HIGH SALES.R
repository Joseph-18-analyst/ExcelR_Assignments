#Problem Statement:
#A cloth manufacturing company is interested to know about the segment or attributes causes high sale.
#Approach - A decision tree can be built with target variable Sale 
#(we will first convert it in categorical variable) & all other variable will be independent in the analysis

# installing packages for Decision Tree type C5.0
install.packages("C50")
library(C50)

#Installing packages caret required for paritioning
install.packages("caret")
library(caret)

#LOADING THE DATA SET
company <- Company_Data

#viewing the data
View(company)

#getting structure of dat set
str(company)
#'data.frame':	400 obs. of  11 variables:
#$ Sales      : num  9.5 11.22 10.06 7.4 4.15 ...
#$ CompPrice  : int  138 111 113 117 141 124 115 136 132 132 ...
#$ Income     : int  73 48 35 100 64 113 105 81 110 113 ...
#$ Advertising: int  11 16 10 4 3 13 0 15 0 0 ...
#$ Population : int  276 260 269 466 340 501 45 425 108 131 ...
#$ Price      : int  120 83 80 97 128 72 108 120 124 124 ...
#$ ShelveLoc  : Factor w/ 3 levels "Bad","Good","Medium": 1 2 3 3 1 1 3 2 3 3 ...
#$ Age        : int  42 65 59 55 38 78 71 67 76 76 ...
#$ Education  : int  17 10 12 14 13 16 15 10 10 17 ...
#$ Urban      : Factor w/ 2 levels "No","Yes": 2 2 2 2 2 1 2 2 1 1 ...
#$ US         : Factor w/ 2 levels "No","Yes": 2 2 2 2 1 2 1 2 1 2 ...

# Check if we have missing values in the Data Set
anyNA (company)
#[1] FALSE
#no missing values in data set

#target output variable/column is "sales"
#getting summary of sales column
summary(company$Sales)

# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.000   5.390   7.490   7.496   9.320  16.270 

#Sales column has data in continous format. It needs to be converted into categorical variable with below given condition
# < 5 - Low -> If the Value of Sales <=5, then we set the Sale as "Low"
# 5 to 10 - Medium -> If the Value of Sales > 5 and <= 10, then we set the Sale as "Medium"
# > 10 - High -> If the Value of Sales > 10, then we set the Sale as "High".
# So creating 3 Categories for Sales Data - "Low", "Medium" and "High".
# ===================================================

# Using the Cut Function to convert Sales (numerical) Data into Categorical Data based on the above criteria.
categorySales <- cut (company$Sales, breaks=c(-1,5,10,20), labels=c("Low", "Medium", "High"))

#output categorysales values
categorySales

#replacing first column "sales" in data set company with column "categorySales"
company <- cbind (categorySales, company[,2:11])

#view the updated dataset
View(company)

#paritioning data set into test data: 25% and training data set: 75%
# On Performing createDataPartition, it splits the rows randomly.
# In the below case, we are splitting the rows randomly in 75:25 ratio.
# The randomly selected row numbers are stored in "inTraininglocal"
inTraininglocal <- createDataPartition(company$categorySales, p = 0.75, list = F)

# Use this to create Training and Testing Data Set.
training <- company[inTraininglocal,]
testing <- company[-inTraininglocal,]

#checking dimensions of training data set
dim(training)
#[1] 301  11
# 301 observations and 11 columns or dimensions

#checking dimensions of test data set
dim(testing)
#[1] 99 11
#99 observations and 11 columns or dimensions

#applyging decision tree C5.0 algorithm on training data set 
#c5.0 parameters c5.0(Y~x1+x2+x3..., data = <data-set>) or
#c5.0 parameters c5.0(y~.,data =<data-set>)
model <- C5.0(training$categorySales~., data =training)

#summary of model
summary(model)

#Call:
#  C5.0.formula(formula = training$categorySales ~ ., data = training)
#C5.0 [Release 2.07 GPL Edition]  	Thu Mar 28 17:54:51 2019
#-------------------------------
#  Class specified by attribute `outcome'
#Read 301 cases (11 attributes) from undefined.data
#Decision tree:
#ShelveLoc = Good:
#:...Price > 135:
#:   :...Education <= 16: Medium (11/1)
#:   :   Education > 16: High (2)
#:   Price <= 135:
#:   :...US = No:
#:       :...Price <= 94: High (4)
#:       :   Price > 94: Medium (9/2)
#:       US = Yes:
#:       :...CompPrice > 116: High (22/1)
#:           CompPrice <= 116:
#:           :...Age > 67: High (4)
#:               Age <= 67:
#:               :...Population <= 356: Medium (7/1)
#:                   Population > 356: High (5/1)
#ShelveLoc in {Bad,Medium}:
#:...Price <= 124:
#:...Price <= 88:
#:   :...ShelveLoc = Bad: Medium (9/3)
#:   :   ShelveLoc = Medium:
#:   :   :...Advertising > 4: High (6)
#:   :       Advertising <= 4:
#:   :       :...Education <= 17: Medium (5)
#:   :           Education > 17: High (2)
#:   Price > 88:
#:   :...ShelveLoc = Bad:
#:       :...CompPrice > 127: Medium (10)
#:       :   CompPrice <= 127:
#:       :   :...US = No:
#:       :       :...Price <= 97: Medium (4)
#:       :       :   Price > 97: Low (9/3)
#:       :       US = Yes:
#:       :       :...Education <= 11: Low (6/1)
#:       :           Education > 11: Medium (10/1)
#:       ShelveLoc = Medium:
#:       :...Age > 49:
#:           :...CompPrice <= 97: Low (2)
#:           :   CompPrice > 97: Medium (58/8)
#:           Age <= 49:
#:           :...Advertising > 14: High (3)
#:               Advertising <= 14:
#:               :...Price <= 96: High (4/1)
#:                   Price > 96: Medium (27/3)
#Price > 124:
#:...Age > 64: Low (17/1)
#Age <= 64:
#:...ShelveLoc = Bad:
#:...Education > 15: Medium (4)
#:   Education <= 15:
#:   :...Population <= 319: Low (8)
#:       Population > 319:
#:       :...Age <= 38: Medium (3)
#:           Age > 38: Low (4/1)
#ShelveLoc = Medium:
#:...CompPrice > 123: Medium (34/2)
#CompPrice <= 123:
#:...Advertising <= 0: Low (4)
#Advertising > 0:
#:...Price <= 133: Medium (6/1)
#Price > 133: Low (2)
#Evaluation on training data (301 cases):
#Decision Tree   
#----------------  
#Size      Errors  
#31   31(10.3%)   <<
#(a)   (b)   (c)    <-classified as
#----  ----  ----
#46    12          (a): class Low
#6    175     3    (b): class Medium
#      10    49    (c): class High
#Attribute usage:
#100.00%	Price
#100.00%	ShelveLoc
#63.79%	Age
#60.80%	CompPrice
#26.58%	US
#19.60%	Advertising
#18.27%	Education
#8.97%	Population
#Time: 0.0 secs

# Plot the Decision Tree
windows ()
plot (model)

#making prediction by using above training model on test data, 
#[,2:11means not considering first column "categorySales" which is Y COORDINATE 
pred <- predict.C5.0(model, testing[,2:11])

#compare predicted value to actual value in test data set for y cordinate: species
a <- table(testing$categorySales, pred)

#printing accuracy table
a
#output
#pred
#       Low Medium High
#Low      8     11    0
#Medium   5     46   10
#High     0      7   12

#compute the testing accuracy of model
sum(diag(a))/sum(a)
#[1] 0.6666667 means 66.67% accurate which is low

##CODE FOR ENSEMBLE METHOD TYPE BAGGING OR BOOTSTRAPPING AGGREGATING

#create empty vector c
acc <- c()

#create a for loop to run bagging model 50 times
#next inside for loop
#paritioning data set into test data: 15% and training data set: 85%
#Assigning training data set to variable training1, test data set to variable testing
#assigning c5.0 algorithm to training1 i.e. training data set
#model built is assigned to variable fittree
#model in fittree is used to compare it on test data stored in variable:testing
#compare the value got from test data to actual test data value, store it in variable a
#create a list to store the accuracy values of 50 models and assign to variable acc: acc <- (acc,model1 accuracy, model2 accuracu..till model50 accuracy )
#compute the accuracy of model using formula sum(diag(a))/sum(a)

for(i in 1:50)
{
  inTraininglocal <- createDataPartition(company$categorySales, p=0.85, list = F)
  training <- company[inTraininglocal, ]
  testing <- company[-inTraininglocal, ]
  
  fittree <- C5.0(training$categorySales~., data=training)
  pred <- predict.C5.0(fittree, testing[ ,2:11])
  a <- table(testing$categorySales,pred)
  acc <- c(acc, sum(diag(a))/sum(a))
}

#Summary of accuracy
summary(acc)

#gives accuracy values of all 50 models invidually
acc

#Boosting model under Decision Tree
#Loading iris data set
#paritioning data set into test data: 25% and training data set: 75%
inTraininglocal <- createDataPartition(company$categorySales, p=0.75, list = F)
training <- company[inTraininglocal, ]
testing <- company[-inTraininglocal, ]

#running boosting technique by giving variable "trials" and setting value, here it is set to 10
#Boosting Model using C5.0 Algorithm on Training Data Set.
boostmodel <- C5.0(training$categorySales~., data =training, trials = 10)
summary(boostmodel)

#Evaluation on training data (301 cases):
#  Trial	    Decision Tree   
#-----	  ----------------  
#  Size      Errors  
#0	    36   25( 8.3%)
#1	    20   57(18.9%)
#2	    22   69(22.9%)
#3	    26   59(19.6%)
#4	    28   49(16.3%)
#5	    34   46(15.3%)
#6	    29   68(22.6%)
#7	    29   61(20.3%)
#8	    26   63(20.9%)
#9	    28   55(18.3%)
#boost	          0( 0.0%)   <<
  
#  (a)   (b)   (c)    <-classified as
#----  ----  ----
#  58                (a): class Low
#       184          (b): class Medium
#              59    (c): class High
#Attribute usage:
#  100.00%	Price
#100.00%	ShelveLoc
#99.67%	CompPrice
#99.34%	Age
#96.68%	Advertising
#84.72%	Income
#76.41%	Education
#56.48%	Urban
#52.49%	Population
#49.50%	US
#Time: 0.0 secs

#next is to combine bagging and boosting model.
#with for loop we create bagging model, inside for loop of bagging model, 
#apply boosting model code
for(i in 1:50)
{
  inTraininglocal <- createDataPartition(company$categorySales, p=0.85, list = F)
  training <- company[inTraininglocal, ]
  testing <- company[-inTraininglocal, ]
  
  fittree <- C5.0(training$categorySales~., data=training, trials = 10)
  pred <- predict.C5.0(fittree, testing[ ,2:11])
  a <- table(testing$categorySales,pred)
  acc <- c(acc, sum(diag(a))/sum(a))
}

#Summary of accuracy
summary(acc)
#Ouput
#  Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.5345  0.6207  0.6552  0.6597  0.7069  0.7931 

#gives accuracy values of all 50 models invidually
acc
