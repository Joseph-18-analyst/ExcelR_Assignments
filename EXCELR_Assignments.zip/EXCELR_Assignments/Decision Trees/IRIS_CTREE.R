#BUISNESS PROBLEM
#Build a decision tree for the 'iris' data with function 'ctree()' in package "party".
#The iris is a built-in dataset in R and looks like this:

#Installing packages caret required for paritioning
install.packages("caret")
library(caret)

# Package "ggplot2" is required for Plotting GGPLOT and ACF Plot
install.packages ("ggplot2")
library(ggplot2)

#installing packages for decision tree using package party
install.packages("party")
library(party)

#loading iris dataset
iris1 <- iris

#iris dataset has 150 observations and 5 dimensions/variables
View(iris1)

#paritioning data set into test data: 25% and training data set: 75%
inTraininglocal <- createDataPartition(iris1$Species, p = 0.75, list = F)

#Assigning training data set to variable training, test data set to variable testing
training <- iris[inTraininglocal,]
testing <- iris[-inTraininglocal,]


#applyging decision ctree() function on training data set 
#ctree parameters ctree(Y~x1+x2+x3..., data = <data-set>) or
#ctree parameters ctree(y~.,data =<data-set>)
model <- ctree(training$Species~., data =training)

#making prediction by using above training model on test data, [,-5] means not considering last column "species" which is Y COORDINATE 
pred <- predict(model, testing[,-5])

#compare predicted value to actual value in test data set for y cordinate: species
a <- table(testing$Species, pred)

#printing accuracy table stored in variable a
a

#pred
#           setosa versicolor virginica
#setosa         12          0         0
#versicolor      0         12         0
#virginica       0          1        11


#compute the testing accuracy of model
sum(diag(a))/sum(a)
#0.9722222
#Accuracy of model is 97.2%

summary(model)


windows()
plot(model)

print(model)
