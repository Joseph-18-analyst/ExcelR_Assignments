#BUISNESS PROBLEM
#Forecast the Airlines Passengers data set. Prepare a document for each model explaining 
#how many dummy variables you have created and RMSE value for each model. Finally which model you will use for 
#Forecasting.

#installing packages required to read excel files.
install.packages("readxl")
library(readxl)

#loading airlines dataset
airlinesdata <- read_excel(file.choose())
#data has 96 rows and 2 dimensions/columns

#getting column names of dataset
colnames(airlinesdata)
#[1] "Month"      "Passengers"
#it is time series data with 2 columns month and passengers
#dataset gives details about passenger ridership monthly wise for 8 years starting from 1995 to 2002

#view dataset
View(airlinesdata)

#scatter plot of passengers to check level, trend, seasonality
plot(airlinesdata$Passengers)
#Level is there
#trend: poitive linear trend
#seasonality: multiplicative seasonality
#upward linear trend with multiplicative seasonality

# creating 12 dummy variables which is required to be substituted in forecasting methods
# data is monthly wise, so building 12 dummy variables for 12 months each, capturing each season
# X1, X2 ... X12 - Representing 12 Months
# In the First Row X1 column is 1 and all the columns are 0
# In the Second Row X2 column is 1 and all the other columns are 0 and so on.
# This Pattern Repeats for every 12 rows.
# abb is short form for month variable
x <- data.frame(outer(rep(month.abb, length=96), month.abb, "==") + 0)
View(x)

#renaming column names in x to month names respectively
colnames(x) <- month.abb
View(x)

#binding this column x to dataset
airlinesdata <- cbind(airlinesdata,x)
View(airlinesdata)

#create new column "t" which has values from 1 to 96 .i.e representing 96 rows.
# t represents time index
airlinesdata["t"] <- 1:96
View(airlinesdata)

#creating new column t_square: having squared values of t
airlinesdata["t_square"] <- airlinesdata["t"] * airlinesdata["t"]
View(airlinesdata)

#creating new column log_passengers: log of passenger column values
airlinesdata["log_passengers"] <- log(airlinesdata["Passengers"])

#next let us partition data into training and testing dataset
#since data is monthly wise, testing dataset will 12 monthly values of latest year provided in dataset i.e 2002 year
# training data set is 96 rows - 12= 84: 1 st row- 84th row training data set
#testing data: from 85th row to 96th row,

trainingdata <- airlinesdata[1:84,]
testingdata <- airlinesdata[85:96,]

#next step building various models.

#LINEAR REGRESSION MODEL
# Linear Model -> Passengers ~ t
linearmodel <- lm(Passengers ~ t, data = trainingdata)

summary(linearmodel)
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -55.419 -17.202  -0.705  16.546  88.438 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept) 106.2708     5.9287   17.93   <2e-16 ***
# t             2.1429     0.1212   17.69   <2e-16 ***
#   ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# Residual standard error: 26.93 on 82 degrees of freedom
# Multiple R-squared:  0.7923,	Adjusted R-squared:  0.7898 
# F-statistic: 312.8 on 1 and 82 DF,  p-value: < 2.2e-16

#applying linearmodel on test data set to predict the values
# pred <- predict(linearmodel, testingdata, type = "response")
lm_predict <- data.frame(predict(linearmodel, interval = 'prediction', newdata = testingdata))
View(lm_predict)

#calculating Root Mean Square Error of linear model
#actual value - predcited value: testingdata$Passengers - lm_predict$fit
#na.rm = T , an na value is there it will be removed.
rmse_lm <- sqrt(mean((testingdata$Passengers - lm_predict$fit) ^ 2, na.rm = T))
rmse_lm
#[1] 53.19924

#Building second model: EXPONENTIAL MODEL
# Exponential Model -> Log (Passengers) ~ t
expon_model <- lm(log_passengers ~ t, data = trainingdata)

#summary of model
summary(expon_model)
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.28906 -0.07775 -0.01528  0.07901  0.25104 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept) 4.770262   0.027693  172.26   <2e-16 ***
# t           0.011087   0.000566   19.59   <2e-16 ***
#   ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# Residual standard error: 0.1258 on 82 degrees of freedom
# Multiple R-squared:  0.8239,	Adjusted R-squared:  0.8218 
# F-statistic: 383.7 on 1 and 82 DF,  p-value: < 2.2e-16

#applying expon_model on test data set to predict the values
# pred <- predict(exponmodel, testingdata, type = "response")
expon_predict <- data.frame(predict(expon_model, interval = 'prediction', newdata = testingdata))
View(expon_predict)

#calculating Root Mean Square Error of linear model
#actual value - predcited value: testingdata$Passengers - exp(expon_predict$fit)
#taking exp(expon_predict$fit) because y is log(y), to get y we need to use exponential on fit values
#na.rm = T , an na value is there it will be removed.
rmse_expon <- sqrt(mean((testingdata$Passengers - exp(expon_predict$fit)) ^ 2, na.rm = T))
rmse_expon
#[1] 46.05736

#building third model: QUADRATIC MODEL
# Quadratic Model -> Passengers ~ t + t_square
quad_model <- lm(Passengers ~ t + t_square, data = trainingdata)

#summary of model
summary(quad_model)
# Call:
#   lm(formula = Passengers ~ t + t_square, data = trainingdata)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -56.985 -15.652  -3.801  16.360  83.241 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept) 1.148e+02  8.996e+00  12.758  < 2e-16 ***
#   t           1.549e+00  4.885e-01   3.172  0.00214 ** 
#   t_square    6.982e-03  5.569e-03   1.254  0.21350    
# ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# Residual standard error: 26.83 on 81 degrees of freedom
# Multiple R-squared:  0.7963,	Adjusted R-squared:  0.7912 
# F-statistic: 158.3 on 2 and 81 DF,  p-value: < 2.2e-16

#applying expon_model on test data set to predict the values
# pred <- predict(quadmodel, testingdata, type = "response")
quad_predict <- data.frame(predict(quad_model, interval = 'prediction', newdata = testingdata))

#viewing quad_predict
View(quad_predict)

#calculating RMSE for quad_model
quad_rmse <- sqrt(mean((testingdata$Passengers - quad_predict$fit)^2, na.rm = T))
quad_rmse
#[1] 48.05189

#building next model: ADDITIVE SEASONALITY
#Here time index is not taken instead dummy variables is taken, from jan to november
#building model
adsea_model <- lm(Passengers ~ Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov, data = trainingdata)

#summary of model
summary(adsea_model)
# Call:
#   lm(formula = Passengers ~ Jan + Feb + Mar + Apr + May + Jun + 
#        Jul + Aug + Sep + Oct + Nov, data = trainingdata)
# 
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -91.571 -51.393   2.143  38.464 124.429 
# 
# Coefficients:
#   Estimate Std. Error t value Pr(>|t|)    
# (Intercept)  189.429     21.746   8.711 7.21e-13 ***
# Jan          -20.143     30.753  -0.655    0.515    
# Feb          -19.286     30.753  -0.627    0.533    
# Mar            8.000     30.753   0.260    0.796    
# Apr            1.857     30.753   0.060    0.952    
# May            1.143     30.753   0.037    0.970    
# Jun           25.143     30.753   0.818    0.416    
# Jul           50.143     30.753   1.630    0.107    
# Aug           49.286     30.753   1.603    0.113    
# Sep           24.143     30.753   0.785    0.435    
# Oct           -1.000     30.753  -0.033    0.974    
# Nov          -24.286     30.753  -0.790    0.432    
# ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# Residual standard error: 57.53 on 72 degrees of freedom
# Multiple R-squared:  0.1674,	Adjusted R-squared:  0.04015 
# F-statistic: 1.316 on 11 and 72 DF,  p-value: 0.2337

#predicting this model on test dataset
adsea_predict <- data.frame(predict(adsea_model, interval = 'prediction', newdata = testingdata))

#viewing adsea_predict
View(adsea_predict)

#calculating RMSE for quad_model
adsea_rmse <- sqrt(mean((testingdata$Passengers-adsea_predict$fit)^2, na.rm = T))

adsea_rmse
#[1] 132.8198

#building next model: ADDITIVE SEASONALITY WITH LINEAR
#here time index t and 11 dummy variables monthly wise is considered
adseal_model <- lm(Passengers ~ t+Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov, data = trainingdata)

#summary of model
summary(adseal_model)
# Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# Residual standard error: 13.46 on 71 degrees of freedom
# Multiple R-squared:  0.9551,	Adjusted R-squared:  0.9475 
# F-statistic: 125.8 on 12 and 71 DF,  p-value: < 2.2e-16

#predicting model on testing data
adseal_pred <- data.frame(predict(adseal_model, interval = 'prediction', newdata = testingdata))

#viewing predcition
View(adseal_pred)

#calculating rmse
adseal_rmse <- sqrt(mean((testingdata$Passengers-adseal_pred$fit)^2, na.rm = T))

#rmse
adseal_rmse
#[1] 35.34896

#building next model: ADDITIVE SEASONALITY WITH QUADRATIC
#here time index t, t^2 and 11 dummy variables for month wise is considered
adseaq_model <- lm(Passengers ~ t+t_square+Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov, data = trainingdata)

#summary of model
summary(adseaq_model)
# Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# Residual standard error: 12.81 on 70 degrees of freedom
# Multiple R-squared:  0.9598,	Adjusted R-squared:  0.9524 
# F-statistic: 128.7 on 13 and 70 DF,  p-value: < 2.2e-16

#predicting model on testing data
adseaq_pred <- data.frame(predict(adseaq_model, interval = 'prediction', newdata = testingdata))

#viewing predictions
View(adseaq_pred)

#calculating RMSE
adseaq_rmse <- sqrt(mean((testingdata$Passengers-adseaq_pred$fit)^2, na.rm = T))

adseaq_rmse
#[1] 26.36082

#building next model: MULTIPLICATIVE SEASONALITY
#here log_passengers is considered as Y variable, 11 dummy variables monthly wise is x variables
mulsea_model <- lm(log_passengers ~ Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov, data = trainingdata)

#summary of model
summary(mulsea_model)
# Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# Residual standard error: 0.2941 on 72 degrees of freedom
# Multiple R-squared:  0.1548,	Adjusted R-squared:  0.02568 
# F-statistic: 1.199 on 11 and 72 DF,  p-value: 0.3036

#building prediction model, by testing it on testingdata
mulsea_pred <- data.frame(predict(mulsea_model, interval = 'prediction', newdata = testingdata))

#viewing predictions
View(mulsea_pred)

#calculating RMSE of this model
mulsea_rmse <- sqrt(mean((testingdata$Passengers-exp(mulsea_pred$fit))^2, na.rm = T))

#rmse
mulsea_rmse
#[1] 140.0632

#building next model: MULTIPLICATIVE SEASONALITY WITH LINEAR
#here log_passengers is considered as Y variable. time index t and 11 dummy variables monthly wise is x variables
mulseal_model <- lm(log_passengers ~ t+Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov, data = trainingdata)

#summary of model
summary(mulseal_model)
# Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# Residual standard error: 0.04956 on 71 degrees of freedom
# Multiple R-squared:  0.9763,	Adjusted R-squared:  0.9723 
# F-statistic:   244 on 12 and 71 DF,  p-value: < 2.2e-16

#building prediction model, by predicting it on testing data
mulseal_pred <- data.frame(predict(mulseal_model, interval = 'prediction', newdata = testingdata))

#viewing prediction model
View(mulseal_pred)

#calculating RMSE
mulseal_rmse <- sqrt(mean((testingdata$Passengers - exp(mulseal_pred$fit))^2, na.rm = T))

#rmse
mulseal_rmse
#[1] 10.51917

#building next model: MULTIPLICATIVE SEASONALITY WITH QUADRATIC
#here log_passengers is considered as Y variable. 
#time index t, t_square and 11 dummy variables monthly wise is x variables
mulseaq_model <- lm(log_passengers ~ t+t_square+Jan+Feb+Mar+Apr+May+Jun+Jul+Aug+Sep+Oct+Nov, data = trainingdata)

#summary of model
summary(mulseaq_model)
# Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# Residual standard error: 0.04844 on 70 degrees of freedom
# Multiple R-squared:  0.9777,	Adjusted R-squared:  0.9736 
# F-statistic: 236.1 on 13 and 70 DF,  p-value: < 2.2e-16

#building prediction model, by predicting above model on testing data
mulseaq_pred <- data.frame(predict(mulseaq_model, interval = 'prediction', newdata = testingdata))

#viewing prediction
View(mulseaq_pred)

#calculating RMSE
mulseaq_rmse <- sqrt(mean((testingdata$Passengers - exp(mulseaq_pred$fit))^2, na.rm = T))

#rmse
mulseaq_rmse
#[1] 18.37201


#next creating table containing 2 columns
# model names and respective rmse values
rmse_table <- data.frame ('Model' = c("Linear", "Exponential", "Quadratic", "Additive Season", "Addtive Season + Linear", "Additive Season + Quadratic", "Multiplicative Season", "Multiplicative Season + Linear", "Multiplicative Season + Quadratic"),'RMSE'= c(rmse_lm, rmse_expon, quad_rmse, adsea_rmse, adseal_rmse, adseaq_rmse, mulsea_rmse, mulseal_rmse, mulseaq_rmse))

#view the table
View(rmse_table)

#from above table, it is seen that Multiplicative seasonality + Linear: "mulseal_model" has least RMSE value
#so this is chosen as final model for airlines data

#residual analysis on this model
residual_analysis <- residuals(mulseal_model)

#plotting histogram of residuals (errors)
hist(residual_analysis)
#normal distribution is observed

#ACF plot with lag = 10
acf (residual_analysis, lag =10)
#significant lags are observed

# Building Autoregressive model (ARIMA) on residuals consider lag-1 
# ARIMA  - Auto Regressive Integrated Moving Average
# arima function is executed with 2 arguments
# residue - univariate time series data
# order - A specification of the non-seasonal part of the ARIMA model: the three integer components (p, d, q) are the AR order, 
# the degree of differencing, and the MA order.
#c(1,0,0): here 1 says error value 1 is conisdered with highest correlation
arimaModel <- arima (residual_analysis, order=c(1,0,0))

#structure of arima model
str (arimaModel)

# Let us Generate the ACF Plot with the Max Lag of 15 for the Residuals of ARIMA.
acf (arimaModel$residuals,lag.max = 15)
# None of the Lags are Significant. so stopping at this first level

#predicting next 12 residuals with arimaModel so n.head = 12 is chosen
predResidue <- predict (arima (arimaModel$residuals, order=c(1,0,0)), n.ahead = 12)

# Print the Next 12 Predicted Residuals.
predResidue$pred
# Time Series:
# Start = 85 
# End = 96 
# Frequency = 1 
# [1] -2.650298e-03 -4.729079e-05 -3.570611e-04 -3.201970e-04 -3.245840e-04 -3.240619e-04
# [7] -3.241240e-04 -3.241166e-04 -3.241175e-04 -3.241174e-04 -3.241174e-04 -3.241174e-04

#above residual values need to be added to multiplicative seasonality+linear model forecasted values for accurate prediction