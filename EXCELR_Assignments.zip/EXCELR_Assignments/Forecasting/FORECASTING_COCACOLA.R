#BUISNESS PROBLEM
#Forecast the Coca cola data set. Prepare a document for each model explaining 
#how many dummy variables you have created and RMSE value for each model. Finally which model you will use for 
#Forecasting.

#installing packages to read excel file
install.packages("readxl")
library(readxl)

# Install the Package Required to Perform Transformations
install.packages ("dplyr")
library (dplyr)

#loading dataset
cokedata <- read_excel(file.choose())
#above dataset has 42 rows and 2 dimensions/columns

#getting colnames of dataset
colnames(cokedata)
#[1] "Quarter" "Sales"

#viewing dataset
View(cokedata)
#it is time series data containing 2 columns- Quarter and Sales
#it gives slaes data of coke quarterly wise from year 1985 to 1996, for 10.5 years that is 42 quarters
# 42 quarter sales = 42 rows/observations

#scatter plot of sales to check level, trend, seasonality
plot(cokedata$Sales, type = "o")
#level: is there by default
#trend: linear, positive upward trend
#seasonality: multiplicative seasonality as it does not have constant magnitude throughout

#creating four dummy variables for each quarter, required for substituting in forecasting methods
#q1, q2,q3 and q4 representing four quarters
#first column q1 =1, rest of three quarters will be 0
#second column q2 =0, rest of columns will be 0
#this pattern repeats for all 4 quarters
x <- data_frame(q1 = c(1,0,0,0), q2 = c(0,1,0,0), q3 = c(0,0,1,0), q4 = c(0,0,0,1))
x <- do.call("rbind", replicate(10, x, simplify = FALSE))
x <- rbind(x, c(1,0,0,0))
x <- rbind(x, c(0,1,0,0))

#merging above 4 columns - q1,q2,q3,q4 with cokedataset
cokedata <- cbind(cokedata,x)

#create new column "t" which has values from 1 to 42 .i.e representing 42 rows.
# t represents time index
cokedata["t"] <- 1:42

#creating new column t_square: having squared values of t
cokedata["t_square"] <- cokedata["t"] * cokedata["t"]

#creating new column-log_sales: contains log of sales values
cokedata["log_sales"] <- log(cokedata["Sales"])

#viewing updated cokedataset
View(cokedata)

#next let us partition data into training and testing dataset
#since data is quarterly wise, for test data we need 4 quarters of data
#42 orows - 4 quarters = 38 rows, and 4 rows of test data set
#training data= 1:38 i.e 9 years and 2 quarters, test data = 39:42

trainingdata <- cokedata[1:38, ]
testingdata <- cokedata[39:42, ]

#NEXT STEP: BUILDING VARIOUS MODELS

# 1. LINEAR REGRESSION MODEL
lm_model <- lm(Sales ~ t, data = trainingdata)

#summary of model
summary(lm_model)
# Residuals:
#   Min      1Q  Median      3Q     Max 
# -499.65 -292.80  -17.43  178.54  858.60 
# 
# Coefficients:
#             Estimate Std. Error t value Pr(>|t|)    
# (Intercept) 1490.736    122.247   12.19 2.41e-14 ***
# t             68.070      5.464   12.46 1.29e-14 ***
#   ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# Residual standard error: 369.4 on 36 degrees of freedom
# Multiple R-squared:  0.8117,	Adjusted R-squared:  0.8065 
# F-statistic: 155.2 on 1 and 36 DF,  p-value: 1.291e-14

#applying linearmodel on test data set to predict the values
linear_pred <- data.frame(predict(lm_model, interval = 'prediction', newdata = testingdata))

#view prediction
View(linear_pred)

#calculating rmse for above mode
#na.rm = T , an na value is there it will be removed.
lm_rmse <- sqrt(mean((testingdata$Sales - linear_pred$fit)^2, na.rm = T))

lm_rmse
#[1] 591.5533

#2.EXPONENTIAL MODEL

exp_model <- lm(log_sales ~ t, data = trainingdata)

#summary of model
summary(exp_model)
# Residuals:
#   Min       1Q   Median       3Q      Max 
# -0.21347 -0.10140 -0.01104  0.07500  0.32689 
# 
# Coefficients:
#             Estimate Std. Error t value Pr(>|t|)    
# (Intercept) 7.439351   0.040202  185.05  < 2e-16 ***
# t           0.023745   0.001797   13.21 2.24e-15 ***
#   ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# Residual standard error: 0.1215 on 36 degrees of freedom
# Multiple R-squared:  0.8291,	Adjusted R-squared:  0.8243 
# F-statistic: 174.6 on 1 and 36 DF,  p-value: 2.241e-15

#applying linearmodel on test data set to predict the values
exp_pred <- data.frame(predict(exp_model, interval = 'prediction', newdata = testingdata))

#view the data
View(exp_pred)

#calculating rmse
exp_rmse <- sqrt(mean((testingdata$Sales - exp(exp_pred$fit))^2, na.rm = T))

#rmse
exp_rmse
#[1] 466.248

# 3.QUADRATIC MODEL

quad_model <- lm(Sales ~ t+t_square, data = trainingdata)

#summary of model
summary(quad_model)

# Residuals:
#   Min      1Q  Median      3Q     Max 
# -529.93 -226.33  -34.69  258.31  532.73 
# 
# Coefficients:
#             Estimate Std. Error t value Pr(>|t|)    
# (Intercept) 2014.3738   153.6079  13.114 4.54e-15 ***
# t            -10.4757    18.1635  -0.577    0.568    
# t_square       2.0140     0.4517   4.459 8.13e-05 ***
#   ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# Residual standard error: 299.2 on 35 degrees of freedom
# Multiple R-squared:  0.8799,	Adjusted R-squared:  0.873 
# F-statistic: 128.2 on 2 and 35 DF,  p-value: < 2.2e-16

#applying this model on testingdata to predict values
quad_pred <- data.frame(predict(quad_model, interval = 'prediction', newdata = testingdata))

#viewing predicted values
View(quad_pred)

#calculating RMSE
quad_rmse <- sqrt(mean((testingdata$Sales - quad_pred$fit)^2, na.rm = T))

#rmse
quad_rmse
#[1] 475.5618

# 4.ADDITIVE SEASONALITY
#Here time index is not taken instead dummy variables is taken

addsea_model <- lm(Sales ~ q1+q2+q3+q4, data = trainingdata)

#summary of model
summary(addsea_model)
# Residual standard error: 832.4 on 34 degrees of freedom
# Multiple R-squared:  0.09682,	Adjusted R-squared:  0.01712 
# F-statistic: 1.215 on 3 and 34 DF,  p-value: 0.3192

#applying this model on testing data to predict values
addsea_pred <- data.frame(predict(addsea_model, interval = 'prediction', newdata = testingdata))

#view the prediction model
View(addsea_pred)

#rmse
addsea_rmse <- sqrt(mean((testingdata$Sales - addsea_pred$fit)^2, na.rm = T))

addsea_rmse
#[1] 1860.024

# 5.ADDITIVE SEASONALITY WITH LINEAR
#here time index t and 11 dummy variables monthly wise is considered

addseal_model <- lm(Sales ~ t+q1+q2+q3+q4, data = trainingdata)

#summary of model
summary(addseal_model)
# Residual standard error: 284.2 on 33 degrees of freedom
# Multiple R-squared:  0.8978,	Adjusted R-squared:  0.8855 
# F-statistic: 72.51 on 4 and 33 DF,  p-value: 7.111e-16

#applying above model on testing data to predict values
addseal_pred <- data.frame(predict(addseal_model, interval = 'prediction', newdata = testingdata))

#view the predictions
View(addseal_pred)

#calculating rmse
addseal_rmse <- sqrt(mean((testingdata$Sales - addseal_pred$fit)^2, na.rm = T))

#RMSE
addseal_rmse
#[1] 464.9829

# 6. ADDITITIVE SEASONALITY WITH QUADRATIC
#here time index t, t^2 and 11 dummy variables for month wise is considered

addseaq_model <- lm(Sales ~ t+t_square+q1+q2+q3+q4, data = trainingdata)

#summary of model
summary(addseaq_model)
# Residual standard error: 162.6 on 32 degrees of freedom
# Multiple R-squared:  0.9676,	Adjusted R-squared:  0.9625 
# F-statistic: 190.9 on 5 and 32 DF,  p-value: < 2.2e-16

#applying aobve model to predict values on testingdata
addseaq_pred <- data.frame(predict(addseaq_model, interval = 'prediction', newdata= testingdata))

#view predicted model
View(addseaq_pred)

#calculating RMSE
addseaq_rmse <- sqrt(mean((testingdata$Sales- addseaq_pred$fit)^2, na.rm= T))

#rmse
addseaq_rmse
#[1] 301.738

#7. MULTIPLICATIVE SEASONALITY
#HERE log of sales and 4 dummy variables are considered in building model

mlsea_model <- lm(log_sales ~ q1+q2+q3+q4, data = trainingdata)

#summary of model
summary(mlsea_model)
# Residual standard error: 0.2862 on 34 degrees of freedom
# Multiple R-squared:  0.1041,	Adjusted R-squared:  0.025 
# F-statistic: 1.316 on 3 and 34 DF,  p-value: 0.2851

#applying aobve model on testingdata to predict values
mlsea_pred <- data.frame(predict(mlsea_model, interval = 'prediction', newdata = testingdata))

#view predicted model
View(mlsea_pred)

#calculating rmse
mlsea_rmse <- sqrt(mean((testingdata$Sales - exp(mlsea_pred$fit))^2, na.rm = T))

#rmse
mlsea_rmse
#[1] 1963.39

# 8.MULTIPLICATIVE SEASONALITY WITH LINEAR
# HERE log of sales, time index t and 4 dummy variables are considered in building model

mlseal_model <- lm(log_sales ~ t+q1+q2+q3+q4, data = trainingdata)

#summary of model
summary(mlseal_model)
# Residual standard error: 0.08595 on 33 degrees of freedom
# Multiple R-squared:  0.9216,	Adjusted R-squared:  0.9121 
# F-statistic: 96.92 on 4 and 33 DF,  p-value: < 2.2e-16

#building prediction model by applying above model on testingdata
mlseal_pred <- data.frame(predict(mlseal_model, interval ='prediction', newdata = testingdata))

#view prediction model
View(mlseal_pred)

#calculating RMSE
mlseal_rmse <- sqrt(mean((testingdata$Sales - exp(mlseal_pred$fit))^2, na.rm= T))

#rmse
mlseal_rmse
#[1] 225.5244

# 9.MULTIPLICATIVE SEASONALITY WITH QUADRATIC
# HERE log of sales, time index t, t_square and 4 dummy variables are considered in building model

mlseaq_model <- lm(log_sales ~ t+t_square+q1+q2+q3+q4, data = trainingdata)

#summary of model
summary(mlseaq_model)
# Residual standard error: 0.06665 on 32 degrees of freedom
# Multiple R-squared:  0.9543,	Adjusted R-squared:  0.9471 
# F-statistic: 133.5 on 5 and 32 DF,  p-value: < 2.2e-16

#applying above model on testingdata
mlseaq_pred <- data.frame(predict(mlseaq_model, interval = 'prediction', newdata = testingdata))

#view prediction model
View(mlseaq_pred)

#calculating RMSE
mlseaq_rmse <- sqrt(mean((testingdata$Sales- exp(mlseaq_pred$fit))^2, na.rm = T))

#rmse
mlseaq_rmse
#[1] 581.8457

#next creating table containing 2 columns
# model names and respective rmse values
rmse_table <- data.frame ('Model' = c("Linear", "Exponential", "Quadratic", "Additive Season", "Addtive Season + Linear", "Additive Season + Quadratic", "Multiplicative Season", "Multiplicative Season + Linear", "Multiplicative Season + Quadratic"),'RMSE'= c(lm_rmse, exp_rmse, quad_rmse, addsea_rmse, addseal_rmse, addseaq_rmse, mlsea_rmse, mlseal_rmse, mlseaq_rmse))
View(rmse_table)

#from above table, it is seen that Multiplicative seasonality + Linear: "mlseal_model" has least RMSE value-225.5244
#so this is chosen as final model for coca cola sales data

#performing residual analysis of the above model
#getting residual values
residue <- residuals(mlseal_model)

#histogram of residuals
hist(residue)
#residuals i.e. errors follow normal distribution

# Let us Generated the ACF Plot with the Max Lag of 10 for the Residuals.
acf (residue, lag.max = 10)
#from plot it is seen, Lag 1 and Lag 2 are significant

# By principle of parcimony we will consider lag - 1 (as we have 2 significant lags) 
# Building Autoregressive model (ARIMA) on residuals consider lag-1 
# ARIMA  - Auto Regressive Integrated Moving Average
# arima function is executed with 2 arguments
# residue - univariate time series data
# order - A specification of the non-seasonal part of the ARIMA model: the three integer components (p, d, q) are the AR order, 
# the degree of differencing, and the MA order.
# c(1,0,0) means lag 1 is taken
arimamodel <- arima(residue, order = c(1,0,0))

#structure of arima model
str(arimamodel)

# Let us Generate the ACF Plot with the Max Lag of 15 for the Residuals of ARIMA.
acf(arimamodel$residuals, lag.max = 15)
#none ofl ags are significant

#predicting next 4 residuals with arimaModel so n.head = 4 is chosen
#4 residuals means for 4 quarters
residue_pred <- predict(arima(arimamodel$residuals, order = c(1,0,0)), n.ahead = 4)

# predicted 4 residuals
residue_pred
# $pred
# Time Series:
# Start = 39 
# End = 42 
# Frequency = 1 
# [1] -0.001306689 -0.002484469 -0.002548209 -0.002551659

#these residual values need to be added final forecast model: multiplicative seasonality with linear
#it improves accuracy of model