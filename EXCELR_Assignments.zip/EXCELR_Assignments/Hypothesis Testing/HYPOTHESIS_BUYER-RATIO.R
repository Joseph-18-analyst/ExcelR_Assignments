#buisness problem
#Sales of products in four different regions is tabulated for males and females. 
# Find if male-female buyer rations are similar across regions.


#loading the dataset
buyer_data <- read.csv(file.choose())
#has 2 rows and 5 columns or dimensions

#viewing the dataset
View(buyer_data)

#convert above dataset into table
buyer_table <- rbind(buyer_data[1,-1], buyer_data[2,-1])
rownames(buyer_table) = c("Males", "Females")

#view the table
View(buyer_table)

# We need to Perform Chi Square Test for Association.
# Chi square test because input variables X is discrete in more than 2 categories
# Null Hypothesis - Ho - Male-Female buyer rations are Similar across regions
# Alternate Hypothesis - Ha -  Male-Female buyer rations are Not Similar Across Regions.
chisq.test(buyer_table, correct = FALSE)
# Pearson's Chi-squared test
# 
# data:  buyer_table
# X-squared = 1.5959, df = 3, p-value = 0.6603
# 

chisq.test(buyer_table, correct = TRUE)
# Pearson's Chi-squared test
# 
# data:  buyer_table
# X-squared = 1.5959, df = 3, p-value = 0.6603

chisq.test(buyer_table)
# Pearson's Chi-squared test
# 
# data:  buyer_table
# X-squared = 1.5959, df = 3, p-value = 0.6603

#here P-Value is 0.6603, so it is greater than 0.05 (alpha value)
#accept Null Hypothesis. Fail to reject null hypothesis

#CONCLUSION: MAL AND FEMALE BUYER RATIONS ARE SIMILAR ACROSS 4 REGIONS