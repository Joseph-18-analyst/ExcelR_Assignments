#buisness problem
#TeleCall uses 4 centers around the globe to process customer order forms. 
#They audit a certain %  of the customer order forms. Any error in order form renders it defective 
#and has to be reworked before processing.  The manager wants to check whether 
#the defective %  varies by centre. Please analyze the data at 5% significance level and 
#help the manager draw appropriate inferences

#loading the data set
customer_data <- read.csv(file.choose())
#it has 300 rows and 4 variables/columns/dimensions

#view the data set
View(customer_data)
#row values are of factor type, needs to be converted to numeric format

#getting column names
colnames(customer_data)
#[1] "Phillippines" "Indonesia"    "Malta"        "India"

# Ho - Null Hypothesis - Maintain Status Quo.
# Ha - Alternate Hypothesis

#we will use Chisquare test
# output variable Y is discrete
# input variable is X is also discrete but have more 2 categories (there are 4 categories)

#need to determing from chisquare test
# Null Hypothesis - Ho - Defective percentage does not vary by centres
# Alternate Hypothesis - Ha - Defective percentage does vary by centres

#coverting data into numeric form
#then stack the data into columns using stack function
#first colum to give defective or non efective details, second column to give centre names

customer_data$Phillippines <- as.numeric(customer_data$Phillippines)
customer_data$Indonesia <- as.numeric(customer_data$Indonesia)
customer_data$Malta <- as.numeric(customer_data$Malta)
customer_data$India <- as.numeric(customer_data$India)
stackcustomer_data <- stack(customer_data)
#converting "2" in "Values" column to "0"
stackcustomer_data$values [stackcustomer_data$values == "2"] <- "0"
 #converting values in column values into numeric form
stackcustomer_data$values <- as.numeric(stackcustomer_data$values)

View(stackcustomer_data)
# in stacked data values column "0" denotes Error free and "1" denotes defective

#rename the columns
names(stackcustomer_data) <- c("Defective", "Country")

#getting summary of dataset
table(stackcustomer_data)
# Country
# Defective Phillippines Indonesia Malta India
#       0          271       267   269   280
#       1           29        33    31    20

#performing chisq.test
chisq.test(table(stackcustomer_data))
# Pearson's Chi-squared test
# 
# data:  table(stackcustomer_data)
# X-squared = 3.859, df = 3, p-value = 0.2771

#Here P-value 0.2771 is higher than 0.05(alpha value)
#so accept null hypothesis (Fail to reject null hypothesis)

#CONCLUSION: DEFECTIVE PERCENTAGE IS NOT VARYING ACROSS ALL 4 COUNTRIES, IT IS SIMILAR
