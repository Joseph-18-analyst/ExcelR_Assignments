#BUISNESS PROBLEM
#A F&B manager wants to determine whether there is any significant difference in the diameter of 
#the cutlet between two units. A randomly selected sample of cutlets was collected from both units
#and measured? Analyze the data and draw inferences at 5% significance level. Please state the 
#assumptions and tests that you carried out to check validity of the assumptions.

#loading tthe dataset
cutlet_data <- read.csv(file.choose())
#data set has 35 rows and 2 dimensions or columns

#view the dataset
View(cutlet_data)

# Ho - Null Hypothesis - Maintain Status Quo.
# Ha - Alternate Hypothesis

# here Y is continuous and X is discrete in 2 categories (unit A and unit B)

#first step is to check Y1 and Y2 are normal
#y1 = unit A data
#y2 = unit B data

#normality test
shapiro.test(cutlet_data$Unit.A)
# data:  cutlet_data$Unit.A
# W = 0.96495, p-value = 0.32
#P- Value is 0.32 which is greater than 0.05.
#so accepting Null hypothesis (fail to reject null hypothesis)
# Y1 data is normal

shapiro.test(cutlet_data$Unit.B)
# data:  cutlet_data$Unit.B
# W = 0.97273, p-value = 0.5225
#P- Value is 0.5225 which is greater than 0.05.
#so accepting Null hypothesis (fail to reject null hypothesis)
# Y2 data is normal

#Both Y1 and Y2 are normal.
#next to check if external conditions are same or not
#external conditions are not same in this case for unit A and unit B
#so need to check if variance is equal or not

#variance test
var.test(cutlet_data$Unit.A, cutlet_data$Unit.B)
# F test to compare two variances
# 
# data:  cutlet_data$Unit.A and cutlet_data$Unit.B
# F = 0.70536, num df = 34, denom df = 34, p-value = 0.3136
# alternative hypothesis: true ratio of variances is not equal to 1
# 95 percent confidence interval:
# 0.3560436 1.3974120
# sample estimates:
# ratio of variances 
# 0.7053649 

#here P-Value is 0.3136 which is greater than 0.05
#accepting Null hypothesis (Fail to reject null hypothesis)
#variance is equal between Y1 and Y2

# If Y1 and Y2 Data have Equal Variance, then we need to Perform 2 Sample T Test for Equal Variance.
# 2 Sample T Test for Equal Variance.
# For 2 Sample T Test, we use the function - t.test with the following parameters
# Y1 Data
# Y2 Data
# alternate = "two.sided" - We are checking for equal and unequal Means
# Ho - Null Hypothesis - Equal Means
# Ha - Alternate Hypothesis - Unequal Means
# conf.level - Confidence Level.
t.test(cutlet_data$Unit.A, cutlet_data$Unit.B, alternative = "two.sided", conf.level = 0.95, correct = TRUE)
#output
# Welch Two Sample t-test
# 
# data:  cutlet_data$Unit.A and cutlet_data$Unit.B
# t = 0.72287, df = 66.029, p-value = 0.4723
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#   -0.09654633  0.20613490
# sample estimates:
# mean of x mean of y 
#  7.019091  6.964297

#here P-value 0.4723 is greater than 0.05.
#so accept null hypothesis (Fail to reject Null Hypothesis)

#CONCLUSION: THERE IS NO SIGNIFICANT DIFFERENCE IN DIAMETER OF CUTLETS PRODUCED FROM UNIT A AND UNIT B