#buisness problem
#Fantaloons Sales managers commented that % of males versus females walking in to the store differ 
#based on day of the week. Analyze the data and determine whether there is evidence at 5 % 
#significance level to support this hypothesis.

#loading the dataset
fantloons_data <- read.csv(file.choose())
#has 400 rows and 2 dimensions/columns

#view the dataset
View(fantloons_data)

#Output variable Y is discrete
#input variables X are 2 columns -weekdays and weekends
#input variable is discrete

# Ho - Null Hypothesis - Maintain Status Quo.
# Ha - Alternate Hypothesis

#since we have 1 output discrete variable and 2 input discrete variables, 2 - Proportion test need to be performed
#Null Hypothesis: Ho- percentage of males and females walking into store does not differ based on day of week
#Alternate Hypothesis: Ga- percentage of males and females walking into store differ based on day of week

#data in both columns of data set are of factor type
#need to be converted into numeric format
fantloons_data$Weekdays <- as.numeric(fantloons_data$Weekdays)
fantloons_data$Weekend <- as.numeric(fantloons_data$Weekend)

#stacking the data
stack_fantloons <- stack(fantloons_data)

#viewing the stacked data
View(stack_fantloons)

#renaming columns of dataset
names(stack_fantloons) = c("gender", "week")

#viewing stacked data
View(stack_fantloons)
# here 2 = Male
# here 1 = Female

#summarize the data to get unique value frequencies using table method
table(stack_fantloons)
# week
# gender Weekdays Weekend
#     1      287     233
#     2      113     167

#performing 2 proportion test
prop.test(table(stack_fantloons), alternative = c("two.sided"), conf.level = 0.95, correct = TRUE)
# 2-sample test for equality of proportions with continuity correction
# 
# data:  table(stack_fantloons)
# X-squared = 15.434, df = 1, p-value = 8.543e-05
# alternative hypothesis: two.sided
# 95 percent confidence interval:
#   0.07398567 0.22271763
# sample estimates:
#   prop 1    prop 2 
# 0.5519231 0.4035714 

#here P-Value is 8.543e-05 which is less than 0.05 (alpha value)
#reject null hypothese (fail to accept null hypothesis)

#CONCLUSION: PERCENTAGE OF MALES AND FEMALES WALKING INTO STORES DOES DIFFER DURING WEEKDAYS AND WEEKENDS
