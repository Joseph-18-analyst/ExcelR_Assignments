#buisness problem
#A hospital wants to determine whether there is any difference in the average Turn Around Time 
#(TAT) of reports of the laboratories on their preferred list. They collected a random sample and 
#recorded TAT for reports of 4 laboratories. TAT is defined as sample collected to report dispatch.

#Analyze the data and determine whether there is any difference in average TAT among the different 
#laboratories at 5% significance level.

# This Package is required to Perform Normality Test on Stacked Data - Anderson Darling Test.
install.packages ("nortest")
library (nortest)

# This Package is required to Perform Variance Test on Stacked Data - Levene's Test
install.packages ("car")
library (car)


#loading the dataset
lab_data <- read.csv(file.choose())
#contains 120 rows and 4 variables/dimensions

#view the dataset
View(lab_data)
# Ho - Null Hypothesis - Maintain Status Quo.
# Ha - Alternate Hypothesis

# Here 
# Y is Continuous
# X is Discrete in 4 Categories (Laboratory 1, Laboratory 2, Laboratory 3, Laboratory 4)

#performing normality- Shapiro test on all y values
#Y1 = Laboratory.1
#Y2 = Laboratory.2
#Y3 = Laboratory.3
#Y4 = Laboratory.4


#normality test for Y1
shapiro.test(lab_data$Laboratory.1)
# data:  lab_data$Laboratory.1
# W = 0.99018, p-value = 0.5508
# p Value is 0.5508 which is greater than 0.05
# So accept Null Hypothesis- fail to reject Null hypothesis
# Y1 data is normal.

#normality test for Y2
shapiro.test(lab_data$Laboratory.2)
# data:  lab_data$Laboratory.2
# W = 0.99363, p-value = 0.8637
# p Value is 0.8637 which is greater than 0.05
# So accept Null Hypothesis- fail to reject Null hypothesis
# Y2 data is normal.

#normality test for Y3
shapiro.test(lab_data$Laboratory.3)
# data:  lab_data$Laboratory.3
# W = 0.98863, p-value = 0.4205
# p Value is 0.4205 which is greater than 0.05
# So accept Null Hypothesis- fail to reject Null hypothesis
# Y3 data is normal.

#normality test for y4
shapiro.test(lab_data$Laboratory.4)
# data:  lab_data$Laboratory.4
# W = 0.99138, p-value = 0.6619
# p Value is 0.6619 which is greater than 0.05
# So accept Null Hypothesis- fail to reject Null hypothesis
# Y4 data is normal.

# Y1, Y2 ,Y3 and Y4 are normal

#next is to check the variance in Y1, Y2, Y3 and Y4
# first stacking the dataset using stack method
stacked_labdata <- stack (lab_data)
# 4 columns of y1, y2,y3 and y4 values will be merged to one column and second column ind- indicates 
# names of column y1 or y2 or y3 or y4 corresponding to values


#view the stacked data
View(stacked_labdata)

# We can also perform Normality Test on Stacked Data
ad.test (stacked_labdata$values)
# Anderson-Darling normality test
# data:  stacked_labdata$values
# A = 0.7495, p-value = 0.05072
#here P-Value is 0.05072 and is greater than 0.05
#accepting Null hypothesis. Fail to reject Null hypothesis
#Y1, Y2, Y3 and Y4 ARE NORMAL

#performing variance test - Levene's test on stacked data
#have to use Levene's test, var.test function cannot take more than 2 Y variables.
leveneTest(stacked_labdata$values ~ stacked_labdata$ind, data = stacked_labdata)
# Levene's Test for Homogeneity of Variance (center = median)
# #        Df F value  Pr(>F)  
# # group   3  2.5996 0.05161 .
# #       476                  
# # ---
# # Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

#here P- Value is 0.05161, that is greater than 0.05
#So accept Null hypothesis, Fail to reject null hypothesis
#variances between Y1, Y2, Y3 and Y4 are equal

#since variance is Y1, Y2, Y3, Y4 are equal we need to perform 1 way anova test
#Null Hypothesis: Ho Average TAT between all 4 laboratories are same
#Alternate Hypothesis: Ha There is difference in average TAT between 4 laboratories
# To Perform One Way Anova Test, we use the function 'aov' with the following parameters
# aov (Stacked Values ~ Stacked Ind, data = Stacked Data Set)

anova_test <- aov(stacked_labdata$values ~ stacked_labdata$ind, data = stacked_labdata)

#summary of anova test
summary(anova_test)
#                       Df Sum Sq Mean Sq F value Pr(>F)    
# stacked_labdata$ind   3  79979   26660   118.7 <2e-16 ***
#   Residuals           476 106905     225                   
# ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

#here P-Value is <2e-16 it means it is lesser than 0.05
#Reject Null hypothesis. Accept Alternate hypothesis

#There is difference in average TAT between 4 laboratories at 5% significant level