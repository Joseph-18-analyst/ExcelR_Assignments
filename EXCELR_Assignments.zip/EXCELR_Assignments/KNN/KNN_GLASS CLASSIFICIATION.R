#BUISNESS PROBLEM
#Prepare a model for glass classification using KNN

#package is required for data partitioning/slicing
install.packages("caret")
library(caret)

#package is required for KNN
install.packages("class")
library(class)

#package is required for knn, , for cross tables
install.packages("gmodels")
library(gmodels)

#Loading dataset "glass"
knnglass <- glass

#view the dataset
View(knnglass)

#getting column names for dataset
colnames(knnglass)
# [1] "RI"   "Na"   "Mg"   "Al"   "Si"   "K"    "Ca"   "Ba"   "Fe"   "Type"

#output variable y is column "Type" which is required to glass classification
#table of column "type"
#table finds out the unique values and its frequencies (number of times unique value appears in column)
table(knnglass$Type)
# 1  2  3  5  6  7 
# 70 76 17 13  9 29 

#summary of dataset
summary(knnglass)
# RI              Na              Mg              Al              Si              K         
# Min.   :1.511   Min.   :10.73   Min.   :0.000   Min.   :0.290   Min.   :69.81   Min.   :0.0000  
# 1st Qu.:1.517   1st Qu.:12.91   1st Qu.:2.115   1st Qu.:1.190   1st Qu.:72.28   1st Qu.:0.1225  
# Median :1.518   Median :13.30   Median :3.480   Median :1.360   Median :72.79   Median :0.5550  
# Mean   :1.518   Mean   :13.41   Mean   :2.685   Mean   :1.445   Mean   :72.65   Mean   :0.4971  
# 3rd Qu.:1.519   3rd Qu.:13.82   3rd Qu.:3.600   3rd Qu.:1.630   3rd Qu.:73.09   3rd Qu.:0.6100  
# Max.   :1.534   Max.   :17.38   Max.   :4.490   Max.   :3.500   Max.   :75.41   Max.   :6.2100  
# Ca               Ba              Fe               Type     
# Min.   : 5.430   Min.   :0.000   Min.   :0.00000   Min.   :1.00  
# 1st Qu.: 8.240   1st Qu.:0.000   1st Qu.:0.00000   1st Qu.:1.00  
# Median : 8.600   Median :0.000   Median :0.00000   Median :2.00  
# Mean   : 8.957   Mean   :0.175   Mean   :0.05701   Mean   :2.78  
# 3rd Qu.: 9.172   3rd Qu.:0.000   3rd Qu.:0.10000   3rd Qu.:3.00  
# Max.   :16.190   Max.   :3.150   Max.   :0.51000   Max.   :7.00 

#data needs to be normalized as variables in each column is of different scale

#first finding structure of dataset
str(knnglass)
# 'data.frame':	214 obs. of  10 variables:
#   $ RI  : num  1.52 1.52 1.52 1.52 1.52 ...
# $ Na  : num  13.6 13.9 13.5 13.2 13.3 ...
# $ Mg  : num  4.49 3.6 3.55 3.69 3.62 3.61 3.6 3.61 3.58 3.6 ...
# $ Al  : num  1.1 1.36 1.54 1.29 1.24 1.62 1.14 1.05 1.37 1.36 ...
# $ Si  : num  71.8 72.7 73 72.6 73.1 ...
# $ K   : num  0.06 0.48 0.39 0.57 0.55 0.64 0.58 0.57 0.56 0.57 ...
# $ Ca  : num  8.75 7.83 7.78 8.22 8.07 8.07 8.17 8.24 8.3 8.4 ...
# $ Ba  : num  0 0 0 0 0 0 0 0 0 0 ...
# $ Fe  : num  0 0 0 0 0 0.26 0 0 0 0.11 ...
# $ Type: int  1 1 1 1 1 1 1 1 1 1 ...

#changing date type of column type to factor data type as it is in integer data type
knnglass$Type <- factor(knnglass$Type)

#structure of updated dataset
str(knnglass)
# 'data.frame':	214 obs. of  10 variables:
#   $ RI  : num  1.52 1.52 1.52 1.52 1.52 ...
# $ Na  : num  13.6 13.9 13.5 13.2 13.3 ...
# $ Mg  : num  4.49 3.6 3.55 3.69 3.62 3.61 3.6 3.61 3.58 3.6 ...
# $ Al  : num  1.1 1.36 1.54 1.29 1.24 1.62 1.14 1.05 1.37 1.36 ...
# $ Si  : num  71.8 72.7 73 72.6 73.1 ...
# $ K   : num  0.06 0.48 0.39 0.57 0.55 0.64 0.58 0.57 0.56 0.57 ...
# $ Ca  : num  8.75 7.83 7.78 8.22 8.07 8.07 8.17 8.24 8.3 8.4 ...
# $ Ba  : num  0 0 0 0 0 0 0 0 0 0 ...
# $ Fe  : num  0 0 0 0 0 0.26 0 0 0 0.11 ...
# $ Type: Factor w/ 6 levels "1","2","3","5",..: 1 1 1 1 1 1 1 1 1 1 ...

#table or proportions of unique values in column "type"
round(prop.table(table(knnglass$Type)) * 100, digits =2)
#   1     2     3     5     6     7 
# 32.71 35.51  7.94  6.07  4.21 13.55 

#applying normalizing function to normalize the values of all columns except last column type
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}

#ranges of normalized values will be in 0 to 1
knnglass_normal <- as.data.frame(lapply(knnglass[,1:9], normalize))

#get updated summary of dataset
summary(knnglass_normal)
# RI               Na               Mg               Al               Si        
# Min.   :0.0000   Min.   :0.0000   Min.   :0.0000   Min.   :0.0000   Min.   :0.0000  
# 1st Qu.:0.2358   1st Qu.:0.3274   1st Qu.:0.4710   1st Qu.:0.2804   1st Qu.:0.4411  
# Median :0.2867   Median :0.3865   Median :0.7751   Median :0.3333   Median :0.5321  
# Mean   :0.3167   Mean   :0.4027   Mean   :0.5979   Mean   :0.3598   Mean   :0.5073  
# 3rd Qu.:0.3515   3rd Qu.:0.4654   3rd Qu.:0.8018   3rd Qu.:0.4174   3rd Qu.:0.5853  
# Max.   :1.0000   Max.   :1.0000   Max.   :1.0000   Max.   :1.0000   Max.   :1.0000  
# K                 Ca               Ba                Fe        
# Min.   :0.00000   Min.   :0.0000   Min.   :0.00000   Min.   :0.0000  
# 1st Qu.:0.01973   1st Qu.:0.2612   1st Qu.:0.00000   1st Qu.:0.0000  
# Median :0.08937   Median :0.2946   Median :0.00000   Median :0.0000  
# Mean   :0.08004   Mean   :0.3278   Mean   :0.05557   Mean   :0.1118  
# 3rd Qu.:0.09823   3rd Qu.:0.3478   3rd Qu.:0.00000   3rd Qu.:0.1961  
# Max.   :1.00000   Max.   :1.0000   Max.   :1.00000   Max.   :1.0000  

#performing cbind to bind the columns of dataset knnglass_normal and knnglass
knnglass <- cbind(knnglass_normal, knnglass$Type)

#view updated knnglass dataset
View(knnglass)

#renaming column 10 to type
names(knnglass) [10] <- "Type"

#checking form issing values
anyNA(knnglass)
#[1] FALSE

#creating data partition for training and test data set
knnpartition <- createDataPartition(knnglass$Type, p = 0.75, list = F)
trainingdata <- knnglass[knnpartition, ]
testingdata <- knnglass[-knnpartition, ]


#dimensions of training dataset
dim(trainingdata)
#[1] 162  10

#dimensions of testing dataset
dim(testingdata)
#[1] 52 10

#creating new variable and assign last column "type" of trainingdata to it
trainingdatasetlabels <- trainingdata[,10]

#creating new variable and assign last column "type" of trainingdata to it
testdatasetlabels <- testingdata[,10]

#building the model "knnmodel"using KNN function
# knn function takes the following arguments
# train - matrix or data frame of training set cases.
# test - matrix or data frame of test set cases.
# k - number of neighbours considered.
# cl - factor of true classifications of training set.
# We are considering 'k' value of 4.
knnmodel <- knn(train = trainingdata, test = testingdata, cl= trainingdatasetlabels, k = 4)

#creating crosstable to compute accuracy
crsTable <- CrossTable (x = testdatasetlabels, y = knnmodel, prop.chisq=FALSE, prop.c = FALSE, prop.r = FALSE)


#computing accuracy of model
sum (diag(crsTable$t)) / sum (crsTable$t)
#[1] 1
#model is 100% accurate

#trying with different values of k, k= 10
knnmodel <- knn(train = trainingdata, test = testingdata, cl= trainingdatasetlabels, k = 10)
crsTable <- CrossTable (x = testdatasetlabels, y = knnmodel, prop.chisq=FALSE, prop.c = FALSE, prop.r = FALSE)
sum (diag(crsTable$t)) / sum (crsTable$t)
#[1] 1
#model is 100% accurate


#trying with different values of k, k= 20
knnmodel <- knn(train = trainingdata, test = testingdata, cl= trainingdatasetlabels, k = 20)
crsTable <- CrossTable (x = testdatasetlabels, y = knnmodel, prop.chisq=FALSE, prop.c = FALSE, prop.r = FALSE)
sum (diag(crsTable$t)) / sum (crsTable$t)
#[1] 0.8653846
#model is 86.54% accurate

#trying with different values of k, k= 30
knnmodel <- knn(train = trainingdata, test = testingdata, cl= trainingdatasetlabels, k = 30)
crsTable <- CrossTable (x = testdatasetlabels, y = knnmodel, prop.chisq=FALSE, prop.c = FALSE, prop.r = FALSE)
sum (diag(crsTable$t)) / sum (crsTable$t)
#[1] 0.7307692
#model is 73.07% accurate