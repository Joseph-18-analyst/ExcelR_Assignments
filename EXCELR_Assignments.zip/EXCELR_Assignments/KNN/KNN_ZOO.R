#BUISNESS PROBLEM
#Implement a KNN model to classify the animals in to categories. 

#package is required for data partitioning/slicing
install.packages("caret")
library(caret)

#package is required for KNN
install.packages("class")
library(class)

#package is required for knn, , for cross tables
install.packages("gmodels")
library(gmodels)

#Loading dataset "ZOO"
knnzoo <- Zoo

#view the datset
View(knnzoo)

#exclude first column as it contains animal names
knnzoo <- knnzoo[,-1]

#view updated knnzoo dataset
View(knnzoo)

#get the columnnames for dataset
colnames(knnzoo)
# [1] "hair"     "feathers" "eggs"     "milk"     "airborne" "aquatic"  "predator" "toothed" 
# [9] "backbone" "breathes" "venomous" "fins"     "legs"     "tail"     "domestic" "catsize" 
# [17] "type" 

#output variable y is column "type" which is required to classify animals into categories
#table of column "type"
#table finds out the unique values and its frequencies (number of times unique value appears in column)
table(knnzoo$type)
# 1  2  3  4  5  6  7 
# 41 20  5 13  4  8 10

#getting structure of datset
str(knnzoo)
# 'data.frame':	101 obs. of  17 variables:
#   $ hair    : int  1 1 0 1 1 1 1 0 0 1 ...
# $ feathers: int  0 0 0 0 0 0 0 0 0 0 ...
# $ eggs    : int  0 0 1 0 0 0 0 1 1 0 ...
# $ milk    : int  1 1 0 1 1 1 1 0 0 1 ...
# $ airborne: int  0 0 0 0 0 0 0 0 0 0 ...
# $ aquatic : int  0 0 1 0 0 0 0 1 1 0 ...
# $ predator: int  1 0 1 1 1 0 0 0 1 0 ...
# $ toothed : int  1 1 1 1 1 1 1 1 1 1 ...
# $ backbone: int  1 1 1 1 1 1 1 1 1 1 ...
# $ breathes: int  1 1 0 1 1 1 1 0 0 1 ...
# $ venomous: int  0 0 0 0 0 0 0 0 0 0 ...
# $ fins    : int  0 0 1 0 0 0 0 1 1 0 ...
# $ legs    : int  4 4 0 4 4 4 4 0 0 4 ...
# $ tail    : int  0 1 1 0 1 1 1 1 1 0 ...
# $ domestic: int  0 0 0 0 0 0 1 1 0 1 ...
# $ catsize : int  1 1 0 1 1 1 1 0 0 0 ...
# $ type    : int  1 1 4 1 1 1 1 4 4 1 ...

#y variable- column type is in intege r type, need to converted to factor data type
knnzoo$type <- factor(knnzoo$type)

#structure of updated dataset
str(knnzoo)
# 'data.frame':	101 obs. of  17 variables:
#   $ hair    : int  1 1 0 1 1 1 1 0 0 1 ...
# $ feathers: int  0 0 0 0 0 0 0 0 0 0 ...
# $ eggs    : int  0 0 1 0 0 0 0 1 1 0 ...
# $ milk    : int  1 1 0 1 1 1 1 0 0 1 ...
# $ airborne: int  0 0 0 0 0 0 0 0 0 0 ...
# $ aquatic : int  0 0 1 0 0 0 0 1 1 0 ...
# $ predator: int  1 0 1 1 1 0 0 0 1 0 ...
# $ toothed : int  1 1 1 1 1 1 1 1 1 1 ...
# $ backbone: int  1 1 1 1 1 1 1 1 1 1 ...
# $ breathes: int  1 1 0 1 1 1 1 0 0 1 ...
# $ venomous: int  0 0 0 0 0 0 0 0 0 0 ...
# $ fins    : int  0 0 1 0 0 0 0 1 1 0 ...
# $ legs    : int  4 4 0 4 4 4 4 0 0 4 ...
# $ tail    : int  0 1 1 0 1 1 1 1 1 0 ...
# $ domestic: int  0 0 0 0 0 0 1 1 0 1 ...
# $ catsize : int  1 1 0 1 1 1 1 0 0 0 ...
# $ type    : Factor w/ 7 levels "1","2","3","4",..: 1 1 4 1 1 1 1 4 4 1 ...

#table or proportions of unique values in column "type"
round(prop.table(table(knnzoo$type)) * 100, digits =2)
#    1     2     3     4     5     6     7 
# 40.59 19.80  4.95 12.87  3.96  7.92  9.90 

#summary of datset
summary(knnzoo)
# hair           feathers          eggs             milk           airborne     
# Min.   :0.0000   Min.   :0.000   Min.   :0.0000   Min.   :0.0000   Min.   :0.0000  
# 1st Qu.:0.0000   1st Qu.:0.000   1st Qu.:0.0000   1st Qu.:0.0000   1st Qu.:0.0000  
# Median :0.0000   Median :0.000   Median :1.0000   Median :0.0000   Median :0.0000  
# Mean   :0.4257   Mean   :0.198   Mean   :0.5842   Mean   :0.4059   Mean   :0.2376  
# 3rd Qu.:1.0000   3rd Qu.:0.000   3rd Qu.:1.0000   3rd Qu.:1.0000   3rd Qu.:0.0000  
# Max.   :1.0000   Max.   :1.000   Max.   :1.0000   Max.   :1.0000   Max.   :1.0000  
# 
# aquatic          predator         toothed         backbone         breathes     
# Min.   :0.0000   Min.   :0.0000   Min.   :0.000   Min.   :0.0000   Min.   :0.0000  
# 1st Qu.:0.0000   1st Qu.:0.0000   1st Qu.:0.000   1st Qu.:1.0000   1st Qu.:1.0000  
# Median :0.0000   Median :1.0000   Median :1.000   Median :1.0000   Median :1.0000  
# Mean   :0.3564   Mean   :0.5545   Mean   :0.604   Mean   :0.8218   Mean   :0.7921  
# 3rd Qu.:1.0000   3rd Qu.:1.0000   3rd Qu.:1.000   3rd Qu.:1.0000   3rd Qu.:1.0000  
# Max.   :1.0000   Max.   :1.0000   Max.   :1.000   Max.   :1.0000   Max.   :1.0000  
# 
# venomous            fins             legs            tail           domestic     
# Min.   :0.00000   Min.   :0.0000   Min.   :0.000   Min.   :0.0000   Min.   :0.0000  
# 1st Qu.:0.00000   1st Qu.:0.0000   1st Qu.:2.000   1st Qu.:0.0000   1st Qu.:0.0000  
# Median :0.00000   Median :0.0000   Median :4.000   Median :1.0000   Median :0.0000  
# Mean   :0.07921   Mean   :0.1683   Mean   :2.842   Mean   :0.7426   Mean   :0.1287  
# 3rd Qu.:0.00000   3rd Qu.:0.0000   3rd Qu.:4.000   3rd Qu.:1.0000   3rd Qu.:0.0000  
# Max.   :1.00000   Max.   :1.0000   Max.   :8.000   Max.   :1.0000   Max.   :1.0000  
# 
# catsize       type  
# Min.   :0.0000   1:41  
# 1st Qu.:0.0000   2:20  
# Median :0.0000   3: 5  
# Mean   :0.4356   4:13  
# 3rd Qu.:1.0000   5: 4  
# Max.   :1.0000   6: 8  
#                 7:10

#scale of column values for legs column is different to other column values. Maximum value is 8.00
#so scale of these value in column legs need to bought similar values compared to other column values
# so next step is to normaize the dataset using normalize function
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}

#ranges of normalized values will be in 0 to 1
knnzoo_normal <- as.data.frame(lapply(knnzoo[,1:16], normalize))


#get updated summary of normlaized data
summary(knnzoo_normal)
# hair           feathers          eggs             milk           airborne     
# Min.   :0.0000   Min.   :0.000   Min.   :0.0000   Min.   :0.0000   Min.   :0.0000  
# 1st Qu.:0.0000   1st Qu.:0.000   1st Qu.:0.0000   1st Qu.:0.0000   1st Qu.:0.0000  
# Median :0.0000   Median :0.000   Median :1.0000   Median :0.0000   Median :0.0000  
# Mean   :0.4257   Mean   :0.198   Mean   :0.5842   Mean   :0.4059   Mean   :0.2376  
# 3rd Qu.:1.0000   3rd Qu.:0.000   3rd Qu.:1.0000   3rd Qu.:1.0000   3rd Qu.:0.0000  
# Max.   :1.0000   Max.   :1.000   Max.   :1.0000   Max.   :1.0000   Max.   :1.0000  
# aquatic          predator         toothed         backbone         breathes     
# Min.   :0.0000   Min.   :0.0000   Min.   :0.000   Min.   :0.0000   Min.   :0.0000  
# 1st Qu.:0.0000   1st Qu.:0.0000   1st Qu.:0.000   1st Qu.:1.0000   1st Qu.:1.0000  
# Median :0.0000   Median :1.0000   Median :1.000   Median :1.0000   Median :1.0000  
# Mean   :0.3564   Mean   :0.5545   Mean   :0.604   Mean   :0.8218   Mean   :0.7921  
# 3rd Qu.:1.0000   3rd Qu.:1.0000   3rd Qu.:1.000   3rd Qu.:1.0000   3rd Qu.:1.0000  
# Max.   :1.0000   Max.   :1.0000   Max.   :1.000   Max.   :1.0000   Max.   :1.0000  
# venomous            fins             legs             tail           domestic     
# Min.   :0.00000   Min.   :0.0000   Min.   :0.0000   Min.   :0.0000   Min.   :0.0000  
# 1st Qu.:0.00000   1st Qu.:0.0000   1st Qu.:0.2500   1st Qu.:0.0000   1st Qu.:0.0000  
# Median :0.00000   Median :0.0000   Median :0.5000   Median :1.0000   Median :0.0000  
# Mean   :0.07921   Mean   :0.1683   Mean   :0.3552   Mean   :0.7426   Mean   :0.1287  
# 3rd Qu.:0.00000   3rd Qu.:0.0000   3rd Qu.:0.5000   3rd Qu.:1.0000   3rd Qu.:0.0000  
# Max.   :1.00000   Max.   :1.0000   Max.   :1.0000   Max.   :1.0000   Max.   :1.0000  
# catsize      
# Min.   :0.0000  
# 1st Qu.:0.0000  
# Median :0.0000  
# Mean   :0.4356  
# 3rd Qu.:1.0000  
# Max.   :1.0000

#binding the columns of knnzoo_normal dataset and dataset knnzoo cbind
knnzoo <- cbind(knnzoo_normal, knnzoo$type)

#view updated knnzoo dataset
View(knnzoo)

#renamin column 17 to type
names(knnzoo) [17] <- "type"

#checking form issing values
anyNA(knnzoo)
#[1] FALSE

#creating data partition: training data = 75%, testing data = 25%
knnpartition <- createDataPartition(knnzoo$type, p = 0.75, list = F)
trainingdata <- knnzoo[knnpartition, ]
testinggdata <- knnzoo[-knnpartition, ]

#dimensions of training dataset
dim(trainingdata)
#[1] 77 17

#dimensions of testing dataset
dim(testinggdata)
#[1] 24 17

#creating new variable and assign last column "type" of trainingdata to it
trainingdatasetlabels <- trainingdata[,17]

#creating new variable and assign last column "type" of trainingdata to it
testdatasetlabels <- testinggdata[,17]


#building the model "knnmodel"using KNN function
# knn function takes the following arguments
# train - matrix or data frame of training set cases.
# test - matrix or data frame of test set cases.
# k - number of neighbours considered.
# cl - factor of true classifications of training set.
# We are considering 'k' value of 3.

knnmodel <- knn(train = trainingdata, test = testinggdata, cl= trainingdatasetlabels, k = 4)


#creating crosstable to compute accuracy
crsTable <- CrossTable (x = testdatasetlabels, y = knnmodel, prop.chisq=FALSE, prop.c = FALSE, prop.r = FALSE)

#computing accuracy of model
sum (diag(crsTable$t)) / sum (crsTable$t)
#[1] 0.7916667
#model is 80% accurate

#trying with different values of K
knnmodel <- knn(train = trainingdata, test = testinggdata, cl= trainingdatasetlabels, k = 8)
crsTable <- CrossTable (x = testdatasetlabels, y = knnmodel, prop.chisq=FALSE, prop.c = FALSE, prop.r = FALSE)
sum (diag(crsTable$t)) / sum (crsTable$t)
#[1] 0.6666667
#model is 66.67% accurate with K=8

knnmodel <- knn(train = trainingdata, test = testinggdata, cl= trainingdatasetlabels, k = 10)
crsTable <- CrossTable (x = testdatasetlabels, y = knnmodel, prop.chisq=FALSE, prop.c = FALSE, prop.r = FALSE)
sum (diag(crsTable$t)) / sum (crsTable$t)
#[1] 0.7916667
#model is 80% accurate with k= 10

knnmodel <- knn(train = trainingdata, test = testinggdata, cl= trainingdatasetlabels, k = 25)
crsTable <- CrossTable (x = testdatasetlabels, y = knnmodel, prop.chisq=FALSE, prop.c = FALSE, prop.r = FALSE)
sum (diag(crsTable$t)) / sum (crsTable$t)
#[1] 0.625
#model is 62.5% accurate with k=25

knnmodel <- knn(train = trainingdata, test = testinggdata, cl= trainingdatasetlabels, k = 35)
crsTable <- CrossTable (x = testdatasetlabels, y = knnmodel, prop.chisq=FALSE, prop.c = FALSE, prop.r = FALSE)
sum (diag(crsTable$t)) / sum (crsTable$t)
#[1] 0.4583333
#model is 45.833% accurate with K=35