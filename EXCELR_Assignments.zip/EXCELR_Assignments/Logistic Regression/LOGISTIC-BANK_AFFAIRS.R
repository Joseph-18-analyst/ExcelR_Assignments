#BUISNESS PROBLEM
# I have a dataset containing family information of married couples, which have around 10 variables & 600+ observations. 
# Independent variables are ~ gender, age, years married, children, religion etc.
# I have one response variable which is number of extra marital affairs.
# Now, I want to know what all factor influence the chances of extra marital affair.
# Since extra marital affair is a binary variable (either a person will have or not), 
# so we can fit logistic regression model here to predict the probability of extra marital affair.
# 
# install.packages('AER')
# data(Affairs,package="AER")

install.packages("AER")
library(AER)

#required for ROCR curve
install.packages("ROCR")
library(ROCR)

#package required for arithmetic operations
install.packages("dplyr")
library(dplyr)
library(plyr)

install.packages("caret")
install.packages("e1071", dependencies=TRUE)
library(caret)

#loading dataset
data(Affairs,package="AER")

#viewing dataset
#ith as 601 rows and 9 dimensions/columns
View(Affairs)

#structure of dataset affairs
str(Affairs)
# 'data.frame':	601 obs. of  9 variables:
# $ affairs      : num  0 0 0 0 0 0 0 0 0 0 ...
# $ gender       : Factor w/ 2 levels "female","male": 2 1 1 2 2 1 1 2 1 2 ...
# $ age          : num  37 27 32 57 22 32 22 57 32 22 ...
# $ yearsmarried : num  10 4 15 15 0.75 1.5 0.75 15 15 1.5 ...
# $ children     : Factor w/ 2 levels "no","yes": 1 1 2 2 1 1 1 2 2 1 ...
# $ religiousness: int  3 4 1 5 2 2 2 2 4 4 ...
# $ education    : num  18 14 12 18 17 17 12 14 16 14 ...
# $ occupation   : int  7 6 1 6 6 5 1 4 1 4 ...
# $ rating       : int  4 4 4 5 3 5 3 4 2 5 ...

#convert the affairs column into factor column with 2 factors - yes/no
Affairs$affairs[Affairs$affairs > 0] <- "yes"
Affairs$affairs[Affairs$affairs == 0] <- "no"
Affairs$affairs <- factor(Affairs$affairs)

#str of dataset
str(Affairs)
# 'data.frame':	601 obs. of  9 variables:
# $ affairs      : Factor w/ 2 levels "no","yes": 1 1 1 1 1 1 1 1 1 1 ...
# $ gender       : Factor w/ 2 levels "female","male": 2 1 1 2 2 1 1 2 1 2 ...
# $ age          : num  37 27 32 57 22 32 22 57 32 22 ...
# $ yearsmarried : num  10 4 15 15 0.75 1.5 0.75 15 15 1.5 ...
# $ children     : Factor w/ 2 levels "no","yes": 1 1 2 2 1 1 1 2 2 1 ...
# $ religiousness: int  3 4 1 5 2 2 2 2 4 4 ...
# $ education    : num  18 14 12 18 17 17 12 14 16 14 ...
# $ occupation   : int  7 6 1 6 6 5 1 4 1 4 ...
# $ rating       : int  4 4 4 5 3 5 3 4 2 5 ...

#getting number of "yes" and "no" entries in column affairs using table method
table(Affairs$affairs)
# no yes 
# 451 150

#get the colnmaes required to build logistic regression model
#affairs is "Y" variable
#rest all columns are "x" variable
colnames(Affairs)
# [1] "affairs"       "gender"        "age"           "yearsmarried"  "children"      "religiousness"
# [7] "education"     "occupation"    "rating" 

#building logisitc regression model glm function, considering all x variables in dataset as inputs
#in function family is set to binomial, as output variable Affairs has 2 facotrs/binomial - Yes or No
affairmodel1 <- glm(affairs ~ ., data = Affairs,  family = "binomial" )

#summary of model
summary(affairmodel1)
# Deviance Residuals: 
#     Min       1Q   Median       3Q      Max  
# -1.5713  -0.7499  -0.5690  -0.2539   2.5191  
# 
# Coefficients:
# Estimate Std. Error z value Pr(>|z|)    
# (Intercept)    1.37726    0.88776   1.551 0.120807    
# gendermale     0.28029    0.23909   1.172 0.241083    
# age           -0.04426    0.01825  -2.425 0.015301 *  
# yearsmarried   0.09477    0.03221   2.942 0.003262 ** 
# childrenyes    0.39767    0.29151   1.364 0.172508    
# religiousness -0.32472    0.08975  -3.618 0.000297 ***
# education      0.02105    0.05051   0.417 0.676851    
# occupation     0.03092    0.07178   0.431 0.666630    
# rating        -0.46845    0.09091  -5.153 2.56e-07 ***
#   ---
# Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# (Dispersion parameter for binomial family taken to be 1)
# 
# Null deviance: 675.38  on 600  degrees of freedom
# Residual deviance: 609.51  on 592  degrees of freedom
# AIC: 627.51
# 
# Number of Fisher Scoring iterations: 4

# 3 coefficients are significant: religiousness, rating, yesmarried, age

#building another LRM leaving out education

affairmodel2 <- glm(affairs ~ Affairs$gender + Affairs$age + Affairs$yearsmarried + Affairs$children + Affairs$religiousness + Affairs$occupation + Affairs$rating, data=Affairs, family = "binomial")
summary(affairmodel2)

# Deviance Residuals: 
#   Min       1Q   Median       3Q      Max  
# -1.5866  -0.7466  -0.5663  -0.2486   2.5072  
# 
# Coefficients:
#   Estimate Std. Error z value Pr(>|z|)    
# (Intercept)            1.62613    0.65831   2.470 0.013505 *  
# Affairs$gendermale     0.29699    0.23524   1.263 0.206767    
# Affairs$age           -0.04397    0.01822  -2.413 0.015804 *  
# Affairs$yearsmarried   0.09454    0.03223   2.933 0.003355 ** 
# Affairs$childrenyes    0.40211    0.29099   1.382 0.167011    
# Affairs$religiousness -0.32647    0.08968  -3.640 0.000272 ***
# Affairs$occupation     0.04407    0.06452   0.683 0.494613    
# Affairs$rating        -0.46235    0.08966  -5.157 2.51e-07 ***
#   ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# (Dispersion parameter for binomial family taken to be 1)
# 
# Null deviance: 675.38  on 600  degrees of freedom
# Residual deviance: 609.68  on 593  degrees of freedom
# AIC: 625.68
# 
# Number of Fisher Scoring iterations: 4

#AIC value of above model is less than previous model with all inputs
#go education variable does not influence reason for extra marital affair

#building another LRM leaving out age and education

affairmodel3 <- glm(affairs ~ Affairs$gender + Affairs$yearsmarried + Affairs$children + Affairs$religiousness + Affairs$occupation + Affairs$rating, data=Affairs, family = "binomial")
summary(affairmodel3)
# Coefficients:
#   Estimate Std. Error z value Pr(>|z|)    
# (Intercept)            0.73165    0.53335   1.372 0.170120    
# Affairs$gendermale     0.18586    0.22880   0.812 0.416603    
# Affairs$yearsmarried   0.03787    0.02222   1.705 0.088269 .  
# Affairs$childrenyes    0.42619    0.28923   1.474 0.140602    
# Affairs$religiousness -0.32915    0.08892  -3.702 0.000214 ***
# Affairs$occupation     0.02996    0.06364   0.471 0.637779    
# Affairs$rating        -0.45016    0.08863  -5.079 3.79e-07 ***
#   ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# (Dispersion parameter for binomial family taken to be 1)
# 
# Null deviance: 675.38  on 600  degrees of freedom
# Residual deviance: 615.78  on 594  degrees of freedom
# AIC: 629.78

#AIC of above model is greater than previous model AIC value
#so variable Age does influence extra marital affair

#building another model without considering education and gender
affairmodel4 <- glm(affairs ~ Affairs$age + Affairs$yearsmarried + Affairs$children + Affairs$religiousness + Affairs$occupation + Affairs$rating, data=Affairs, family = "binomial")
summary(affairmodel4)

# Coefficients:
#   Estimate Std. Error z value Pr(>|z|)    
# (Intercept)            1.49498    0.64997   2.300 0.021445 *  
# Affairs$age           -0.03979    0.01791  -2.221 0.026348 *  
# Affairs$yearsmarried   0.08685    0.03171   2.739 0.006161 ** 
# Affairs$childrenyes    0.44603    0.28969   1.540 0.123629    
# Affairs$religiousness -0.32511    0.08965  -3.627 0.000287 ***
# Affairs$occupation     0.08211    0.05692   1.443 0.149160    
# Affairs$rating        -0.46003    0.08954  -5.137 2.79e-07 ***
#   ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# (Dispersion parameter for binomial family taken to be 1)
# 
# Null deviance: 675.38  on 600  degrees of freedom
# Residual deviance: 611.29  on 594  degrees of freedom
# AIC: 625.29
# 
# Number of Fisher Scoring iterations: 4
#AIC value of above model is lesser than all previous models.
#so education and gender does not influence much on affairs

#building another model without considering education and occupation
affairmodel5 <- glm(affairs ~ Affairs$gender + Affairs$age + Affairs$yearsmarried + Affairs$children + Affairs$religiousness + Affairs$rating, data=Affairs, family = "binomial")
summary(affairmodel5)
# Coefficients:
# Estimate Std. Error z value Pr(>|z|)    
# (Intercept)            1.75357    0.63082   2.780 0.005439 ** 
# Affairs$gendermale     0.37366    0.20768   1.799 0.071989 .  
# Affairs$age           -0.04285    0.01810  -2.367 0.017953 *  
# Affairs$yearsmarried   0.09518    0.03220   2.956 0.003115 ** 
# Affairs$childrenyes    0.37307    0.28762   1.297 0.194608    
# Affairs$religiousness -0.32900    0.08962  -3.671 0.000242 ***
# Affairs$rating        -0.46015    0.08947  -5.143 2.71e-07 ***
#   ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# (Dispersion parameter for binomial family taken to be 1)
# 
# Null deviance: 675.38  on 600  degrees of freedom
# Residual deviance: 610.15  on 594  degrees of freedom
# AIC: 624.15
# 
# Number of Fisher Scoring iterations: 4

#AIC value of above model is lesser than all previous models.
#so education and occupation does not influence much on affairs

#FINAL MODEL IS LRM MODEL WHICH DOES NOT HAVE EDUCATION AND OCCUPATION
#Summary of model

summary(affairmodel5)
# 
# Call:
#   glm(formula = affairs ~ Affairs$gender + Affairs$age + Affairs$yearsmarried + 
#         Affairs$children + Affairs$religiousness + Affairs$rating, 
#       family = "binomial", data = Affairs)
# 
# Deviance Residuals: 
#   Min       1Q   Median       3Q      Max  
# -1.5534  -0.7503  -0.5701  -0.2469   2.4890  
# 
# Coefficients:
#   Estimate Std. Error z value Pr(>|z|)    
# (Intercept)            1.75357    0.63082   2.780 0.005439 ** 
# Affairs$gendermale     0.37366    0.20768   1.799 0.071989 .  
# Affairs$age           -0.04285    0.01810  -2.367 0.017953 *  
# Affairs$yearsmarried   0.09518    0.03220   2.956 0.003115 ** 
# Affairs$childrenyes    0.37307    0.28762   1.297 0.194608    
# Affairs$religiousness -0.32900    0.08962  -3.671 0.000242 ***
# Affairs$rating        -0.46015    0.08947  -5.143 2.71e-07 ***
#   ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# (Dispersion parameter for binomial family taken to be 1)
# 
# Null deviance: 675.38  on 600  degrees of freedom
# Residual deviance: 610.15  on 594  degrees of freedom
# AIC: 624.15
# 
# Number of Fisher Scoring iterations: 4

#confusion matrix table
#getting y values
pr <- predict(affairmodel5, Affairs)
pr

#using Y values generated in "pr"  need to calculate probability
#next get the probability of above model, predicting outcome of this model
#type = c("response") calculates probabilities in same predict function
probaffair <- predict(affairmodel5, Affairs, type = "response")

#printing probability values
probaffair

#getting exponential values of lrm model
exp(coef(affairmodel5))

#calculating accuracy of model
#getting actual data from Affairs dataset
table(Affairs$affairs)
# no yes 
#451 150 
#count of unique values

#comparing predicted/probability values with cutoff value/default value as 0.5 with actual values
#here 0.5 means, predicted/probability values > 0.5 will be treated as YES and less than 0.5 as NO
confusion <- table(probaffair > 0.5, Affairs$affairs)
confusion
#        ACTUAL 
#        no yes
# FALSE 432 124
# TRUE   19  26

# True Negative (TN) -> 432 -> Model Predicted No and Actual was No.
# True Positive (TP) -> 26 -> Model Predicted Yes and Actual was Yes
# False Negative (FN) -> 124 -> Model Predicted No and Actual was Yes.
# False Positive (FP) -> 19 -> Model Predicted Yes and Actual was No.

# Specificity is TN / (TN + FP) -> 432 / (432 + 19) -> 95.79%
# Specificity is TN / Total Number of Actual Value of NO
# Specificity is also referred to as TN Rate.

# Sensitivity is TP / (TP + FN) -> 26 /  (26 + 124) -> 17.33%
# Sensitivity is TP / Total Number of Actual Value of YES
# Sensitivity is also referred to as TP Rate.

# False Positive Rate - FP Rate is (1 - Specificty)

# Ideally TP and TN Rate should be High. This is not possible. 
# Generally TP and TN Rate are Inversely Related. 
# If TP goes Up TN generally goes down.
# So we look at the FP Rate.
# SO Ideally we want a High TP and low FP.

# TP Measures Accuracy. FP Measures Error.

# So we Plot FP Rate on X axis and TP Rate on Y axis. The curve that we obtain is ROC Curve.
# ROC - Receiver Operating Characteristics.
# We want a point on the curve which gives high TP for a low FP.

#model accuracy
#sum of diagonal elements where model predicted correct values divided total of all elements in confusion table
accuracy <- sum(diag(confusion))/ sum(confusion)
accuracy
# model accuracy is [1] 0.7620632 i.e. 76.21%

#creating 2 empty vecotrs to store predcited values/calssed based on threshold value
pred_values <- NULL
yes_no <- NULL

pred_values <- ifelse(probaffair > 0.5, 1,0)
yes_no <- ifelse(probaffair > 0.5, "yes","no")

#creating new column in dataset "Affairs" to store above values
Affairs[,"prob"] <- probaffair
Affairs[,"pred_values"] <- pred_values
Affairs[,"yes_no"] <- yes_no

#view dataset Affairs with above columns added to it
View(Affairs)

#viewing only updated 3 new columns and affairs column only
View(Affairs[,c(1,10:12)])

#calling confusionmatrix which is part of library:caret
confusionMatrix(factor(Affairs$pred_values, levels = c(0,1)), factor(Affairs$affairs, levels = c(0,1)))

table(Affairs$affairs, Affairs$pred_values)
# 
#       0   1
# no  432  19
# yes 124  26


rocrpred <- prediction(probaffair, Affairs$affairs)

rocrperf <- performance(rocrpred, 'tpr', 'fpr')

plot(rocrperf, colorize =T, text.adj=c(-0.2,1.7))
#more area under curve better logisitic regression model is obtained

str(rocrperf)
# Formal class 'performance' [package "ROCR"] with 6 slots
# ..@ x.name      : chr "False positive rate"
# ..@ y.name      : chr "True positive rate"
# ..@ alpha.name  : chr "Cutoff"
# ..@ x.values    :List of 1
# .. ..$ : num [1:394] 0 0 0.00443 0.00665 0.00665 ...
# ..@ y.values    :List of 1
# .. ..$ : num [1:394] 0 0.00667 0.00667 0.00667 0.01333 ...
# ..@ alpha.values:List of 1
# .. ..$ : num [1:394] Inf 0.718 0.701 0.682 0.681 .

rocr_cutoff <- data.frame(cut_off = rocrperf@alpha.values[[1]],fpr=rocrperf@x.values,tpr=rocrperf@y.values)
colnames(rocr_cutoff) <- c("cut_off","FPR","TPR")
View(rocr_cutoff)


rocr_cutoff$cut_off <- round(rocr_cutoff$cut_off,6)
# Sorting data frame with respect to tpr in decreasing order 
rocr_cutoff <- arrange(rocr_cutoff,desc(TPR))

View(rocr_cutoff)
