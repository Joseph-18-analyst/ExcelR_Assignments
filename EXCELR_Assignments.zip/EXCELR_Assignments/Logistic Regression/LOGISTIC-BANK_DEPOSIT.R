#BUISNESS PROBLEM
#Output variable -> y
#y -> Whether the client has subscribed a term deposit or not 
#Binomial ("yes" or "no")

install.packages("AER")
library(AER)

#required for ROCR curve
install.packages("ROCR")
library(ROCR)

#package required for arithmetic operations
install.packages("dplyr")
library(plyr)
library(dplyr)

install.packages("caret")
install.packages("e1071", dependencies=TRUE)
library(caret)


#loading dataset
bankdata <- read.csv(file.choose(), sep = ";")
#dataset has 45211 rows and 17 dimensions/columns

#view the dataset
View(bankdata)

#get column names of dataset
colnames(bankdata)
# [1] "age"       "job"       "marital"   "education" "default"   "balance"   "housing"  
# [8] "loan"      "contact"   "day"       "month"     "duration"  "campaign"  "pdays"    
# [15] "previous"  "poutcome"  "y"     

#structure of dataset
str(bankdata)
# 'data.frame':	45211 obs. of  17 variables:
# $ age      : int  58 44 33 47 33 35 28 42 58 43 ...
# $ job      : Factor w/ 12 levels "admin.","blue-collar",..: 5 10 3 2 12 5 5 3 6 10 ...
# $ marital  : Factor w/ 3 levels "divorced","married",..: 2 3 2 2 3 2 3 1 2 3 ...
# $ education: Factor w/ 4 levels "primary","secondary",..: 3 2 2 4 4 3 3 3 1 2 ...
# $ default  : Factor w/ 2 levels "no","yes": 1 1 1 1 1 1 1 2 1 1 ...
# $ balance  : int  2143 29 2 1506 1 231 447 2 121 593 ...
# $ housing  : Factor w/ 2 levels "no","yes": 2 2 2 2 1 2 2 2 2 2 ...
# $ loan     : Factor w/ 2 levels "no","yes": 1 1 2 1 1 1 2 1 1 1 ...
# $ contact  : Factor w/ 3 levels "cellular","telephone",..: 3 3 3 3 3 3 3 3 3 3 ...
# $ day      : int  5 5 5 5 5 5 5 5 5 5 ...
# $ month    : Factor w/ 12 levels "apr","aug","dec",..: 9 9 9 9 9 9 9 9 9 9 ...
# $ duration : int  261 151 76 92 198 139 217 380 50 55 ...
# $ campaign : int  1 1 1 1 1 1 1 1 1 1 ...
# $ pdays    : int  -1 -1 -1 -1 -1 -1 -1 -1 -1 -1 ...
# $ previous : int  0 0 0 0 0 0 0 0 0 0 ...
# $ poutcome : Factor w/ 4 levels "failure","other",..: 4 4 4 4 4 4 4 4 4 4 ...
# $ y        : Factor w/ 2 levels "no","yes": 1 1 1 1 1 1 1 1 1 1 ...

#next step build the logistic regression model, with column "y" has output variable y
#all inputs i.e, x variables are considered in first model.
#family is chosen as binomial as output variable y has 2 values -yes and no
model1 <- glm(y ~ ., data = bankdata, family = "binomial")

#summary of model1
summary(model1)
# 
# Call:
#   glm(formula = y ~ ., family = "binomial", data = bankdata)

# Deviance Residuals: 
#   Min       1Q   Median       3Q      Max  
# -5.7286  -0.3744  -0.2530  -0.1502   3.4288  
# 
# Coefficients:
# Estimate Std. Error z value Pr(>|z|)    
# (Intercept)        -2.536e+00  1.837e-01 -13.803  < 2e-16 ***
# age                 1.127e-04  2.205e-03   0.051 0.959233    
# jobblue-collar     -3.099e-01  7.267e-02  -4.264 2.01e-05 ***
# jobentrepreneur    -3.571e-01  1.256e-01  -2.844 0.004455 ** 
# jobhousemaid       -5.040e-01  1.365e-01  -3.693 0.000221 ***
# jobmanagement      -1.653e-01  7.329e-02  -2.255 0.024130 *  
# jobretired          2.524e-01  9.722e-02   2.596 0.009436 ** 
# jobself-employed   -2.983e-01  1.120e-01  -2.664 0.007726 ** 
# jobservices        -2.238e-01  8.406e-02  -2.662 0.007763 ** 
# jobstudent          3.821e-01  1.090e-01   3.505 0.000457 ***
# jobtechnician      -1.760e-01  6.893e-02  -2.554 0.010664 *  
# jobunemployed      -1.767e-01  1.116e-01  -1.583 0.113456    
# jobunknown         -3.133e-01  2.335e-01  -1.342 0.179656    
# maritalmarried     -1.795e-01  5.891e-02  -3.046 0.002318 ** 
# maritalsingle       9.250e-02  6.726e-02   1.375 0.169066    
# educationsecondary  1.835e-01  6.479e-02   2.833 0.004618 ** 
# educationtertiary   3.789e-01  7.532e-02   5.031 4.88e-07 ***
# educationunknown    2.505e-01  1.039e-01   2.411 0.015915 *  
# defaultyes         -1.668e-02  1.628e-01  -0.102 0.918407    
# balance             1.283e-05  5.148e-06   2.493 0.012651 *  
# housingyes         -6.754e-01  4.387e-02 -15.395  < 2e-16 ***
# loanyes            -4.254e-01  5.999e-02  -7.091 1.33e-12 ***
# contacttelephone   -1.634e-01  7.519e-02  -2.173 0.029784 *  
# contactunknown     -1.623e+00  7.317e-02 -22.184  < 2e-16 ***
# day                 9.969e-03  2.497e-03   3.993 6.53e-05 ***
# monthaug           -6.939e-01  7.847e-02  -8.842  < 2e-16 ***
# monthdec            6.911e-01  1.767e-01   3.912 9.17e-05 ***
# monthfeb           -1.473e-01  8.941e-02  -1.648 0.099427 .  
# monthjan           -1.262e+00  1.217e-01 -10.367  < 2e-16 ***
# monthjul           -8.308e-01  7.740e-02 -10.733  < 2e-16 ***
# monthjun            4.536e-01  9.367e-02   4.843 1.28e-06 ***
# monthmar            1.590e+00  1.199e-01  13.265  < 2e-16 ***
# monthmay           -3.991e-01  7.229e-02  -5.521 3.36e-08 ***
# monthnov           -8.734e-01  8.441e-02 -10.347  < 2e-16 ***
# monthoct            8.814e-01  1.080e-01   8.159 3.37e-16 ***
# monthsep            8.741e-01  1.195e-01   7.314 2.58e-13 ***
# duration            4.194e-03  6.453e-05  64.986  < 2e-16 ***
# campaign           -9.078e-02  1.014e-02  -8.955  < 2e-16 ***
# pdays              -1.027e-04  3.061e-04  -0.335 0.737268    
# previous            1.015e-02  6.503e-03   1.561 0.118476    
# poutcomeother       2.035e-01  8.986e-02   2.265 0.023543 *  
# poutcomesuccess     2.291e+00  8.235e-02  27.821  < 2e-16 ***
# poutcomeunknown    -9.179e-02  9.347e-02  -0.982 0.326093    
# ---
#   Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
# 
# (Dispersion parameter for binomial family taken to be 1)
# 
# Null deviance: 32631  on 45210  degrees of freedom
# Residual deviance: 21562  on 45168  degrees of freedom
# AIC: 21648
# 
# Number of Fisher Scoring iterations: 6

# Null Deviance is the Quantum of Error that we will get when we consider only the Intercept i.e . Beta0.
# Residual Deviance is the Quantum of Error that we will get when we consider
# all the Inputs and Coefficients.
# If the Difference between the Null Deviance and Residual Deviance is Substantial, model is considered to be good
# it is (32631 - 21562) = 11069. This is substantial. So we consider the Model to be good.

# No Observations are deleted due to Missingness. So there is no 'NA' data in the Data Set.
#in output column "y" value YES means customer has opted for term deposit, "No" means otherwise

#confusion matrix table
#getting y values
pr <- predict(model1, bankdata)
pr

#using Y values generated in "pr"  need to calculate probability
#next get the probability of above model i.e. predicting outcome of this model
#type = "response" calculates probabilities in same predict function
probbank <- predict(model1, bankdata, type = "response")

#printing probability values
probbank

#calculating accuracy of model
#getting actual data from Affairs dataset
table(bankdata$y)
#   no   yes 
# 39922  5289

#comparing predicted/probability values with cutoff value/threshold value as 0.5 with actual values
#here 0.5 means, predicted/probability values > 0.5 will be treated as YES and less than 0.5 as NO
confusion <- table(probbank > 0.5, bankdata$y)
confusion
#           ACTUAL
#          no   yes
# FALSE 38940  3456
# TRUE    982  1833

# True Negative (TN) -> 38940 -> Model Predicted No and Actual was No.
# True Positive (TP) -> 1833 -> Model Predicted Yes and Actual was Yes
# False Negative (FN) -> 3456 -> Model Predicted No and Actual was Yes.
# False Positive (FP) -> 982 -> Model Predicted Yes and Actual was No.

# Specificity is TN / (TN + FP) -> 38940 / (38940 + 982) -> 97.5%
# Specificity is TN / Total Number of Actual Value of NO
# Specificity is also referred to as TN Rate.

# Sensitivity is TP / (TP + FN) -> 1833 /  (1833 + 3456) -> 34.65%
# Sensitivity is TP / Total Number of Actual Value of YES
# Sensitivity is also referred to as TP Rate.

# False Positive Rate - FP Rate is (1 - Specificty)

# Ideally TP and TN Rate should be High. This is not possible. 
# Generally TP and TN Rate are Inversely Related. 
# If TP goes Up TN generally goes down.
# So we look at the FP Rate.
# SO Ideally we want a High TP and low FP.

# TP Measures Accuracy. FP Measures Error.

# So we Plot FP Rate on X axis and TP Rate on Y axis. The curve that we obtain is ROC Curve.
# ROC - Receiver Operating Characteristics.
# We want a point on the curve which gives high TP for a low FP.

#model accuracy
#sum of diagonal elements where model predicted correct values divided total of all elements in confusion table
accuracy <- sum(diag(confusion))/ sum(confusion)
accuracy
# model accuracy is [1] 0.901838 i.e. 90.18%

#creating 2 empty vecotrs to store predcited values/calssed based on threshold value
pred_values <- NULL
yes_no <- NULL

pred_values <- ifelse(probbank> 0.5, 1,0)
yes_no <- ifelse(probbank > 0.5, "yes","no")

#creating new column in dataset "Affairs" to store above values
bankdata[,"prob"] <- probbank
bankdata[,"pred_values"] <- pred_values
bankdata[,"yes_no"] <- yes_no

#view dataset Affairs with above columns added to it
View(bankdata)

table(bankdata$y, bankdata$pred_values)
#          ACTUAL
#         0     1
# no  38940   982
# yes  3456  1833

rocrpred <- prediction(probbank, bankdata$y)

rocrperf <- performance(rocrpred, 'tpr', 'fpr')

plot(rocrperf, colorize =T, text.adj=c(-0.2,1.7))
#more area under curve better logisitic regression model is obtained

str(rocrperf)
# Formal class 'performance' [package "ROCR"] with 6 slots
# ..@ x.name      : chr "False positive rate"
# ..@ y.name      : chr "True positive rate"
# ..@ alpha.name  : chr "Cutoff"
# ..@ x.values    :List of 1
# .. ..$ : num [1:45212] 0.00 2.50e-05 2.50e-05 5.01e-05 7.51e-05 ...
# ..@ y.values    :List of 1
# .. ..$ : num [1:45212] 0 0 0.000189 0.000189 0.000189 ...
# ..@ alpha.values:List of 1
# .. ..$ : num [1:45212] Inf 1 1 1 1 ...

rocr_cutoff <- data.frame(cut_off = rocrperf@alpha.values[[1]],fpr=rocrperf@x.values,tpr=rocrperf@y.values)
colnames(rocr_cutoff) <- c("cut_off","FPR","TPR")
View(rocr_cutoff)


rocr_cutoff$cut_off <- round(rocr_cutoff$cut_off,6)
# Sorting data frame with respect to tpr in decreasing order 
rocr_cutoff <- arrange(rocr_cutoff,desc(TPR))

View(rocr_cutoff)
