# Business Problem: Predict the Sales of Computers

install.packages("data.table")
library (data.table)

install.packages("corpcor")
library(corpcor)

install.packages("MASS")
library(MASS)

# Package 'moments' is required for Skewness and Kurtosis
install.packages ("moments")
library (moments)

# Package "car" is required for Plotting QQPlot.
install.packages ("car")
library (car)

# Package "ggplot2" is required for Plotting GGPLOT and ACF Plot
install.packages ("ggplot2")
library(ggplot2)

#loading dataset
sales <- Computer_Data

#view the data
View(sales)

#first colum contains serial number, creating new data set excluding first column
sales1 <- sales[,-1]

#view dataset, data set has 6259 observations and 10 dimensions
View(sales1)

#getting column names
colnames(sales1)
#[1] "price"   "speed"   "hd"      "ram"     "screen"  "cd"      "multi"   "premium" "ads"    
#[10] "trend

#getting data types of all columns
str(sales1)
#$ price  : int  1499 1795 1595 1849 3295 3695 1720 1995 2225 2575 ...
#$ speed  : int  25 33 25 25 33 66 25 50 50 50 ...
#$ hd     : int  80 85 170 170 340 340 170 85 210 210 ...
#$ ram    : int  4 2 4 8 16 16 4 2 8 4 ...
#$ screen : int  14 14 15 14 14 14 14 14 14 15 ...
#$ cd     : Factor w/ 2 levels "no","yes": 1 1 1 1 1 1 2 1 1 1 ...
#$ multi  : Factor w/ 2 levels "no","yes": 1 1 1 1 1 1 1 1 1 1 ...
#$ premium: Factor w/ 2 levels "no","yes": 2 2 2 1 2 2 2 2 2 2 ...
#$ ads    : int  94 94 94 94 94 94 94 94 94 94 ...
#$ trend  : int  1 1 1 1 1 1 1 1 1 1 ...

#generating summary
summary(sales1)

# Column - Speed
#Min : 25, Max : 100, Median : 50, Mean : 52.01, 1st Quartile : 33, 3rd Quartile : 66
#Mean and Median are close to each other, suspecting no possible outliers

# Column - hd
#Min : 80, Max : 2100, Median : 340, Mean : 416, 1st Quartile : 214, 3rd Quartile : 528
#High difference between Mean and Meidan, Suspected Outliers are Outliers are present.
#IQR = 528 - 214 = 314
#Upper boundary: Q3+1.5(IQR) = 528 + 1.5(314) = 999
#Max value is 2100, so outliers are presend in X-Variable:hd

# Column - ram
#Min : 2, Max : 32, Median : 8, Mean : 8.287, 1st Quartile : 4, 3rd Quartile : 8
#Mean and Median are close to each other, suspecting no possible outliers

# Column - screen
#Min : 14, Max : 17, Median : 14, Mean : 14.61, 1st Quartile : 14, 3rd Quartile : 15
#Mean and Median are close to each other, suspecting no possible outliers

# Column - ads
#Min : 39, Max : 339, Median : 246, Mean : 221.3, 1st Quartile : 162.5, 3rd Quartile : 275
#Mean and Median are close to each other, suspecting no possible outliers

# Column - trend
#Min : 1, Max : 35, Median : 16, Mean : 15.93, 1st Quartile : 10, 3rd Quartile : 21.5
#Mean and Median are close to each other, suspecting no possible outliers


#Generating box plots, variance and standar deviation for input variables
boxplot(sales1$speed)
#data is right skewed.
var(sales1$speed)
#447.6498
sd(sales1$speed)
#21.15774

boxplot(sales1$hd)
#slightly right skewed, outliers in upper boundary
var(sales1$hd)
#66847.3
sd(sales1$hd)
#258.5484

boxplot(sales1$ram)
#third quartile and median are same, outliers present in upper boundary
var(sales1$ram)
#31.70928
sd(sales1$ram)
#5.631099

boxplot(sales1$screen)
#first quartile and median are same, outlier present in upper boundary
var(sales1$screen)
#0.8192336
sd(sales1$screen)
#0.9051152

boxplot(sales1$ads)
#data is left skewed, no outliers
var(sales1$ads)
#5600.32
sd(sales1$ads)
#74.83528

boxplot(sales1$trend)
#no outliers, very slightly right skewed
var(sales1$trend)
#61.99962
sd(sales1$trend)
#7.873984

#generating histogram, skewness for x-variables
hist(sales1$speed)
# Distribution is not Continuous. For Certain Ranges Frequency is 0.
# Getting the Unique Values for Speed
unique(sales1$speed)
#only 6 unique values of speed: 25  33  66  50 100  75

hist(sales1$hd)
#right skewed
skewness(sales1$hd)
#1.377689

hist(sales1$ram)
# Distribution is not Continuous. For Certain Ranges Frequency is 0.
# Getting the Unique Values for Speed
unique(sales1$ram)
#only 6 unique vales: 4  2  8 16 32 24
skewness(sales1$ram)
#1.38587

hist(sales1$screen)
# Distribution is not Continuous. For Certain Ranges Frequency is 0. Outliers present
# Getting the Unique Values for Speed
unique(sales1$screen)
#only 3 unique values: 14 15 17
skewness(sales1$screen)
#1.633616

hist(sales1$ads)
#left skewed
skewness(sales1$ads)
#-0.5531955

hist(sales1$trend)
#symmetrical distribution
skewness(sales1$trend)
#0.2366127

#determining correlation between input and output variables to check collinearity
#pairs function
pairs(sales1)
#no multi collinearity

#strength and direction of correlation using cor function
cor(sales1[,c(1,2,3,4,5,9,10)])
#           price      speed         hd        ram      screen         ads      trend
#price   1.00000000  0.3009765  0.4302578  0.6227482  0.29604147  0.05454047 -0.1999869
#speed   0.30097646  1.0000000  0.3723041  0.2347605  0.18907412 -0.21523206  0.4054383
#hd      0.43025779  0.3723041  1.0000000  0.7777263  0.23280153 -0.32322200  0.5777901
#ram     0.62274824  0.2347605  0.7777263  1.0000000  0.20895374 -0.18166971  0.2768438
#screen  0.29604147  0.1890741  0.2328015  0.2089537  1.00000000 -0.09391943  0.1886144
#ads     0.05454047 -0.2152321 -0.3232220 -0.1816697 -0.09391943  1.00000000 -0.3185525
#trend  -0.19998694  0.4054383  0.5777901  0.2768438  0.18861444 -0.31855251  1.0000000

#'ram' and 'hd': 0.78,  and 'trend' and 'hd':0.58 ->positive relationship
# Correlation between 'Y' and all the 'X' variables.
# price' and 'ram' and :0.63 -> positive relationship
# weak positive relationship between 'price' and 'speed', 'hd', 'screen'
# very weak positive correlation between Price and ads
# weak negative correlation between Price and trend.

#getting pure correlation 
cor2pcor(cor(sales1 [, c(1,2,3,4,5,9,10)]))


#building first MLR: multi linear regression model
# To Build the Model - lm function
# lm (Y ~ X1 + X2 + ... Xn, data=<data-set>) OR ( Y ~ . data=<data-set>)
mlr1 <- lm(sales1$price~., data = sales1)

#summary of model
summary(mlr1)

#Residuals:
#  Min       1Q   Median       3Q      Max 
#-1093.77  -174.24   -11.49   146.49  2001.05 
#Coefficients:
#  Estimate Std. Error t value Pr(>|t|)    
#(Intercept)  307.98798   60.35341   5.103 3.44e-07 ***
#  speed          9.32028    0.18506  50.364  < 2e-16 ***
#  hd             0.78178    0.02761  28.311  < 2e-16 ***
#  ram           48.25596    1.06608  45.265  < 2e-16 ***
#  screen       123.08904    3.99950  30.776  < 2e-16 ***
#  cdyes         60.91671    9.51559   6.402 1.65e-10 ***
#  multiyes     104.32382   11.41268   9.141  < 2e-16 ***
#  premiumyes  -509.22473   12.34225 -41.259  < 2e-16 ***
#  ads            0.65729    0.05132  12.809  < 2e-16 ***
#  trend        -51.84958    0.62871 -82.470  < 2e-16 ***
#  Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
#Residual standard error: 275.3 on 6249 degrees of freedom
#Multiple R-squared:  0.7756,	Adjusted R-squared:  0.7752 
#F-statistic:  2399 on 9 and 6249 DF,  p-value: < 2.2e-16

#all coefficients are significant. R-Squared value is 77.56%

#checking multi collinearity using VIF function
#if vif values > 10 then multi collinearity exists
vif(mlr1)
#speed       hd      ram   screen       cd    multi  premium      ads    trend 
#1.265364 4.207395 2.974628 1.081644 1.859370 1.290568 1.109388 1.217218 2.022790 
#no multicollinearity exists

#Added Variable Plot (AV Plot) to check for Correlation between variables and o/p Variable
avPlots(mlr1,id.n=2,id.cex=0.7)

# Can check which variables have the strongest influence on price, after accounting for all other 
# variables, by evaluating the slope of each chart in the grid.
# We observe 'cd', multi' and 'ads' have a very negligible slop.

# Let us build a model by not considering the 'cd' dimension
mlr2 <- lm(sales1$price ~ sales1$speed+sales1$hd+sales1$ram+sales1$screen+sales1$multi+sales1$premium+sales1$ads+sales1$trend, data = sales1)

#summary
summary(mlr2)

#Residuals:
#Min       1Q   Median       3Q      Max 
#-1078.19  -173.69   -10.97   148.45  2002.20 
#Coefficients:
#  Estimate Std. Error t value Pr(>|t|)    
#(Intercept)        272.02527   60.28331   4.512 6.53e-06 ***
#  sales1$speed         9.36969    0.18549  50.514  < 2e-16 ***
#  sales1$hd            0.80334    0.02750  29.217  < 2e-16 ***
#  sales1$ram          49.40038    1.05434  46.854  < 2e-16 ***
#  sales1$screen      123.21752    4.01222  30.711  < 2e-16 ***
#  sales1$multiyes    134.52653   10.42506  12.904  < 2e-16 ***
#  sales1$premiumyes -498.64785   12.27023 -40.639  < 2e-16 ***
#  sales1$ads           0.71650    0.05064  14.150  < 2e-16 ***
#  sales1$trend       -50.93945    0.61438 -82.912  < 2e-16 ***
#  Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
#Residual standard error: 276.2 on 6250 degrees of freedom
#Multiple R-squared:  0.7741,	Adjusted R-squared:  0.7738 
#F-statistic:  2677 on 8 and 6250 DF,  p-value: < 2.2e-16

#buidling next model by excluding also "multi" variable

mlr3 <- lm(sales1$price ~ sales1$speed+sales1$hd+sales1$ram+sales1$screen+sales1$premium+sales1$ads+sales1$trend, data = sales1)

#summary
summary(mlr3)

#Residuals:
#  Min       1Q   Median       3Q      Max 
#-1056.63  -175.12    -9.71   148.59  1995.17 
#Coefficients:
#  Estimate Std. Error t value Pr(>|t|)    
#  (Intercept)        271.45594   61.07618   4.445 8.96e-06 ***
#  sales1$speed         9.37710    0.18793  49.898  < 2e-16 ***
#  sales1$hd            0.78725    0.02783  28.289  < 2e-16 ***
#  sales1$ram          49.64734    1.06803  46.485  < 2e-16 ***
#  sales1$screen      121.33374    4.06230  29.868  < 2e-16 ***
#  sales1$premiumyes -477.78532   12.32323 -38.771  < 2e-16 ***
#  sales1$ads           0.74744    0.05124  14.586  < 2e-16 ***
#  sales1$trend       -49.34131    0.60968 -80.930  < 2e-16 ***
#  Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
#Residual standard error: 279.9 on 6251 degrees of freedom
#Multiple R-squared:  0.7681,	Adjusted R-squared:  0.7678 
#F-statistic:  2957 on 7 and 6251 DF,  p-value: < 2.2e-16

#mlr2 model R squared value is not better than vanilla model

#to perform deletion diagnostics on vanilla model-mlr1 to check influential observation, 
#instead of deleting whole columns like cd and multi
influence.measures (mlr1)
influenceIndexPlot(mlr1)
windows()

# Influence Index Plot
# As per Cook's Distance Plot, Influence Observations are 1701, 1441.
# As per Studentized Residuals Plot, Influence Observations are 1701, 1441.
# As per Bonferroni p-value Plot, Influence Observations are 1701, 1441.
# As per hat-values Plot, Influence Observations are 3784, 4478

#let us build another model by excluding these 4 observations
sales1 <- sales[-c(1441, 1701, 3784, 4478), ]
mlr4 <- lm(sales1$price~., data = sales1)

#summary
summary(mlr4)

#Residuals:
#  Min       1Q   Median       3Q      Max 
#-1151.81  -174.72   -13.22   148.15  1445.35 
#Coefficients:
#  Estimate Std. Error t value Pr(>|t|)    
#(Intercept)  427.91085   60.64272   7.056 1.90e-12 ***
#  X              0.11720    0.01436   8.160 4.01e-16 ***
#  speed          9.39272    0.18299  51.330  < 2e-16 ***
#  hd             0.81143    0.02802  28.962  < 2e-16 ***
#  ram           47.94856    1.06292  45.110  < 2e-16 ***
#  screen       120.59372    3.95093  30.523  < 2e-16 ***
#  cdyes         49.42971    9.48533   5.211 1.94e-07 ***
#  multiyes     105.97847   11.26098   9.411  < 2e-16 ***
#  premiumyes  -511.08131   12.17793 -41.968  < 2e-16 ***
#  ads            0.54097    0.05256  10.292  < 2e-16 ***
#  trend        -78.96608    3.39373 -23.268  < 2e-16 ***
#  Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
#Residual standard error: 271.7 on 6244 degrees of freedom
#Multiple R-squared:  0.7797,	Adjusted R-squared:  0.7794 
#F-statistic:  2210 on 10 and 6244 DF,  p-value: < 2.2e-16

#all coefficients are significant, R-Squared value is 0.7797, not much better than vanilla model
# Let us Build a Logarithmic Model with log (speed), log (hd), log (screen)
mlrlog <- lm(sales1$price~log(sales1$speed)+log(sales1$hd)+sales1$ram+log(sales1$screen)+sales1$cd+sales1$multi+sales1$premium+sales1$ads+sales1$trend, data = sales1)

#summary
summary(mlrlog)

#Residuals:
#  Min     1Q Median     3Q    Max 
#-893.7 -168.8  -20.3  141.0 1380.2 
#Coefficients:
#  Estimate Std. Error t value Pr(>|t|)    
#(Intercept)        -5.333e+03  1.555e+02 -34.298  < 2e-16 ***
#  log(sales1$speed)   4.760e+02  9.033e+00  52.699  < 2e-16 ***
#  log(sales1$hd)      3.645e+02  9.758e+00  37.350  < 2e-16 ***
#  sales1$ram          4.786e+01  9.049e-01  52.883  < 2e-16 ***
#  log(sales1$screen)  1.627e+03  5.746e+01  28.313  < 2e-16 ***
#  sales1$cdyes        5.009e+01  8.880e+00   5.641 1.77e-08 ***
#  sales1$multiyes     9.405e+01  1.061e+01   8.864  < 2e-16 ***
#  sales1$premiumyes  -5.465e+02  1.156e+01 -47.294  < 2e-16 ***
#  sales1$ads          4.988e-01  4.727e-02  10.553  < 2e-16 ***
#  sales1$trend       -5.226e+01  5.688e-01 -91.874  < 2e-16 ***
#  Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
#Residual standard error: 256.6 on 6245 degrees of freedom
#Multiple R-squared:  0.8034,	Adjusted R-squared:  0.8031 
#F-statistic:  2835 on 9 and 6245 DF,  p-value: < 2.2e-16

#finalizing mlrlog model as final, r-sqaured value is 80.31 and all coefficients are significant

#perform the Error / Residual Analysis
##########################################################################
# 1. Residuals should be Normally Distributed.
# 2. Homoscedasticity - constant variance - This assumption means that the variance around the 
# regression line is the same for all values of the predictor variable (X).
# 3. Statistical Independence of the Errors - Residuals should not be auto correlated.

#listing residuals
mlrlog$residuals

#sum of residuals
sum(mlrlog$residuals)
#-6.517142e-11

#finding mean
mean(mlrlog$residuals)
# -1.031303e-14

#finding root mean square error
sqrt(sum(mlrlog$residuals^2)/nrow(sales1))
#RMSE is 256.4077

#plotting 4 charts in 1 panel
par(mfrow=c(2,2))
plot (mlrlog)
par(mfrow=c(1,1))

# Normal QQ Plot  - Residuals are Normally Distributed - Assumption 1 is checked.
# If there is absolutely no heteroscedastity, you should see a completely random, equal distribution of 
# points throughout the range of X axis and a flat red line.
# In our case in Residual Vs Fitted Plot, Residuals are random, equal distributed throughout the 
# range of X axis and flat red line. - Assumption 2 is checked.

#histogram of residuals
hist(residuals(mlrlog))
#symmetrical distribution is seen, normal distribution- assumption 1 is checked

# Let us construct the ACF (Auto Correlation Function) Plot
acf (mlrlog$residuals)
# If the residuals are not autocorrelated, the vertical bars will be near zero value below the dashed 
# blue line (significance level). In our case most of the vertical bars are below the blue line.
# So there is no auto correlation problem. - Assumption 3 is checked.