#Buisness Problem
#Consider only the below columns and prepare a prediction model for predicting Price.
#Corolla<-Corolla[c("Price","Age_08_04","KM","HP","cc","Doors","Gears","Quarterly_Tax","Weight")]

# Package 'moments' is required for Skewness and Kurtosis
install.packages ("moments")
library (moments)

# Package "car" is required for Plotting QQPlot.
install.packages ("car")
library (car)

# Package "ggplot2" is required for Plotting GGPLOT and ACF Plot
install.packages ("ggplot2")
library(ggplot2)

# Package - 'corpcor' is required for Partial Correlation Matrix
install.packages("corpcor")
library(corpcor)

install.packages("data.table")
library (data.table)

#loading the dataset
cprice <- ToyotaCorolla

#viewing data set
View(cprice)

#Need to consider only following input variables-X: "Price","Age_08_04","KM","HP","cc","Doors","Gears","Quarterly_Tax","Weight"
#Output/dependent variable is Price
cprice <- cprice[c("Price","Age_08_04","KM","HP","cc","Doors","Gears","Quarterly_Tax","Weight")]

#viewing updated dataset
View(cprice)
#Updated data has 1436 observations and 9 dimensions

#Getting data types of all columns
str(cprice)
#'data.frame':	1436 obs. of  9 variables:
#$ Price        : int  13500 13750 13950 14950 13750 12950 16900 18600 21500 12950 ...
#$ Age_08_04    : int  23 23 24 26 30 32 27 30 27 23 ...
#$ KM           : int  46986 72937 41711 48000 38500 61000 94612 75889 19700 71138 ...
#$ HP           : int  90 90 90 90 90 90 90 90 192 69 ...
#$ cc           : int  2000 2000 2000 2000 2000 2000 2000 2000 1800 1900 ...
#$ Doors        : int  3 3 3 3 3 3 3 3 3 3 ...
#$ Gears        : int  5 5 5 5 5 5 5 5 5 5 ...
#$ Quarterly_Tax: int  210 210 210 210 210 210 210 210 100 185 ...
#$ Weight       : int  1165 1165 1165 1165 1170 1170 1245 1245 1185 1105 ...

#summary of dataset
summary(cprice)
#    Price         Age_08_04           KM               HP              cc            Doors      
#Min.   : 4350   Min.   : 1.00   Min.   :     1   Min.   : 69.0   Min.   : 1300   Min.   :2.000  
#1st Qu.: 8450   1st Qu.:44.00   1st Qu.: 43000   1st Qu.: 90.0   1st Qu.: 1400   1st Qu.:3.000  
#Median : 9900   Median :61.00   Median : 63390   Median :110.0   Median : 1600   Median :4.000  
#Mean   :10731   Mean   :55.95   Mean   : 68533   Mean   :101.5   Mean   : 1577   Mean   :4.033  
#3rd Qu.:11950   3rd Qu.:70.00   3rd Qu.: 87021   3rd Qu.:110.0   3rd Qu.: 1600   3rd Qu.:5.000  
#Max.   :32500   Max.   :80.00   Max.   :243000   Max.   :192.0   Max.   :16000   Max.   :5.000  
#Gears       Quarterly_Tax        Weight    
#Min.   :3.000   Min.   : 19.00   Min.   :1000  
#1st Qu.:5.000   1st Qu.: 69.00   1st Qu.:1040  
#Median :5.000   Median : 85.00   Median :1070  
#Mean   :5.026   Mean   : 87.12   Mean   :1072  
#3rd Qu.:5.000   3rd Qu.: 85.00   3rd Qu.:1085  
#Max.   :6.000   Max.   :283.00   Max.   :1615

#preparing histogram, skewness, kurtosis and qqnorm for x-vraibles
#doors and gears input variables are excluded for above mentioned plots.
#as they have 2,3,4,5 and 3, 5, 6, 4 only as values respectively.

hist(cprice$Age_08_04)
skewness(cprice$Age_08_04)
#skewness is -0.8258381
kurtosis(cprice$Age_08_04)
#kurtosis is 2.919459
qqnorm(cprice$Age_08_04)
qqline(cprice$Age_08_04)

hist(cprice$KM)
skewness(cprice$KM)
#skewness is 1.014851 and right skewed
kurtosis(cprice$KM)
#kurtosis is 5.449539
qqnorm(cprice$KM)
qqline(cprice$KM)
#slightly right skewed

hist(cprice$HP)
table(cprice$HP)
#69  71  72  73  86  90  97  98 107 110 116 192 
#34   1  73   1 249  36 164   2  21 835   9  11
#12 unique values

hist(cprice$cc)
#outlier is present
table(cprice$cc)
#1300  1332  1398  1400  1587  1598  1600  1800  1900  1975  1995  2000 16000 
#248     2     2   164     4     4   845    14    30     1     2   119     1
# suspect 16000 is a outlier and 13 unique values

hist(cprice$Quarterly_Tax)
table(cprice$Quarterly_Tax)
#19  40  64  69  72  85 100 163 185 197 210 234 283 
#72   1  18 559   3 613  19   1  96  14  18  19   3
# 13 unique values

hist(cprice$Weight)
#it is right skewed
skewness(cprice$Weight)
#3.105391
kurtosis(cprice$Weight)
22.29137
qqnorm(cprice$Weight)
qqline(cprice$Weight)
#postivie and strong relation

#generating boxplot, variance, standard devaition for Input X-Variables

var(cprice$Age_08_04)
#345.9596
sd(cprice$Age_08_04)
#18.59999
boxplot(cprice$Age_08_04)
#data is left skewed, presence of outliers suspected outside minimum range

var(cprice$KM)
#1406733707
sd(cprice$KM)
#37506.45
boxplot(cprice$KM)
#data is slightly right skewed, presence of outlier suspected above maximum range.

var(cprice$Weight)
#2771.088
sd(cprice$Weight)
#52.64112
boxplot(cprice$Weight)
## Many Suspected Outliers and Outliers are present.

#checking colinearity between dimensions
pairs(cprice)
#no evidence of collinearity

#to check Strength and Direction of Correlation using cor function
cor(cprice)
#                    Price    Age_08_04          KM          HP          cc       Doors
#Price          1.00000000 -0.876590497 -0.56996016  0.31498983  0.12638920  0.18532555
#Age_08_04     -0.87659050  1.000000000  0.50567218 -0.15662202 -0.09808374 -0.14835921
#KM            -0.56996016  0.505672180  1.00000000 -0.33353795  0.10268289 -0.03619661
#HP             0.31498983 -0.156622020 -0.33353795  1.00000000  0.03585580  0.09242450
#cc             0.12638920 -0.098083739  0.10268289  0.03585580  1.00000000  0.07990330
#Doors          0.18532555 -0.148359215 -0.03619661  0.09242450  0.07990330  1.00000000
#Gears          0.06310386 -0.005363947  0.01502333  0.20947715  0.01462935 -0.16014143
#Quarterly_Tax  0.21919691 -0.198430508  0.27816470 -0.29843172  0.30699580  0.10936323
#Weight         0.58119759 -0.470253184 -0.02859846  0.08961406  0.33563740  0.30261764
#Gears Quarterly_Tax      Weight
#Price          0.063103857   0.219196911  0.58119759
#Age_08_04     -0.005363947  -0.198430508 -0.47025318
#KM             0.015023328   0.278164697 -0.02859846
#HP             0.209477146  -0.298431717  0.08961406
#cc             0.014629352   0.306995798  0.33563740
#Doors         -0.160141430   0.109363225  0.30261764
#Gears          1.000000000  -0.005451955  0.02061328
#Quarterly_Tax -0.005451955   1.000000000  0.62613373
#Weight         0.020613284   0.626133733  1.00000000

# Age_08_04 is positively correlated with KM
# Weight is negatively moderately correlated with Age_08_04
# Quarterly_Tax is positevely moderately correlated with Weight

# Correlation between 'Y' and all the 'X' variables.
# There is a weak positive correlation between Price and cc, Doors, Gears, Quarterly Tax, HP
# There is a moderately positive correlation between Price and Weight
# There is a negative correlation between Price and Age_08_044
# There is a moderately negative correlation between Price and KM

# Get the Pure Correlation  between the dimensions
cor2pcor(cor(cprice))

#building multilinear regression model for Price
# lm (Y ~ X1 + X2 + ... Xn, data=<data-set>) OR ( Y ~ . data=<data-set>)
mlrmodel <- lm(cprice$Price~cprice$Age_08_04+cprice$KM+cprice$HP+cprice$cc+cprice$Doors+cprice$Gears+cprice$Quarterly_Tax+cprice$Weight, data = cprice)
summary(mlrmodel)

#Residuals:
#  Min      1Q  Median      3Q     Max 
#-9366.4  -793.3   -21.3   799.7  6444.0 
#Coefficients:
#  Estimate Std. Error t value Pr(>|t|)    
#(Intercept)          -5.573e+03  1.411e+03  -3.949 8.24e-05 ***
#cprice$Age_08_04     -1.217e+02  2.616e+00 -46.512  < 2e-16 ***
#cprice$KM            -2.082e-02  1.252e-03 -16.622  < 2e-16 ***
#cprice$HP             3.168e+01  2.818e+00  11.241  < 2e-16 ***
#cprice$cc            -1.211e-01  9.009e-02  -1.344  0.17909    
#cprice$Doors         -1.617e+00  4.001e+01  -0.040  0.96777    
#cprice$Gears          5.943e+02  1.971e+02   3.016  0.00261 ** 
#cprice$Quarterly_Tax  3.949e+00  1.310e+00   3.015  0.00262 ** 
#cprice$Weight         1.696e+01  1.068e+00  15.880  < 2e-16 ***
#Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
#Residual standard error: 1342 on 1427 degrees of freedom
#Multiple R-squared:  0.8638,	Adjusted R-squared:  0.863 
#F-statistic:  1131 on 8 and 1427 DF,  p-value: < 2.2e-16

#Checking for Multi Collinearity Problem using VIF - Variance Inflation Factor
# If vIF > 10 then there exists collinearity. 

vif(mlrmodel)
#cprice$Age_08_04            cprice$KM            cprice$HP            cprice$cc 
#1.884620             1.756905             1.419422             1.163894 
#cprice$Doors         cprice$Gears cprice$Quarterly_Tax        cprice$Weight 
#1.156575             1.098723             2.311431             2.516420 

#All the values are less than 10. So there is no issue of Multi Collinearity.

#Added Variable Plot (AV Plot) to check for Correlation between variables and o/p Variable
avPlots(mlrmodel)
# We observe 'Doors' have a very negligible slope.

mlrmindoormodel <- lm(cprice$Price~cprice$Age_08_04+cprice$KM+cprice$HP+cprice$cc+cprice$Gears+cprice$Quarterly_Tax+cprice$Weight, data = cprice)
#summary(mlrmindoormodel)
#Residuals:
#  Min      1Q  Median      3Q     Max 
#-9362.3  -792.5   -21.3   801.2  6446.4 
#Coefficients:
#  Estimate Std. Error t value Pr(>|t|)    
#(Intercept)          -5.575e+03  1.410e+03  -3.954 8.06e-05 ***
#cprice$Age_08_04     -1.217e+02  2.615e+00 -46.528  < 2e-16 ***
#cprice$KM            -2.082e-02  1.251e-03 -16.636  < 2e-16 ***
#cprice$HP             3.167e+01  2.810e+00  11.270  < 2e-16 ***
#cprice$cc            -1.210e-01  9.005e-02  -1.344  0.17909    
#cprice$Gears          5.958e+02  1.934e+02   3.081  0.00210 ** 
#cprice$Quarterly_Tax  3.953e+00  1.306e+00   3.027  0.00251 ** 
#cprice$Weight         1.695e+01  1.033e+00  16.401  < 2e-16 ***
#Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
#Residual standard error: 1342 on 1428 degrees of freedom
#Multiple R-squared:  0.8638,	Adjusted R-squared:  0.8631 
#F-statistic:  1293 on 7 and 1428 DF,  p-value: < 2.2e-16

stepAIC(mlrmodel)

#Start:  AIC=20693.89
#cprice$Price ~ cprice$Age_08_04 + cprice$KM + cprice$HP + cprice$cc + 
#  cprice$Doors + cprice$Gears + cprice$Quarterly_Tax + cprice$Weight
#Df  Sum of Sq        RSS   AIC
#- cprice$Doors          1       2943 2571786477 20692
#- cprice$cc             1    3256511 2575040045 20694
#<none>                               2571783534 20694
#- cprice$Quarterly_Tax  1   16377633 2588161166 20701
#- cprice$Gears          1   16393629 2588177163 20701
#- cprice$HP             1  227730786 2799514319 20814
#- cprice$Weight         1  454465243 3026248777 20926
#- cprice$KM             1  497917334 3069700867 20946
#- cprice$Age_08_04      1 3898860600 6470644134 22017
#Step:  AIC=20691.89
#cprice$Price ~ cprice$Age_08_04 + cprice$KM + cprice$HP + cprice$cc + 
#  cprice$Gears + cprice$Quarterly_Tax + cprice$Weight
#Df  Sum of Sq        RSS   AIC
#- cprice$cc             1    3254209 2575040686 20692
#<none>                               2571786477 20692
#- cprice$Quarterly_Tax  1   16503849 2588290326 20699
#- cprice$Gears          1   17093855 2588880332 20699
#- cprice$HP             1  228761929 2800548406 20812
#- cprice$Weight         1  484447009 3056233485 20938
#- cprice$KM             1  498427860 3070214337 20944
#- cprice$Age_08_04      1 3898877516 6470663993 22015
#Step:  AIC=20691.7
#cprice$Price ~ cprice$Age_08_04 + cprice$KM + cprice$HP + cprice$Gears + 
#  cprice$Quarterly_Tax + cprice$Weight
#Df  Sum of Sq        RSS   AIC
#<none>                               2575040686 20692
#- cprice$Quarterly_Tax  1   14976762 2590017448 20698
#- cprice$Gears          1   17276597 2592317283 20699
#- cprice$HP             1  225684613 2800725299 20810
#- cprice$Weight         1  484245502 3059286188 20937
#- cprice$KM             1  506728527 3081769213 20948
#- cprice$Age_08_04      1 3902107988 6477148674 22014
#Call:
#  lm(formula = cprice$Price ~ cprice$Age_08_04 + cprice$KM + cprice$HP + 
#       cprice$Gears + cprice$Quarterly_Tax + cprice$Weight, data = cprice)
#Coefficients:
# (Intercept)      cprice$Age_08_04             cprice$KM             cprice$HP  
#-5.478e+03            -1.217e+02            -2.094e-02             3.133e+01  
#cprice$Gears  cprice$Quarterly_Tax         cprice$Weight  
#5.990e+02             3.737e+00             1.673e+01  

#building final model

mlrfinalmodel <- lm(cprice$Price~cprice$Age_08_04+cprice$KM+cprice$HP+log(cprice$cc)+cprice$Gears+cprice$Quarterly_Tax+cprice$Weight, data = cprice)
summary(mlrfinalmodel)

#Residuals:
#  Min       1Q   Median       3Q      Max 
#-10498.6   -763.2    -30.4    759.7   6611.2 
#Coefficients:
#  Estimate Std. Error t value Pr(>|t|)    
#(Intercept)           8.288e+03  2.662e+03   3.114  0.00188 ** 
#cprice$Age_08_04     -1.211e+02  2.585e+00 -46.868  < 2e-16 ***
#cprice$KM            -1.928e-02  1.263e-03 -15.262  < 2e-16 ***
#cprice$HP             3.677e+01  2.907e+00  12.649  < 2e-16 ***
#log(cprice$cc)       -2.261e+03  3.726e+02  -6.067 1.67e-09 ***
#cprice$Gears          5.582e+02  1.912e+02   2.920  0.00356 ** 
#cprice$Quarterly_Tax  6.545e+00  1.361e+00   4.808 1.69e-06 ***
#cprice$Weight         1.870e+01  1.059e+00  17.658  < 2e-16 ***
#Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
#Residual standard error: 1326 on 1428 degrees of freedom
#Multiple R-squared:  0.867,	Adjusted R-squared:  0.8664 
#F-statistic:  1330 on 7 and 1428 DF,  p-value: < 2.2e-16

# Let us consider the Model - mlrfinalmodel and perform the Error / Residual Analysis
##########################################################################
# 1. Residuals should be Normally Distributed.
# 2. Homoscedasticity - constant variance - This assumption means that the variance around the 
# regression line is the same for all values of the predictor variable (X).
# 3. Statistical Independence of the Errors - Residuals should not be auto correlated.

#listing residuals
mlrfinalmodel$residuals

#sum of residuals
sum(mlrfinalmodel$residuals)
#1.377956e-10

#mean of residuals
mean(mlrfinalmodel$residuals)
#9.474315e-14

#calculating root mean square error
sqrt(sum(mlrfinalmodel$residuals^2)/nrow(cprice))
#1322.174

## To plot 4 Charts in 1 Panel
plot(mlrfinalmodel)
par(mfrow=c(1,1))
# The above function displays 4 plots
# Residual Vs Fitted
# Normal QQ Plot  - Residuals are Normally Distributed - Assumption 1 is checked.
# Scale-Location Plot (Fitted (X) Vs Sqrt (Standardized Residuals))
# Residuals Vs Leverage
# In our case in Residual Vs Fitted Plot, Residuals are random, equal distributed throughout the 
# range of X axis and flat red line. - Assumption 2 is checked.

hist(residuals(mlrfinalmodel))
#very close to normal distribution
