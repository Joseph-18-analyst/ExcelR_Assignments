#Buisness Porblem
#1) Prepare a classification model using Naive Bayes for salary data 

#install package caret- required for data partitioning/slicing
install.packages("caret")
library(caret)

#instal package e1071 required naive bayes algorithm
install.packages("e1071")
library(e1071)

#install package gmodels required for comparisions
install.packages("gmodels")
library(gmodels)


#uploading salary training dataset
salary_train <- read.csv(file.choose())
#data set has 30161 rows and 14 dimensions

#structure of dataset
str(salary_train)
# 'data.frame':	30161 obs. of  14 variables:
# $ age          : int  39 50 38 53 28 37 49 52 31 42 ...
# $ workclass    : Factor w/ 7 levels " Federal-gov",..: 6 5 3 3 3 3 3 5 3 3 ...
# $ education    : Factor w/ 16 levels " 10th"," 11th",..: 10 10 12 2 10 13 7 12 13 10 ...
# $ educationno  : int  13 13 9 7 13 14 5 9 14 13 ...
# $ maritalstatus: Factor w/ 7 levels " Divorced"," Married-AF-spouse",..: 5 3 1 3 3 3 4 3 5 3 ...
# $ occupation   : Factor w/ 14 levels " Adm-clerical",..: 1 4 6 6 10 4 8 4 10 4 ...
# $ relationship : Factor w/ 6 levels " Husband"," Not-in-family",..: 2 1 2 1 6 6 2 1 2 1 ...
# $ race         : Factor w/ 5 levels " Amer-Indian-Eskimo",..: 5 5 5 3 3 5 3 5 5 5 ...
# $ sex          : Factor w/ 2 levels " Female"," Male": 2 2 2 2 1 1 1 2 1 2 ...
# $ capitalgain  : int  2174 0 0 0 0 0 0 0 14084 5178 ...
# $ capitalloss  : int  0 0 0 0 0 0 0 0 0 0 ...
# $ hoursperweek : int  40 13 40 40 40 40 16 45 50 40 ...
# $ native       : Factor w/ 40 levels " Cambodia"," Canada",..: 38 38 38 38 5 38 22 38 38 38 ...
# $ Salary       : Factor w/ 2 levels " <=50K"," >50K": 1 1 1 1 1 1 1 2 2 2 ...

#building NB model
nb_salary <- naiveBayes(salary_train$Salary ~ ., data = salary_train)
nb_salary


#reading salary_test data to predict the model on test data
salary_test <- read.csv(file.choose())


#using test data, predicting accuracy of NB model built from training data.
salarypredcit <- predict(nb_salary, salary_test[ ,-14])

#getting accuracy of model
accuracy <- mean(salarypredcit == salary_test[,14])
accuracy
#[1] 0.8193227
#model is 81.93% accurate