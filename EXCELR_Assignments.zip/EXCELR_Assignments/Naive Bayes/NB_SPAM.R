#BUISNESS PROBLEM
#Build a naive Bayes model on the data set for classifying the ham and spam

# Install Package - "caret" required for Partitioning / Data Slicing
install.packages("caret")
library(caret)

# Package Required for Naive Bayes Algorithm
install.packages("e1071")
library(e1071)

#tm package to build text corpus, corpus means file
install.packages("tm")
library(tm)

#used for comparisons
install.packages("gmodels")
library(gmodels)

#loading dataset
spamdata <- read.csv(file.choose())
#dataset has 5559 rows and 2 dimensions/columns

#viewing dataset
View(spamdata)

#structure of dataset
str(spamdata)
# 'data.frame':	5559 obs. of  2 variables:
# $ type: Factor w/ 2 levels "ham","spam": 1 1 1 2 2 1 1 1 2 1 ...
# $ text: Factor w/ 5156 levels "'An Amazing Quote'' - Sometimes in life its difficult to decide whats wrong!! a lie that brings a smile or the "| __truncated__,..: 1651 2557 257 626 3308 190 357 3392 2726 1079 ...

#getting proportion of ham and spam messages in column type using table function
table(table(spamdata$type))
# ham spam 
# 4812  747 

prop.table(table(spamdata$type))
#      ham      spam 
# 0.8656233 0.1343767

#text mining package is required as we are dealing rextual data in column: "text"
#structure of column: text
str(spamdata$text)

#converting text coulmn to corpus
spam_corpus <- Corpus(VectorSource(spamdata$text))
str(spam_corpus)

#performing cleansing on each of corpus document created using tm_map
#tm_map- transforming text data to filter unnecessary things like special characters or junk character
#special or junk characters are converted to universal text format:utf byte by byte
spam_corpus <- tm_map(spam_corpus, function(x) iconv(enc2utf8(x), sub = 'byte' ))

#cleanup corpus using tm_map
#converting to lowercase
corpus_clean <- tm_map(spam_corpus, tolower)
corpus_clean <- tm_map(corpus_clean, removePunctuation)
corpus_clean <- tm_map(corpus_clean, removeNumbers)
corpus_clean <- tm_map(corpus_clean, removeWords, stopwords())
corpus_clean <- tm_map(corpus_clean, stripWhitespace)  


#create a document-term sparse matrix on cleansed data
spam_dtm <- DocumentTermMatrix(corpus_clean)
spam_dtm
# <<DocumentTermMatrix (documents: 5559, terms: 8279)>>
#   Non-/sparse entries: 44003/45978958
#   Sparsity           : 100% 
# 100% sparsity means none of messages are repeating i.e messages/words repeating in one document will not repeat again in rest of documents
# 5559 rows and 8279 keywords

str(spam_dtm)
# List of 6
# $ i       : int [1:44003] 1 1 1 1 1 2 2 2 3 3 ...
# $ j       : int [1:44003] 1 2 3 4 5 6 7 8 9 10 ...
# $ v       : num [1:44003] 1 1 1 1 1 1 1 1 1 1 ...
# $ nrow    : int 5559
# $ ncol    : int 8279
# $ dimnames:List of 2
# ..$ Docs : chr [1:5559] "1" "2" "3" "4" ...
# ..$ Terms: chr [1:8279] "checking" "good" "hope" "just" ...
# - attr(*, "class")= chr [1:2] "DocumentTermMatrix" "simple_triplet_matrix"
# - attr(*, "weighting")= chr [1:2] "term frequency" "tf"

View(spam_dtm[1:10, 1:30])


#to view document term matric: DTM we need to convert it to matrix first
dtm_matrix <- as.matrix(spam_dtm)
str(dtm_matrix)
# num [1:5559, 1:8279] 1 0 0 0 0 0 0 0 0 0 ...
# - attr(*, "dimnames")=List of 2
# ..$ Docs : chr [1:5559] "1" "2" "3" "4" ...
# ..$ Terms: chr [1:8279] "checking" "good" "hope" "just" ...


#viewing only part of data- 10 rows, 20 columns, as whole data is around 351 mb in size
View(dtm_matrix[1:10, 1:20])

#next step creating training and test data set
#partitioning raw data
spamdata_train <- spamdata[1:4169, ]
spamdata_test <- spamdata[4170:5559, ]

#partitoning cleansed data
spamcorpus_train <- corpus_clean[1:4169]
spamcorpus_test <- corpus_clean[4170:5559]

#partitoning dtm also
spam_dtm_train <- spam_dtm[1:4169, ]
spam_dtm_test <- spam_dtm[4170:5559, ]


#checking proprotion of spam is similar
prop.table(table(spamdata$type))
#  ham      spam 
# 0.8656233 0.1343767

prop.table(table(spamdata_train$type))
# ham      spam 
# 0.8647158 0.1352842 

prop.table(table(spamdata_test$type))
# ham      spam 
# 0.8683453 0.1316547

#creating dictionary of words used more than 5 times
#by changing number of words to 3 or 4 or other number we can improve accuracy of model
spam_dict <- findFreqTerms(spam_dtm_train, 5)

#using above dictionary of 5 frequent words, recreating document term matrix of spamcorpus_train, spamcorpus_test
spam_train <- DocumentTermMatrix(spamcorpus_train, list(dictionary = spam_dict))
spam_test <- DocumentTermMatrix(spamcorpus_test, list(dictionary = spam_dict))

spam_test_matrix <- as.matrix(spam_test)
View(spam_test_matrix[1:10, 1:10])


#converting counts into a facotor
#custom function: if a word is used more than 0 times name it as 1
conver_counts <- function(x){
  x <- ifelse(x > 0, 1, 0)
  x <- factor(x, levels = c(0,1), labels = c("no","yes"))
}

#apply convert_counts to training and test data
#margin = 2 means it is for columns
#margin = 1 means it is for rows
spam_train <- apply(spam_train, MARGIN = 2, conver_counts)
spam_test <- apply(spam_test, MARGIN = 2, conver_counts)

View(spam_test[1:10, 1:10])


#applying naive bayes method
spam_classifier <- naiveBayes(spam_train, spamdata_train$type)
spam_classifier


#evaluating model performance on test data set
spam_test_pred <- predict(spam_classifier,spam_test)

table(spam_test_pred)
# spam_test_pred
# ham spam 
# 1233  157 
prop.table(table(spam_test_pred))
# spam_test_pred
# ham      spam 
# 0.8870504 0.1129496

#measuring accuracy of model
CrossTable(spam_test_pred, spamdata_test$type,
           prop.chisq = FALSE, prop.t = FALSE, prop.r = FALSE,
           dnn = c('predicted', 'actual'))

accuracy = mean(spam_test_pred == spamdata_test$type)

accuracy
#[1] 0.9755396
#accuracy od model is 97.55%  