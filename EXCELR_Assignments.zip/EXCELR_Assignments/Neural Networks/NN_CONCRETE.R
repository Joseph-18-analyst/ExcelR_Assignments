#BUISNESS PROBLEM
#Prepare a model for strength of concrete data using Neural Networks

install.packages("neuralnet")
library(neuralnet)  # regression

install.packages("nnet")
library(nnet) # classification 

#loading dataset concrete
concrete <- read.csv(file.choose())

#view dataset, has 1030 rows and 9 dimensions
View(concrete)

#summary of dataset
summary(concrete)
#      cement           slag            ash             water        superplastic   
# Min.   :102.0   Min.   :  0.0   Min.   :  0.00   Min.   :121.8   Min.   : 0.000  
# 1st Qu.:192.4   1st Qu.:  0.0   1st Qu.:  0.00   1st Qu.:164.9   1st Qu.: 0.000  
# Median :272.9   Median : 22.0   Median :  0.00   Median :185.0   Median : 6.400  
# Mean   :281.2   Mean   : 73.9   Mean   : 54.19   Mean   :181.6   Mean   : 6.205  
# 3rd Qu.:350.0   3rd Qu.:142.9   3rd Qu.:118.30   3rd Qu.:192.0   3rd Qu.:10.200  
# Max.   :540.0   Max.   :359.4   Max.   :200.10   Max.   :247.0   Max.   :32.200  
#   coarseagg         fineagg           age            strength    
# Min.   : 801.0   Min.   :594.0   Min.   :  1.00   Min.   : 2.33  
# 1st Qu.: 932.0   1st Qu.:731.0   1st Qu.:  7.00   1st Qu.:23.71  
# Median : 968.0   Median :779.5   Median : 28.00   Median :34.45  
# Mean   : 972.9   Mean   :773.6   Mean   : 45.66   Mean   :35.82  
# 3rd Qu.:1029.4   3rd Qu.:824.0   3rd Qu.: 56.00   3rd Qu.:46.13  
# Max.   :1145.0   Max.   :992.6   Max.   :365.00   Max.   :82.60  

#need to standardize the values, as values in all columns have different scale
#using normalizing function
normalize <- function(x){return((x-min(x))/(max(x)-min(x)))}

#applying above normalize function to standardize data in concrete dataset
#using list apply function: lapply
norm_concrete <- as.data.frame(lapply(concrete[,-9], FUN = normalize))

#summary of standaridized dataset
summary(norm_concrete)
#      cement            slag              ash             water         superplastic   
# Min.   :0.0000   Min.   :0.00000   Min.   :0.0000   Min.   :0.0000   Min.   :0.0000  
# 1st Qu.:0.2063   1st Qu.:0.00000   1st Qu.:0.0000   1st Qu.:0.3442   1st Qu.:0.0000  
# Median :0.3902   Median :0.06121   Median :0.0000   Median :0.5048   Median :0.1988  
# Mean   :0.4091   Mean   :0.20561   Mean   :0.2708   Mean   :0.4774   Mean   :0.1927  
# 3rd Qu.:0.5662   3rd Qu.:0.39775   3rd Qu.:0.5912   3rd Qu.:0.5607   3rd Qu.:0.3168  
# Max.   :1.0000   Max.   :1.00000   Max.   :1.0000   Max.   :1.0000   Max.   :1.0000  
#   coarseagg         fineagg            age         
# Min.   :0.0000   Min.   :0.0000   Min.   :0.00000  
# 1st Qu.:0.3808   1st Qu.:0.3436   1st Qu.:0.01648  
# Median :0.4855   Median :0.4654   Median :0.07418  
# Mean   :0.4998   Mean   :0.4505   Mean   :0.12270  
# 3rd Qu.:0.6640   3rd Qu.:0.5770   3rd Qu.:0.15110  
# Max.   :1.0000   Max.   :1.0000   Max.   :1.00000 -concrete using cbind

#binding strenght column from dataset concrete to standaridzed dataset norm
norm_concrete <- cbind(norm_concrete, concrete$strength)

#renaming the column to strength
colnames(norm_concrete)[9] <- "strength"
View(norm_concrete)

#preparing training and test dataset
concrete_train <- norm_concrete[1:773,]
concrete_test <- norm_concrete[774:1030,]

#building neural network model, with 1 simple hiddden neuron
concrete_model <- neuralnet(formula= strength~cement+slag+ash+water+superplastic+coarseagg+fineagg+age, data = concrete_train)

#visualize network topology
plot(concrete_model)


#evaluating model results
#obtain model results on concrete_test model consisting of upto 8 columns escluding strength column
model_results <- compute(concrete_model, concrete_test[1:8])
model_results

#obtaining predicted strength values
predicted_strength <- model_results$net.result

#examine correlation between predicted and actual values
cor(predicted_strength, concrete_test$strength)
#[1,] 0.8066579
#accuracy of model is 80.66%, small r value

#Next: improving the accuracy of model by setting hidden value to  i.e.  hidden nodes
concrete_model2 <- neuralnet(formula= strength~cement+slag+ash+water+superplastic+coarseagg+fineagg+age, data = concrete_train, hidden = 5)

#visualize network topology
plot(concrete_model2)

#evaluating model results
#obtain model results on concrete_test model consisting of upto 8 columns escluding strength column
model_results1 <- compute(concrete_model2, concrete_test[1:8])
model_results1

#obtaining predicted strength values
predicted_strength1 <- model_results1$net.result

#examine correlation between predicted and actual values
cor(predicted_strength1, concrete_test$strength)
