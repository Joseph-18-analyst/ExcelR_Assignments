#BUISNESS PROBLEM
#PREDICT THE BURNED AREA OF FOREST FIRES WITH NEURAL NETWORKS

# Install Package - "caret" required for Partitioning / Data Slicing
install.packages ("caret")
library (caret)

install.packages("neuralnet")
library(neuralnet)  # regression

install.packages("nnet")
library(nnet) # classification 

install.packages("plyr")
library(plyr)

#loading dataset concrete
forest <- read.csv(file.choose())

#view data set, has 517 rows and 31 dimensions
View(forest)

#dropping dummy data columns,as it is not required
forest <- forest[,-c(12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30)]

#viewing updated dataset
View(forest)

# Move the 'area' column to the Last.
areaData <- as.data.frame (forest [,11])
forest <- forest [, c(1,2,3,4,5,6,7,8,9,10,12)]
forest <- cbind (forest, areaData)
names(forest)[12] <- "area"

#structure of dataset
str(forest)
# 'data.frame':	517 obs. of  12 variables:
# $ month        : Factor w/ 12 levels "apr","aug","dec",..: 8 11 11 8 8 2 2 2 12 12 ...
# $ day          : Factor w/ 7 levels "fri","mon","sat",..: 1 6 3 1 4 4 2 2 6 3 ...
# $ FFMC         : num  86.2 90.6 90.6 91.7 89.3 92.3 92.3 91.5 91 92.5 ...
# $ DMC          : num  26.2 35.4 43.7 33.3 51.3 ...
# $ DC           : num  94.3 669.1 686.9 77.5 102.2 ...
# $ ISI          : num  5.1 6.7 6.7 9 9.6 14.7 8.5 10.7 7 7.1 ...
# $ temp         : num  8.2 18 14.6 8.3 11.4 22.2 24.1 8 13.1 22.8 ...
# $ RH           : int  51 33 33 97 99 29 27 86 63 40 ...
# $ wind         : num  6.7 0.9 1.3 4 1.8 5.4 3.1 2.2 5.4 4 ...
# $ rain         : num  0 0 0 0.2 0 0 0 0 0 0 ...
# $ area         : num  0 0 0 0 0 0 0 0 0 0 ...
# $ size_category: Factor w/ 2 levels "large","small": 2 2 2 2 2 2 2 2 2 2 ...

#column month, day and size_category has factor data type
#it needs to be converted using dummy variables

forest$month <-as.numeric(revalue(forest$month, c("jan"="0", "feb"="1", "mar"= "2", "apr"="3", 
                                                  "may"="4", "jun"="5", "jul"="6", "aug"="7",
                                                  "sep"="8", "oct"="9","nov"="10", "dec"= "11")))

forest$day <-as.numeric(revalue(forest$day, c("mon"="0", "tue"="1", "wed"="2", "thu"="3",
                                              "fri"="4", "sat"="5", "sun"="6")))

forest$size_category <-as.numeric(revalue(forest$size_category, c ("small"="0", "large"="1")))


#structure of updated dataset
str(forest)
# 'data.frame':	517 obs. of  12 variables:
#   $ month        : num  8 11 11 8 8 2 2 2 12 12 ...
# $ day          : num  1 6 3 1 4 4 2 2 6 3 ...
# $ FFMC         : num  86.2 90.6 90.6 91.7 89.3 92.3 92.3 91.5 91 92.5 ...
# $ DMC          : num  26.2 35.4 43.7 33.3 51.3 ...
# $ DC           : num  94.3 669.1 686.9 77.5 102.2 ...
# $ ISI          : num  5.1 6.7 6.7 9 9.6 14.7 8.5 10.7 7 7.1 ...
# $ temp         : num  8.2 18 14.6 8.3 11.4 22.2 24.1 8 13.1 22.8 ...
# $ RH           : int  51 33 33 97 99 29 27 86 63 40 ...
# $ wind         : num  6.7 0.9 1.3 4 1.8 5.4 3.1 2.2 5.4 4 ...
# $ rain         : num  0 0 0 0.2 0 0 0 0 0 0 ...
# $ size_category: num  2 2 2 2 2 2 2 2 2 2 ...
# $ area         : num  0 0 0 0 0 0 0 0 0 0 ...

#need to standardize the values, as values in all columns have different scale
#using normalizing function
normalize <- function(x){return((x-min(x))/(max(x)-min(x)))}

#applying above normalize function to standardize data in concrete dataset
#using list apply function: lapply
norm_forest <- as.data.frame(lapply(forest, FUN = normalize))

#summary of normalized dataset
summary(norm_forest)
#     month              day              FFMC             DMC               DC        
# Min.   :0.00000   Min.   :0.0000   Min.   :0.0000   Min.   :0.0000   Min.   :0.0000  
# 1st Qu.:0.09091   1st Qu.:0.1667   1st Qu.:0.9226   1st Qu.:0.2326   1st Qu.:0.5040  
# Median :0.54545   Median :0.5000   Median :0.9406   Median :0.3694   Median :0.7697  
# Mean   :0.52347   Mean   :0.4562   Mean   :0.9283   Mean   :0.3783   Mean   :0.6333  
# 3rd Qu.:1.00000   3rd Qu.:0.6667   3rd Qu.:0.9574   3rd Qu.:0.4869   3rd Qu.:0.8280  
# Max.   :1.00000   Max.   :1.0000   Max.   :1.0000   Max.   :1.0000   Max.   :1.0000  
#       ISI              temp              RH              wind             rain         
# Min.   :0.0000   Min.   :0.0000   Min.   :0.0000   Min.   :0.0000   Min.   :0.000000  
# 1st Qu.:0.1159   1st Qu.:0.4277   1st Qu.:0.2118   1st Qu.:0.2556   1st Qu.:0.000000  
# Median :0.1497   Median :0.5498   Median :0.3176   Median :0.4000   Median :0.000000  
# Mean   :0.1608   Mean   :0.5366   Mean   :0.3446   Mean   :0.4020   Mean   :0.003385  
# 3rd Qu.:0.1925   3rd Qu.:0.6624   3rd Qu.:0.4471   3rd Qu.:0.5000   3rd Qu.:0.000000  
# Max.   :1.0000   Max.   :1.0000   Max.   :1.0000   Max.   :1.0000   Max.   :1.000000  
#   size_category         area          
# Min.   :0.0000   Min.   :0.0000000  
# 1st Qu.:0.0000   1st Qu.:0.0000000  
# Median :1.0000   Median :0.0004767  
# Mean   :0.7311   Mean   :0.0117774  
# 3rd Qu.:1.0000   3rd Qu.:0.0060229  
# Max.   :1.0000   Max.   :1.0000000

#preparing training and test dataset
#training = 75%, testing = 25%
datapartition <- createDataPartition(norm_forest$area, p=0.75, list = F)
trainingdata <- norm_forest[datapartition, ]
testingdata <- norm_forest[-datapartition, ]

#building neural network model, with 1 simple hiddden neuron
forest_model <- neuralnet(formula = area ~ ., data = trainingdata)

#plot the model
plot(forest_model)

#evaluating model results
#obtain model results on testing data excluding profit column in testingdata
model_results <- compute(forest_model, testingdata[1:11])

#obtaining predicted profit values for testing dataset
predicted_area <- model_results$net.result

#examine correlation between predicted and actual values
cor(predicted_area, testingdata$area)
#[1,] 0.3943302
# accuracy of model is 39.43%

#Next: improving the accuracy of model by setting hidden value to  5 i.e.  hidden nodes
forest_model2 <- neuralnet(formula = area ~ ., data = trainingdata, hidden = 5)

#plot the model
plot(forest_model2)

#evaluating model results
#obtain model results on testing data excluding profit column in testingdata
model_results2 <- compute(forest_model2, testingdata[1:11])

#obtaining predicted profit values for testing dataset
predicted_area2 <- model_results2$net.result

#examine correlation between predicted and actual values
cor(predicted_area2, testingdata$area)
#[1,] 0.3994953
# accuracy of model is 40%

#Next: improving the accuracy of model by setting hidden value to  15 i.e.  hidden nodes
forest_model3 <- neuralnet(formula = area ~ ., data = trainingdata, hidden = 15, stepmax = 1e+07)

#plot the model
plot(forest_model3)

#evaluating model results
#obtain model results on testing data excluding profit column in testingdata
model_results3 <- compute(forest_model3, testingdata[1:11])

#obtaining predicted profit values for testing dataset
predicted_area3 <- model_results3$net.result

#examine correlation between predicted and actual values
cor(predicted_area3, testingdata$area)
#[1,] 0.2717017
# accuracy of model is 27.17%