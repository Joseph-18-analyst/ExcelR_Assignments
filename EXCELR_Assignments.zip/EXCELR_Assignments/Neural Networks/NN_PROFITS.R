#BUISNESS PROBLEM
#Build a Neural Network model for 50_startups data to predict profit 

# Install Package - "caret" required for Partitioning / Data Slicing
install.packages ("caret")
library (caret)

install.packages("neuralnet")
library(neuralnet)  # regression

install.packages("nnet")
library(nnet) # classification 

install.packages("plyr")
library(plyr)

#loading dataset concrete
profits <- read.csv(file.choose())

#VIEWING DATA set, it has 50 rows and 5 dimensions/columns
View(profits)

#structure of dataset
str(profits)
# 'data.frame':	50 obs. of  5 variables:
# $ R.D.Spend      : num  165349 162598 153442 144372 142107 ...
# $ Administration : num  136898 151378 101146 118672 91392 ...
# $ Marketing.Spend: num  471784 443899 407935 383200 366168 ...
# $ State          : Factor w/ 3 levels "California","Florida",..: 3 1 2 3 2 3 1 2 3 1 ...
# $ Profit         : num  192262 191792 191050 182902 166188 ...

# dimension state has Factor data type
# it needs to be converted to dummy variables
#will be assigning valued 0 to New york, 1 = california, 2= florida
profits$State <- as.numeric(revalue(profits$State, c("New York" = "0", "California" = "1", "Florida"="2")))

#structure of updated dataset profits
str(profits)
# 'data.frame':	50 obs. of  5 variables:
# $ R.D.Spend      : num  165349 162598 153442 144372 142107 ...
# $ Administration : num  136898 151378 101146 118672 91392 ...
# $ Marketing.Spend: num  471784 443899 407935 383200 366168 ...
# $ State          : num  3 1 2 3 2 3 1 2 3 1 ...
# $ Profit         : num  192262 191792 191050 182902 166188 ...

#need to standardize the values, as values in all columns have different scale
#using normalizing function
normalize <- function(x){return((x-min(x))/(max(x)-min(x)))}

#applying above normalize function to standardize data in concrete dataset
#using list apply function: lapply
norm_profits <- as.data.frame(lapply(profits, FUN = normalize))


#summary of dataset
summary(norm_profits)

#preparing training and test dataset
#training = 75%, testing = 25%
datapartition <- createDataPartition(norm_profits$Profit, p=0.75, list = F)
trainingdata <- norm_profits[datapartition, ]
testingdata <- norm_profits[-datapartition, ]

#building neural network model, with 1 simple hiddden neuron
profit_model <- neuralnet(formula = Profit~., data = trainingdata)

#plotting the model
plot(profit_model)

#evaluating model results
#obtain model results on testing data excluding profit column in testingdata
model_results <- compute(profit_model, testingdata[1:4])

#obtaining predicted profit values for testing dataset
predicted_strength <- model_results$net.result

#examine correlation between predicted and actual values
cor(predicted_strength, testingdata$Profit)
#[1,] 0.9643712
#accuracy of model is 96.44%, small r value

#Next: improving the accuracy of model by setting hidden value to  5 i.e.  hidden nodes
profit_model <- neuralnet(formula = Profit~., data = trainingdata, hidden = 5)

#plotting the model
plot(profit_model)

#evaluating model results
#obtain model results on testing data excluding profit column in testingdata
model_results1 <- compute(profit_model, testingdata[1:4])

#obtaining predicted profit values for testing dataset
predicted_strength <- model_results1$net.result

#examine correlation between predicted and actual values
cor(predicted_strength, testingdata$Profit)
#[1,] 0.9708064
#accuracy of model is 97.08%, small r value

#Next: improving the accuracy of model by setting hidden value to 15  i.e.  hidden nodes
profit_model <- neuralnet(formula = Profit~., data = trainingdata, hidden = 15)

#plotting the model
plot(profit_model)

#evaluating model results
#obtain model results on testing data excluding profit column in testingdata
model_results2 <- compute(profit_model, testingdata[1:4])

#obtaining predicted profit values for testing dataset
predicted_strength2 <- model_results2$net.result

#examine correlation between predicted and actual values
cor(predicted_strength2, testingdata$Profit)
#[1,] 0.9810666
#accuracy of model is 98.10%, small r value