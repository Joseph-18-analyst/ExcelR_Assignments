# Perform Principal component analysis and perform clustering using first 
# 3 principal component scores (both heirarchial and k mean clustering(scree plot or elbow curve)
# and obtain optimum number of clusters 
# and check whether we have obtained same number of clusters with the original data 
# (class column we have ignored at the begining who shows it has 3 clusters)df

# Package - 'gdata' required for PCA Algorithm
install.packages ("gdata")
library(gdata)

# Package 'dplyr' required for Hierarchical Clustering
install.packages ("dplyr")
library (dplyr)

install.packages("cluster")
library(cluster)

# Package 'plyr' required for K Means Clustering
install.packages ("plyr")
library (plyr)

#loading the transaction retail.csv dataset, value 1 is for first tab in excel sheet
pcawine <- read.csv(file.choose(), 1)

#dataset has 178 observations and 14 dimesnions. Viewing the dataset
View(pcawine)

#drop the first column "type"
pcawine <- pcawine[,-1]

#summary of dataset
summary(pcawine)

#perform PCA using function princomp function, this function accepts data which is only numeric in nature
#cor = true; it means use correlation matrix, internally standaridizes the data
#covmat = NULL; means use of covariance matrix is false, wont be used in PCA 
#scores = true: means final output scores
pca_wine <- princomp(pcawine, cor = TRUE, scores = TRUE, covmat = NULL)

pca_wine
# Call:
# princomp(x = pcawine, cor = TRUE, scores = TRUE, covmat = NULL)
# 
# Standard deviations:
#    Comp.1    Comp.2    Comp.3    Comp.4    Comp.5    Comp.6    Comp.7    Comp.8    Comp.9 
# 2.1692972 1.5801816 1.2025273 0.9586313 0.9237035 0.8010350 0.7423128 0.5903367 0.5374755 
#   Comp.10   Comp.11   Comp.12   Comp.13 
# 0.5009017 0.4751722 0.4108165 0.3215244 
# 13  variables and  178 observations.

summary(pca_wine)
# Importance of components:
#                           Comp.1    Comp.2    Comp.3    Comp.4     Comp.5     Comp.6     Comp.7
# Standard deviation     2.1692972 1.5801816 1.2025273 0.9586313 0.92370351 0.80103498 0.74231281
# Proportion of Variance 0.3619885 0.1920749 0.1112363 0.0706903 0.06563294 0.04935823 0.04238679
# Cumulative Proportion  0.3619885 0.5540634 0.6652997 0.7359900 0.80162293 0.85098116 0.89336795
#                           Comp.8     Comp.9    Comp.10    Comp.11    Comp.12     Comp.13
# Standard deviation     0.59033665 0.53747553 0.50090167 0.47517222 0.41081655 0.321524394
# Proportion of Variance 0.02680749 0.02222153 0.01930019 0.01736836 0.01298233 0.007952149
# Cumulative Proportion  0.92017544 0.94239698 0.96169717 0.97906553 0.99204785 1.000000000


#loadings talks about weights
loadings(pca_wine)
# 
# Loadings:
#                 Comp.1 Comp.2 Comp.3 Comp.4 Comp.5 Comp.6 Comp.7 Comp.8 Comp.9 Comp.10 Comp.11
# Alcohol          0.144  0.484  0.207         0.266  0.214         0.396  0.509  0.212   0.226 
# Malic           -0.245  0.225        -0.537         0.537 -0.421               -0.309         
# Ash                     0.316 -0.626  0.214  0.143  0.154  0.149 -0.170 -0.308          0.499 
# Alcalinity      -0.239        -0.612               -0.101  0.287  0.428  0.200         -0.479 
# Magnesium        0.142  0.300 -0.131  0.352 -0.727        -0.323 -0.156  0.271                
# Phenols          0.395        -0.146 -0.198  0.149               -0.406  0.286 -0.320  -0.304 
# Flavanoids       0.423        -0.151 -0.152  0.109               -0.187        -0.163         
# Nonflavanoids   -0.299        -0.170  0.203  0.501 -0.259 -0.595 -0.233  0.196  0.216  -0.117 
# Proanthocyanins  0.313        -0.149 -0.399 -0.137 -0.534 -0.372  0.368 -0.209  0.134   0.237 
# Color                   0.530  0.137               -0.419  0.228               -0.291         
# Hue              0.297 -0.279         0.428  0.174  0.106 -0.232  0.437        -0.522         
# Dilution         0.376 -0.164 -0.166 -0.184  0.101  0.266                0.137  0.524         
# Proline          0.287  0.365  0.127  0.232  0.158  0.120         0.120 -0.576  0.162  -0.539 
# Comp.12 Comp.13
# Alcohol          0.266         
# Malic           -0.122         
# Ash                     -0.141 
# Alcalinity                     
# Magnesium                      
# Phenols          0.304  -0.464 
# Flavanoids               0.832 
# Nonflavanoids            0.114 
# Proanthocyanins         -0.117 
# Color           -0.604         
# Hue             -0.259         
# Dilution        -0.601  -0.157 
# Proline                        
# 
#                Comp.1 Comp.2 Comp.3 Comp.4 Comp.5 Comp.6 Comp.7 Comp.8 Comp.9 Comp.10 Comp.11
# SS loadings     1.000  1.000  1.000  1.000  1.000  1.000  1.000  1.000  1.000   1.000   1.000
# Proportion Var  0.077  0.077  0.077  0.077  0.077  0.077  0.077  0.077  0.077   0.077   0.077
# Cumulative Var  0.077  0.154  0.231  0.308  0.385  0.462  0.538  0.615  0.692   0.769   0.846
#                 Comp.12 Comp.13
# SS loadings      1.000   1.000
# Proportion Var   0.077   0.077
# Cumulative Var   0.923   1.000


#scatter plot to show the variances component wise
plot(pca_wine)

biplot(pca_wine)

pca_wine$scores


#next part
#perform clustering using first 3 principal component scores (both heirarchical and 
#k mean clustering(scree plot or elbow curve) and obtain optimum number of clusters 

#considering first three PCA components

pcaclwine <- as.data.frame (pca_wine$scores[,1:3])
# above data set has now 178 observations and 3 columns
# columns has been reduced from 13 to 3 columns

#normalizing data using scale() function
nrmpcawine <- scale(pcaclwine)

#measuring distance using euclidean 
d <- dist(nrmpcawine, method = "euclidean") 
d

#performing heirarchical clustering
hclustwine <- hclust(d, method = "complete")

#plot the dendrogram
windows()
plot(hclustwine, hang = -1)

#grouping means cutting into 4 clusters using cutree() function
groups <- cutree(hclustwine, k = 4)
groups

table(groups)
#number of rows per cluster, here clusters is 4
#  1   2   3   4 
#107  15   3  53

#showing clusters in red border using rect.hclust() method
rect.hclust(hclustwine, k=4, border = "red")

# Creating a Data Set by combining pcawine and Cluster Id.
pcawinecluster <- cbind (pcawine, groups)

# View the above created Data Set.
View (pcawinecluster)

# Get the Average Data for 4 Clusters of each column in dataset.
aggregate (pcawinecluster[,1:13], by=list(pcawinecluster$groups), FUN = mean)
# Group.1    Alcohol    Malic      Ash Alcalinity Magnesium  Phenols Flavanoids Nonflavanoids
# 1       1 13.46654 2.625981 2.440187   19.09720 103.45794 2.296075   1.941589     0.3699065
# 2       2 12.68933 1.392667 1.882000   15.66000  97.46667 2.192000   2.077333     0.2680000
# 3       3 12.53333 1.923333 3.016667   27.83333 127.33333 3.036667   3.550000     0.3833333
# 4       4 12.17453 2.042075 2.318113   20.91132  91.32075 2.280377   2.106604     0.3709434
#   Proanthocyanins    Color       Hue Dilution  Proline
# 1        1.545514 6.337383 0.8843925 2.452617 876.1776
# 2        1.584667 3.884000 1.1460000 2.745333 710.3333
# 3        1.916667 4.310000 1.1233333 3.463333 760.0000
# 4        1.665849 2.850000 1.0421887 2.846792 495.4906


#perform hierarchichal clustering on orginal data set "pcawine"
#which has 13 dimensions

#normalizing data using scale() function
nrmlwine <- scale(pcawine [,1:13])

#measuring distance using euclidean 
d <- dist(nrmlwine, method = "euclidean") 
d

#performing heirarchical clustering
hclustwine <- hclust(d, method = "complete")

#plot the dendrogram
windows()
plot(hclustwine, hang = -1)

#grouping means cutting into 4 clusters using cutree() function
groups <- cutree(hclustwine, k = 4)
groups

table(groups)
# groups
#  1  2  3  4 
# 57 58 12 51
# number of clusters is 4, for each cluster number of rows is given above
# Comparing these  PCA cluster data where 3 colums are taken to data set with all 13 columns:
# number of rows in both dataset does not match for each of 4 clusters
# PCA data with 3 columns capture only 67% of data, this might be the reason for variance

#showing clusters in red border using rect.hclust() method
rect.hclust(hclustwine, k=4, border = "red")

# Creating a Data Set by combining pcawine and Cluster Id.
wineDataCluster <- cbind (pcawine, groups)

# View the above created Data Set.
View (wineDataCluster)

# Get the Average Data for 4 Clusters of each column in dataset.
aggregate (wineDataCluster[,1:13], by=list(wineDataCluster$groups), FUN = mean)
#   Group.1  Alcohol    Malic      Ash Alcalinity Magnesium  Phenols Flavanoids Nonflavanoids
# 1       1 13.60421 1.982807 2.360526   16.65263 106.36842 2.797719  2.9201754     0.2743860
# 2       2 12.41517 1.989828 2.381379   21.11724  93.84483 2.424828  2.3398276     0.3668966
# 3       3 12.46500 1.500833 2.045833   17.34167  98.50000 1.913333  1.4758333     0.4025000
# 4       4 13.11784 3.322157 2.431765   21.33333  99.33333 1.675686  0.8105882     0.4443137
#   Proanthocyanins    Color       Hue Dilution   Proline
# 1        2.015088 5.326667 1.0515789 3.141228 1073.0526
# 2        1.678103 3.280345 1.0579310 2.978448  573.3793
# 3        0.967500 3.395000 1.1555000 2.156667  565.0000
# 4        1.164314 7.170980 0.6913725 1.709804  622.4902

#PERFROM K-MEAN CLUSTERING ON NORMALIZED DATASET: "nrmpcaclwine" USING KMEANS METHOD
#CHOSE NUMBER OF CLUSTERS I.E K =5
wine_kmeans <- kmeans(nrmpcawine, 5)

#structure- str tells about clusters and its centers
str(wine_kmeans)
# List of 9
# $ cluster     : int [1:178] 3 4 3 3 1 3 4 3 4 4 ...
# $ centers     : num [1:5, 1:3] 0.045 -0.128 1.172 0.926 -1.261 ...
# ..- attr(*, "dimnames")=List of 2
# .. ..$ : chr [1:5] "1" "2" "3" "4" ...
# .. ..$ : chr [1:3] "Comp.1" "Comp.2" "Comp.3"
# $ totss       : num 531
# $ withinss    : num [1:5] 52.8 36 18 15.1 47.5
# $ tot.withinss: num 169
# $ betweenss   : num 362
# $ size        : int [1:5] 36 33 36 24 49
# $ iter        : int 4
# $ ifault      : int 0
# - attr(*, "class")= chr "kmeans"

wine_kmeans$centers
#        Comp.1      Comp.2      Comp.3
# 1  0.04496962 -0.80321108 -1.24165768
# 2 -0.12796606 -1.21855122  0.60898455
# 3  1.17204730  0.86631765 -0.06280851
# 4  0.92565437  0.01647133  0.81926243
# 5 -1.26133538  0.76622534  0.14697948

#Building SCREE PLOT to check optimum cluster K value
#creating a variable and assigning it to NULL 

twss <- NULL
for (i in 2:15) {twss <- c(twss,kmeans(nrmpcawine, centers =  i)$tot.withinss)}
twss
# [1] 380.37034 251.34608 184.48624 165.34181 134.87867 122.49059 110.17875 100.13801  91.21680
# [10]  88.90760  78.08521  75.53969  75.43269  62.76206

#using twss values given above, we will be plotting scree-plot or elbow curve to perfrom k(cluster) Selection
# x- axis will have K values(clusters) and Y-axis will have within sum of squares(wss) values

plot(twss, type = "b", xlab = "NUmber of Clusters", ylab = "within group sum of squares")
title(sub = "k-means Clustering scree plot")

#from scree plot from K value 5 (in graph it is 4) to K Value 6( in graph it is 5) we can see maximum 
#net reduction in similarities. We can conclude saying k = 6 cluster will be optimum clusters
# 6 IS OPTIMUM NUMBER OF CLUSTERS OBTAINED FROM SCREE-PLOT/ELBOW PLOT.

#PERFROM K-MEAN CLUSTERING ON NORMALIZED DATASET: "nrmpcaclwine" USING KMEANS METHOD
#CHOSE NUMBER OF CLUSTERS I.E K =6
kmeanscl <- kmeans(nrmpcawine, 6)


#structure of kmeanscl
str(kmeanscl)
# List of 9
# $ cluster     : int [1:178] 3 4 3 3 6 3 4 3 4 4 ...
# $ centers     : num [1:6, 1:3] -0.2002 -1.2649 1.1539 0.921 0.0219 ...
# ..- attr(*, "dimnames")=List of 2
# .. ..$ : chr [1:6] "1" "2" "3" "4" ...
# .. ..$ : chr [1:3] "Comp.1" "Comp.2" "Comp.3"
# $ totss       : num 531
# $ withinss    : num [1:6] 30.4 45.7 19.4 12.8 24.7 ...
# $ tot.withinss: num 141
# $ betweenss   : num 390
# $ size        : int [1:6] 27 48 37 23 37 6
# $ iter        : int 4
# $ ifault      : int 0
# - attr(*, "class")= chr "kmeans"

# Creating a Data Set by combining Wine Data and Cluster Id obtained via K-Means Algorithm.
pcawinedatakmeans<- cbind (pcawine, kmeanscl$cluster)

# View the above Created Data Set.
View (pcawinedatakmeans)

# Get the Number of Rows Per Cluster.
table (pcawinedatakmeans$`kmeanscl$cluster`)
# Output
#  1  2  3  4  5  6 
# 27 48 37 23 37  6 

#next step to perform kmeans clusterting on actual wine data having 13 dimensions/columns data set
#dataset
#CHOSE NUMBER OF CLUSTERS I.E K =5

kmeansclu <- kmeans(nrmlwine,5)

#output the structure of dataset
str(kmeansclu)
# List of 9
# $ cluster     : int [1:178] 1 1 1 1 4 1 1 1 1 1 ...
# $ centers     : num [1:5, 1:13] 0.999 0.186 -0.781 -0.692 -0.871 ...
# ..- attr(*, "dimnames")=List of 2
# .. ..$ : chr [1:5] "1" "2" "3" "4" ...
# .. ..$ : chr [1:13] "Alcohol" "Malic" "Ash" "Alcalinity" ...
# $ totss       : num 2301
# $ withinss    : num [1:5] 239 303 209 103 248
# $ tot.withinss: num 1102
# $ betweenss   : num 1199
# $ size        : int [1:5] 53 49 24 11 41
# $ iter        : int 4
# $ ifault      : int 0
# - attr(*, "class")= chr "kmeans"

#Building SCREE PLOT to check optimum cluster K value
#creating a variable and assigning it to NULL 

twss <- NULL
for (i in 2:15) {twss <- c(twss,kmeans(nrmlwine, centers =  i)$tot.withinss)}
twss
# [1] 1649.6877 1270.7491 1177.1803 1109.4840 1033.3141 1006.9846  953.4784  898.2754  893.4882
# [10]  821.7050  790.6657  771.0775  718.9799  719.7420

#using twss values given above, we will be plotting scree-plot or elbow curve to perfrom k(cluster) Selection
# x- axis will have K values(clusters) and Y-axis will have within sum of squares(wss) values

plot(twss, type = "b", xlab = "NUmber of Clusters", ylab = "within group sum of squares")
title(sub = "k-means Clustering scree plot")

#from scree plot from K value  7(in graph it is 6) to K Value 8( in graph it is 7) we can see maximum 
#net reduction in similarities. We can conclude saying k = 8 cluster will be optimum clusters
# 6 IS OPTIMUM NUMBER OF CLUSTERS OBTAINED FROM SCREE-PLOT/ELBOW PLOT.

#PERFROM K-MEAN CLUSTERING ON NORMALIZED DATASET: "nrmlwine" USING KMEANS METHOD
#CHOSE NUMBER OF CLUSTERS I.E K =8
kmeanscl <- kmeans(nrmlwine, 8)


#structure of dataset
str(kmeanscl)
# List of 9
# $ cluster     : int [1:178] 4 4 4 4 7 4 4 4 4 4 ...
# $ centers     : num [1:8, 1:13] 0.4898 -0.2034 -0.5936 0.968 0.0555 ...
# ..- attr(*, "dimnames")=List of 2
# .. ..$ : chr [1:8] "1" "2" "3" "4" ...
# .. ..$ : chr [1:13] "Alcohol" "Malic" "Ash" "Alcalinity" ...
# $ totss       : num 2301
# $ withinss    : num [1:8] 77.7 53.1 122.6 265.4 97.2 ...
# $ tot.withinss: num 947
# $ betweenss   : num 1354
# $ size        : int [1:8] 17 11 16 54 23 28 9 20
# $ iter        : int 2
# $ ifault      : int 0
# - attr(*, "class")= chr "kmeans"

# Creating a Data Set by combining Wine Data and Cluster Id obtained via K-Means Algorithm.
winedatakmeans<- cbind (pcawine, kmeanscl$cluster)

# View the above Created Data Set.
View (winedatakmeans)

# Get the Number of Rows Per Cluster.
table (winedatakmeans$`kmeanscl$cluster`)
# Output
#  1  2  3  4  5  6  7  8 
# 17 11 16 54 23 28  9 20 

# clusters do not match between PCA data and actual dataset data