#BUISNESS PROBLEM
#Use decision trees to prepare a model on fraud data 
#treating those who have taxable_income <= 30000 as "Risky" and others are "Good"

# installing packages for Decision Tree type C5.0
install.packages("C50")
library(C50)

#Installing packages caret required for paritioning
install.packages("caret")
library(caret)

#LOADING DATASET
fraudcheck <- Fraud_check

#viewing the dataset
View(fraudcheck)

#getting structure of dataset
str(fraudcheck)
#'data.frame':	600 obs. of  6 variables:
#$ Undergrad      : Factor w/ 2 levels "NO","YES": 1 2 1 2 1 1 1 2 1 2 ...
#$ Marital_Status : Factor w/ 3 levels "Divorced","Married",..: 3 1 2 3 2 1 1 3 3 1 ...
#$ Taxable_Income : int  68833 33700 36925 50190 81002 33329 83357 62774 83519 98152 ...
#$ City_Population: int  50047 134075 160205 193264 27533 116382 80890 131253 102481 155482 ...
#$ Work_Experience: int  10 18 30 15 28 0 8 3 12 4 ...
#$ Urban          : Factor w/ 2 levels "NO","YES": 2 2 2 2 1 1 2 2 2 2 ...

#check if any missing values in dataset
anyNA(fraudcheck)
#[1] FALSE
#no missing values in dataset

#target output variable/column is "Taxable_income"
#Getting summary of column "taxable_Column"
summary(fraudcheck$Taxable_Income)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#10003   32872   55075   55208   78612   99619 

#output variable column "taxable_income" has values in continuous format, needs to be converted
#categorical format using cut() function. 
#dividing into 3 categorical ranges
# ===================================================
# <= 30000 - Risky
# 30000 to 60000 - Low TI
# > 60000 - High TI
# ===================================================

taxable_income <- cut(fraudcheck$Taxable_Income, breaks = c(0, 30000, 60000, 100000),labels=c("Risky", "LowTI", "HighTI"))

#Ouput taxable_income values
taxable_income

#replacing this to column "Taxable_Income" in fraudcheck dataset
fraudcheck <- cbind (taxable_income, fraudcheck[,-3])

#view updated fraudcheck dataset
View(fraudcheck)

#paritioning data set into test data: 25% and training data set: 75%
# On Performing createDataPartition, it splits the rows randomly.
# In the below case, we are splitting the rows randomly in 75:25 ratio.
# The randomly selected row numbers are stored in "inTraininglocal"
inTraininglocal <- createDataPartition(fraudcheck$taxable_income, p = 0.75, list = F)

# Use this to create Training and Testing Data Set.
training <- fraudcheck[inTraininglocal,]
testing <- fraudcheck[-inTraininglocal,]

#checking dimensions of training dataset
dim(training)
#[1] 451   6
#451 observations and 6 dimensions/columns

#checking dimensions of testing dataset
dim(testing)
#[1] 149   6
#149 observations and 6 columns

#applyging decision tree C5.0 algorithm on training data set 
#c5.0 parameters c5.0(Y~x1+x2+x3..., data = <data-set>) or
#c5.0 parameters c5.0(y~.,data =<data-set>)
model <- C5.0(training$taxable_income~., data = training)

#summary of model
summary(model)
#Call:
#  C5.0.formula(formula = training$taxable_income ~ ., data = training)
#
#
#C5.0 [Release 2.07 GPL Edition]  	Fri Mar 29 14:29:03 2019
#-------------------------------
#  
#  Class specified by attribute `outcome'
#
#Read 451 cases (6 attributes) from undefined.data
#
#Decision tree:
#
#Urban = NO:
#:...Marital_Status = Single: HighTI (72/41)
#:   Marital_Status = Divorced:
#:   :...Work_Experience > 24:
#:   :   :...Work_Experience <= 28: HighTI (13/1)
#:   :   :   Work_Experience > 28: LowTI (7/4)
#:   :   Work_Experience <= 24:
#:   :   :...Undergrad = NO: LowTI (32/17)
#:   :       Undergrad = YES:
#:   :       :...Work_Experience > 20: LowTI (6/2)
#:   :           Work_Experience <= 20:
#:   :           :...City_Population <= 52940: Risky (2)
#:   :               City_Population > 52940:
#:   :               :...City_Population <= 162102: HighTI (20/8)
#:   :                   City_Population > 162102: Risky (2/1)
#:   Marital_Status = Married:
#:   :...Undergrad = YES:
#:       :...City_Population <= 168473: LowTI (32/16)
#:       :   City_Population > 168473:
#:       :   :...City_Population <= 186239: HighTI (3)
#:       :       City_Population > 186239: LowTI (3/1)
#:       Undergrad = NO:
#:       :...Work_Experience > 26: HighTI (6/2)
#:           Work_Experience <= 26:
#:           :...Work_Experience > 13: LowTI (14/3)
#:               Work_Experience <= 13:
#:               :...City_Population <= 89965: HighTI (6/1)
#:                   City_Population > 89965:
#:                   :...Work_Experience <= 5: LowTI (3)
#:                       Work_Experience > 5: Risky (4/2)
#Urban = YES:
#:...Work_Experience <= 8:
#:...City_Population <= 118798: HighTI (40/10)
#:   City_Population > 118798:
#:   :...Work_Experience <= 2: LowTI (7/1)
#:       Work_Experience > 2:
#:       :...City_Population <= 141502: Risky (7/2)
#:           City_Population > 141502:
#:           :...City_Population <= 186239: HighTI (12/1)
#:               City_Population > 186239: Risky (2/1)
#Work_Experience > 8:
#:...Work_Experience <= 11:
#:...Marital_Status = Married: LowTI (7/2)
#:   Marital_Status = Divorced:
#:   :...City_Population <= 94199: LowTI (2)
#:   :   City_Population > 94199: HighTI (4)
#:   Marital_Status = Single:
#:   :...Undergrad = NO: HighTI (2)
#:       Undergrad = YES:
#:       :...City_Population <= 95831: HighTI (4/1)
#:           City_Population > 95831: LowTI (2)
#Work_Experience > 11:
#:...Undergrad = NO:
# #:...Marital_Status = Married: HighTI (24/11)
# :   Marital_Status = Divorced:
# :   :...Work_Experience > 25: HighTI (6)
# :   :   Work_Experience <= 25:
# :   :   :...Work_Experience <= 17: HighTI (5/2)
# :   :       Work_Experience > 17: LowTI (5/2)
# :   Marital_Status = Single:
# :   :...City_Population <= 97526: HighTI (12/5)
# :       City_Population > 97526:
# :       :...City_Population <= 135886:
# :           :...City_Population > 124440: Risky (3)
# :           :   City_Population <= 124440:
# :           :   :...City_Population <= 111774: Risky (2)
# :           :       City_Population > 111774: LowTI (3)
# :           City_Population > 135886:
# :           :...City_Population > 161265: LowTI (3)
# :               City_Population <= 161265:
# :               :...City_Population <= 143349: LowTI (2)
# :                   City_Population > 143349: HighTI (2)
# Undergrad = YES:
# :...Marital_Status = Married: LowTI (21/11)
# Marital_Status = Divorced:
# :...Work_Experience <= 17:
# :   :...City_Population <= 157025: Risky (3)
# :   :   City_Population > 157025: HighTI (2)
# :   Work_Experience > 17:
# :   :...City_Population > 158849: Risky (3/1)
# :       City_Population <= 158849:
# :       :...City_Population > 106757: LowTI (4)
# :           City_Population <= 106757:
# :           :...Work_Experience <= 26: HighTI (3)
# :               Work_Experience > 26: LowTI (4/1)
# Marital_Status = Single:
# :...Work_Experience > 21:
# :...Work_Experience <= 25: HighTI (7)
# :   Work_Experience > 25: LowTI (5/2)
# Work_Experience <= 21:
# :...Work_Experience > 17: Risky (7/3)
# Work_Experience <= 17:
# :...Work_Experience <= 12: LowTI (2)
# Work_Experience > 12:
# :...Work_Experience <= 14: HighTI (2)
# Work_Experience > 14: LowTI (7/3)
# 
# 
# Evaluation on training data (451 cases):
# 
# Decision Tree   
# ----------------  
# Size      Errors  
# 
# 51  158(35.0%)   <<
# 
# 
# (a)   (b)   (c)    <-classified as
# ----  ----  ----
# 25    31    37    (a): class Risky
# 6    106    46    (b): class LowTI
# 4     34   162    (c): class HighTI
# 
# 
# Attribute usage:
# 
# 100.00%	Urban
# 84.92%	Marital_Status
# 75.61%	Work_Experience
# 61.64%	Undergrad
# 44.57%	City_Population
# 
# 
# Time: 0.0 secs

#plotting decision tree
windows()
plot(model)

#making prediction by using above training model on test data, 
#[,2:11means not considering first column "categorySales" which is Y COORDINATE 
pred <- predict.C5.0(model, testing[,2:6])

#compare predicted value to actual value in test data set for y cordinate: species
a <- table(testing$taxable_income, pred)

#printing accuracy table
a
#       pred
#        Risky LowTI HighTI
# Risky      4    12     15
# LowTI      3    22     27
# HighTI     4    19     43

#compute the testing accuracy of model
sum(diag(a))/sum(a)
#[1] 0.4630872
#46.31% is accuracy of model

##CODE FOR ENSEMBLE METHOD TYPE BAGGING OR BOOTSTRAPPING AGGREGATING

#create empty vector c
acc <- c()

#RANDOM FORESTS TECHNIQUES BEING APPLIED
#create a for loop to run bagging model 50 times
#next inside for loop
#paritioning data set into test data: 15% and training data set: 85%
#Assigning training data set to variable training1, test data set to variable testing
#assigning c5.0 algorithm to training1 i.e. training data set
#model built is assigned to variable fittree
#model in fittree is used to compare it on test data stored in variable:testing
#compare the value got from test data to actual test data value, store it in variable a
#create a list to store the accuracy values of 50 models and assign to variable acc: acc <- (acc,model1 accuracy, model2 accuracu..till model50 accuracy )
#compute the accuracy of model using formula sum(diag(a))/sum(a)

for(i in 1:50)
{
  inTraininglocal <- createDataPartition(fraudcheck$taxable_income, p=0.85, list = F)
  training <- fraudcheck[inTraininglocal, ]
  testing <- fraudcheck[-inTraininglocal, ]
  
  fittree <- C5.0(training$taxable_income~., data=training)
  pred <- predict.C5.0(fittree, testing[ ,2:6])
  a <- table(testing$taxable_income,pred)
  acc <- c(acc, sum(diag(a))/sum(a))
}

#Summary of accuracy
summary(acc)
#  Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.2841  0.3977  0.4205  0.4277  0.4659  0.5568 

#gives accuracy values of all 50 models invidually
acc

hist(acc)

#Boosting model under Decision Tree
#Loading datset
#paritioning data set into test data: 25% and training data set: 75%
inTraininglocal <- createDataPartition(fraudcheck$taxable_income, p=0.75, list = F)
training <- fraudcheck[inTraininglocal, ]
testing <- fraudcheck[-inTraininglocal, ]

#running boosting technique by giving variable "trials" and setting value, here it is set to 10
#Boosting Model using C5.0 Algorithm on Training Data Set.
boostmodel <- C5.0(training$taxable_income~., data =training, trials = 10)
summary(boostmodel)
# Evaluation on training data (451 cases):
#   
#   Trial	    Decision Tree   
# -----	  ----------------  
#   Size      Errors  
# 
# 0	    39  165(36.6%)
# 1	    19  195(43.2%)
# 2	    18  195(43.2%)
# boost	    168(37.3%)   <<
#   
#   
#   (a)   (b)   (c)    <-classified as
# ----  ----  ----
#   28    24    41    (a): class Risky
#    9    82    67    (b): class LowTI
#    7    20   173    (c): class HighTI
# 
# 
# Attribute usage:
#   
#   100.00%	Urban
# 90.24%	Work_Experience
# 85.14%	Marital_Status
# 81.15%	City_Population
# 66.52%	Undergrad
# 
# 
# Time: 0.0 secs

#next is to combine bagging and boosting model.
#with for loop we create bagging model, inside for loop of bagging model, 
#apply boosting model code
acc <- c()

for(i in 1:50)
{
  inTraininglocal <- createDataPartition(fraudcheck$taxable_income, p=0.85, list = F)
  training <- fraudcheck[inTraininglocal, ]
  testing <- fraudcheck[-inTraininglocal, ]
  
  fittree <- C5.0(training$taxable_income~., data=training, trials = 10)
  pred <- predict.C5.0(fittree, testing[ ,2:6])
  a <- table(testing$taxable_income,pred)
  acc <- c(acc, sum(diag(a))/sum(a))
}

#Summary of accuracy
summary(acc)
#Ouput
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#0.2841  0.3864  0.4318  0.4184  0.4432  0.4886 

#gives accuracy values of all 50 models invidually
acc

#histogram of accuracy list
hist(acc)
