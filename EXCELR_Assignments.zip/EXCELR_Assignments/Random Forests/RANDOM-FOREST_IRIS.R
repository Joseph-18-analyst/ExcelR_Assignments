#BUISNESS PROBLEM
#Build a decision tree for the 'iris' data with function 'ctree()' in package "party".
#The iris is a built-in dataset in R and looks like this:

#Installing packages caret required for paritioning
install.packages("caret")
library(caret)

# Package "ggplot2" is required for Plotting GGPLOT and ACF Plot
install.packages ("ggplot2")
library(ggplot2)

#installing packages for decision tree using package party
install.packages("party")
library(party)

#loading iris dataset
iris1 <- iris

#iris dataset has 150 observations and 5 dimensions/variables
View(iris1)

#paritioning data set into test data: 25% and training data set: 75%
inTraininglocal <- createDataPartition(iris1$Species, p = 0.75, list = F)

#Assigning training data set to variable training, test data set to variable testing
training <- iris[inTraininglocal,]
testing <- iris[-inTraininglocal,]


#applyging decision ctree() function on training data set 
#ctree parameters ctree(Y~x1+x2+x3..., data = <data-set>) or
#ctree parameters ctree(y~.,data =<data-set>)
model <- ctree(training$Species~., data =training)

model
# Conditional inference tree with 4 terminal nodes
# 
# Response:  training$Species 
# Inputs:  Sepal.Length, Sepal.Width, Petal.Length, Petal.Width 
# Number of observations:  114 
# 
# 1) Petal.Length <= 1.9; criterion = 1, statistic = 106.6
# 2)*  weights = 38 
# 1) Petal.Length > 1.9
# 3) Petal.Width <= 1.6; criterion = 1, statistic = 52.436
# 4) Petal.Length <= 4.6; criterion = 0.996, statistic = 10.995
# 5)*  weights = 30 
# 4) Petal.Length > 4.6
# 6)*  weights = 10 
# 3) Petal.Width > 1.6
# 7)*  weights = 36

trainingaccuracytable <- table(predict(model), training$Species)

trainingaccuracytable
#            setosa versicolor virginica
# setosa         38          0         0
# versicolor      0         37         3
# virginica       0          1        35

#accuracy of trainingdataset
sum(diag(trainingaccuracytable))/sum(trainingaccuracytable)
# [1] 0.9649123
# it is 96.49%

#making prediction by using above training model on test data, [,-5] means not considering last column "species" which is Y COORDINATE 
pred <- predict(model, newdata = testing, type = "response")

#compare predicted value to actual value in test data set for y cordinate: species
a <- table(testing$Species, pred)

#printing accuracy table stored in variable a
a

# pred
#            setosa versicolor virginica
# setosa         12          0         0
# versicolor      0         11         1
# virginica       0          1        11


#compute the testing accuracy of model
sum(diag(a))/sum(a)
#0.9444444
#Accuracy of model is 94.44%

summary(model)

windows()
plot(model)

print(model)

# Bagging (or boot strap aggregation) - Random Forests.
# Random forests or random decision forests are an ensemble learning method for classification, regression and other tasks that 
# operates by constructing a multitude of decision trees at training time and outputting the class that is the mode of the classes 
# (classification) or mean prediction (regression) of the individual trees.Random decision forests correct for decision trees' habit of overfitting to their training set.


# Use the iris Data Set
iris2 <- iris

#creating new list to store accuracy of models being built.
#using for loop going to build 51 models
accuracylist <- c()

#using for loop next to build 51 models
#same method ctree will be build 51 models

for (i in 1:51)
  {
    inTraininglocal <- createDataPartition(iris2$Species, p = 0.85, list = F)
    training <- iris[inTraininglocal,]
    testing <- iris[-inTraininglocal,]
    
    model <- ctree(training$Species ~ ., data = training)
    pred <- predict(model, newdata = testing, type = "response")
    accuracy_table <- table(testing$Species, pred)
    
    #Append the Accuracy for each model into List Variable
    accuracylist <- c(accuracylist, sum(diag(accuracy_table))/ sum(accuracy_table))
}

#accuracylist of 51 models
accuracylist
# [1] 0.9047619 0.9523810 0.9523810 0.9047619 0.9523810 0.9523810 1.0000000 0.8571429 1.0000000
# [10] 0.9523810 0.9523810 0.9523810 0.9523810 0.9523810 0.9047619 0.9523810 0.9523810 0.8095238
# [19] 0.9523810 0.9047619 0.9523810 0.9523810 0.9523810 0.9523810 0.9047619 0.9523810 0.9523810
# [28] 0.9047619 0.9523810 0.9523810 0.8571429 0.9523810 0.9523810 1.0000000 0.9523810 0.9047619
# [37] 1.0000000 0.9047619 0.9047619 0.9523810 0.9523810 0.9047619 0.9523810 0.9047619 0.9523810
# [46] 1.0000000 0.9523810 0.9047619 0.9523810 0.9047619 0.9523810

#summary of accuracylist
summary(accuracylist)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 0.8095  0.9048  0.9524  0.9384  0.9524  1.0000 

# Generate the Histogram for the Accuracy list
hist (accuracylist)

# Generate the Box Plot for the Accuracy List
boxplot (accuracylist)
