#buisness problem
#3) Emp_data -> Build a prediction model for Churn_out_rate 
#Do the necessary transformations for input variables for getting better R^2 value for the model prepared.


# Package 'moments' is required for Skewness and Kurtosis
install.packages ("moments")
library (moments)

# Package "car" is required for Plotting QQPlot.
install.packages ("car")
library (car)

# Package "ggplot2" is required for Plotting GGPLOT and ACF Plot
install.packages ("ggplot2")
library(ggplot2)

#Loading dataset excel sheet "atdata"
atdata2 <- emp_data

#data set has 10 observations for salary hike and churn out rate respectively
View(atdata2)

#First step: performing Exploratory data analysis
#Summary of data set
summary(atdata2)

#Salary_hike   Churn_out_rate 
#Min.   :1580   Min.   :60.00  
#1st Qu.:1618   1st Qu.:65.75  
#Median :1675   Median :71.00  
#Mean   :1689   Mean   :72.90  
#3rd Qu.:1724   3rd Qu.:78.75  
#Max.   :1870   Max.   :92.00  

#Descriptive analysis on independent variable Salary_hike
#lower extreme i.e. min = 1580
#upper extreme i.e. max = 1870
#Q1 = 1618
#Q3 = 1724
#IQR = Q3-Q1 = 106
#outlier upper fence = Q3+1.5(IQR) = 1883
#maximum value in data set is 1870, lesser than 1883 so no possible outlier in upper fence
#outlier lower fence = Q1-1.5(IQR) = 28
#minimum value in data set is 1580, greater than 28 so no possible outlier in lower fence


#first moment buisness decision: mean, median
mean(atdata2$Salary_hike)
#Mean is 1688.6

median(atdata2$Salary_hike)
#Median is 1675

#second moment business decision: variance, standard deviation, range
var(atdata2$Salary_hike)
#variance is 8481.822

sd(atdata2$Salary_hike)
#standard deviation is 92.09681

range(atdata2$Salary_hike)
#range: minimum is 1580 and maximum is 1870

#third moment buisness decision:skewness
skewness(atdata2$Salary_hike)
#skewness is 0.7238458 means slightly right skewed

#fourth moment buisness decision: kurtosis
kurtosis(atdata2$Salary_hike)
#kurtosis is 2.548327

#boxplot
boxplot(atdata2$Salary_hike)
#confirms data is right skewed, no outliers

#histogram
hist(atdata2$Salary_hike)

#to check data is normally distributted using qqnorm and qqline plots
qqnorm(atdata2$Salary_hike)
qqline(atdata2$Salary_hike)
#qqnorm and qqline confirms data is normal.

#Shapiro-Wilk's method is widely recommended for normality test.
shapiro.test (atdata2$Salary_hike)
#P-value is 0.5018 which is greater than 0.05. Data is assumed to be normal.

#to find correlation between x and y variable using cor() function
cor(atdata2$Salary_hike, atdata2$Churn_out_rate)
# correlation value is -0.9117216 which means strong negative correlation between salary hike
# and churn out rate

#scatter plot to check to plot between x and y values
plot(atdata2$Salary_hike, atdata2$Churn_out_rate)
#negative relation is observed in plot.

#next step: to build liner regression model to determine relationship between dependent and independent variable
#dependent variable- Y: curn out rate. Independent variable- x = salary hike

# Building SLR Model using 'lm' function.
# lm (Y~X, data=<data-set>)
model <- lm(atdata2$Churn_out_rate~atdata2$Salary_hike,data=atdata2)

#Summary of regression model is displayed
summary(model)

#B(0)-beta 0 value is  244.36491, p value is  8.934 1.96e-05 so value is significant
#B(1)- beta 1 value is -0.10154, P value is -6.277 0.000239 so value is significant.
#Coefficient of Determination Value - R square Value is 0.8312 (almost 83%).
#since R2 value is above 0.8, strong correlation is seen
#R square Value tells, % of the variation in Y can be explained by X.
#Here 83% variation in chrun out rate can be explained by salary hike.
#final equation
#Churn_out_rate = 244.36491 -0.10154 (Salary_hike)
#Model is built for the following range:"1580 to 1870" of salary hike values

#building SLR models using transformations

#log transformation: logarithmic model
logmodel <- lm(atdata2$Churn_out_rate~log(atdata2$Salary_hike),data=atdata2)
summary(logmodel)

#B(0)-beta 0 value is  1381.5, p value is 0.000105 so value is significant
#B(1)- beta 1 value is -176.1 , P value is 0.000153 so value is significant.
#Coefficient of Determination Value - R square Value is 0.8486 (almost 85%).
#since R2 value is above 0.8, strong correlation and slightly better than vanilla model


#exponential transformation: exponential model
expmodel <- lm(log(atdata2$Churn_out_rate)~atdata2$Salary_hike,data=atdata2)
summary(expmodel)

#B(0)-beta 0 value is  6.6383000, p value is 2.88e-08 so value is significant
#B(1)- beta 1 value is -0.0013963 , P value is 7.38e-05 so value is significant.
#Coefficient of Determination Value - R square Value is 0.8577 (almost 86)%.
#since R2 value is above 0.8, strong correlation and better than vanilla model, logarithmic model


#Quadratic model: 2nd degree polynomial model
quadmodel <- lm(atdata2$Churn_out_rate~atdata2$Salary_hike+I(Churn_out_rate^2),data=atdata2)
summary(quadmodel)

#B(0)-beta 0 value is  65.3862088, p value is  7.13e-07 so value is significant
#B(1)- beta 1 value is  -0.0142633 , P value is 0.000185 so value is significant.
##B(2)- beta 2 value is 0.0058418 , P value is 3.65e-10 so value is significant.
#Coefficient of Determination Value - R square Value is 0.9995 (almost 99)%.
#since R2 value is above 0.8, strong correlation and better than previous models

#Polynomial model: 3rd degree polynomial model
fourthmodel <- lm(atdata2$Churn_out_rate~atdata2$Salary_hike+I(Salary_hike^2)+I(Salary_hike^3),data=atdata2)
summary(fourthmodel)

#B(0)-beta 0 value is  1.320e+04, p value is 0.0148 so value is significant
#B(1)- beta 1 value is -2.194e+01 , P value is 0.0182 so value is significant.
#B(2)- beta 2 value is  1.223e-02, P value is 0.0216 so value is significant.
#B(3)- beta 2 value is -2.276e-06 , P value is 0.0251 so value is significant.
#Coefficient of Determination Value - R square Value is 0.9893 (almost 99)%.
#since R2 value is above 0.8, strong correlation and better than vanilla model, logarithmic and exponential model


# R Squared Values for Various Models
# Vanilla Model : 0.8312 - All Coefficients are significant
# Logarithmic Model : 0.8486 - All Coefficients are significant
# Exponential Model : 0.8577 - All Coefficients are signigicant
# Quadratic Model : 0.9995 - Beta 0, ta 1 Beta 2 is Significant
# Polynomial Model (3rd Degree Model) : 0.9893 - All Coefficients are significant
###########################################################################################################3

# Error Residual analysis on first model: Vanilla model to check below 3 points
# 1. Residuals should be Normally Distributed.
# 2. Homoscedasticity - constant variance - This assumption means that the variance around the 
# regression line is the same for all values of the predictor variable (X).
# 3. Statistical Independence of the Errors - Residuals should not be auto correlated.

#listing residulas or Y hat (Y^) of vanilla model
model$residuals

#Sum of residuals
sum(model$residuals)
# sum of residuals is 4.440892e-16

#mean of residuals:
mean(model$residuals)
# mean of residuals is 4.449566e-17

#to calculate Root Mean square error
sqrt (sum(model$residuals^2)/nrow(atdata2))
#RMSE is 3.997528

# Checking if the Residuals are normally distributed.
shapiro.test (model$residuals)
# p-value is 0.05845 which is greater than 0.05. We can assume normality.
#Point 1 assumption is checked.


# An algorithmic approach to check for heteroscedasticity 
# For this purpose, we have NCV - (Non Constant Error Variance) Test to establish the presence or 
# absence of heteroscedasticity
# Computes a score test of the hypothesis of constant error variance against the alternative that 
# the error variance changes with 
# the level of the response (fitted values), or with a linear combination of predictors.
car::ncvTest(model)
# p-value is 0.1606595. This is greater than 0.05. We accept Null Hypothesis i.e we have constant error 
# variance
# Heteroscedasticity is not present. - Assumption 2 is checked

# ConstructingACF (Auto Correlation Function) Plot
acf (model$residuals)
# If the residuals are not autocorrelated, the vertical bars will be near zero value below the dashed 
# blue line (significance level). In our case all the vertical bars are below the blue line.
# So there is no auto correlation problem. - Assumption 3 is checked.

##########################################################################################

# Error Residual analysis on fourth model: 3rd Degree Model (Polynomial) to check below 3 points
# 1. Residuals should be Normally Distributed.
# 2. Homoscedasticity - constant variance - This assumption means that the variance around the 
# regression line is the same for all values of the predictor variable (X).
# 3. Statistical Independence of the Errors - Residuals should not be auto correlated.

#listing residulas or Y hat (Y^) of vanilla model
fourthmodel$residuals

#Sum of residuals
sum(fourthmodel$residuals)
# sum of residuals is -8.881784e-16

#mean of residuals:
mean(fourthmodel$residuals)
# mean of residuals is -8.882597e-17

#to calculate Root Mean square error
sqrt (sum(fourthmodel$residuals^2)/nrow(atdata2))
#RMSE is 1.0052

# Checking if the Residuals are normally distributed.
shapiro.test (fourthmodel$residuals)
# p-value is 0.8663, which is greater than 0.05.Can assume normality.
#Point 1 assumption is checked.


# An algorithmic approach to check for heteroscedasticity 
# For this purpose, we have NCV - (Non Constant Error Variance) Test to establish the presence or 
# absence of heteroscedasticity
# Computes a score test of the hypothesis of constant error variance against the alternative that 
# the error variance changes with 
# the level of the response (fitted values), or with a linear combination of predictors.
car::ncvTest(fourthmodel)
# p-value is 0.37766. This is greater than 0.05. We accept Null Hypothesis i.e we have constant error 
# variance
# Heteroscedasticity is not present. - Assumption 2 is checked

# ConstructingACF (Auto Correlation Function) Plot
acf (fourthmodel$residuals)
# If the residuals are not autocorrelated, the vertical bars will be near zero value below the dashed 
# blue line (significance level). In our case all the vertical bars are below the blue line.
# So there is no auto correlation problem. - Assumption 3 is checked.

################################################################################################################
#RMSE value of 3rd degree model-Polynomial is 1.0052 is better than Vanilla model RMSE = 3.997528

#Finalizing 3rd Degree polynomial model
#final equation
#churn out rate = 1.320e+04 - 2.194e+01(salary hike) + 1.223e-02 (salary hike^2) - 2.276e-06 (salary hike^3)

# Range for Confidence Interval of 95%.
confint(fourthmodel,level = 0.95)
#output
#                           2.5 %        97.5 %
#(Intercept)          3.654531e+03  2.273912e+04
#atdata2$Salary_hike -3.861930e+01 -5.255724e+00
#I(Salary_hike^2)     2.525628e-03  2.193585e-02
#I(Salary_hike^3)    -4.154996e-06 -3.971350e-07