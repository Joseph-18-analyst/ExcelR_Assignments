#BUISNESS PROBLEM
#4) Salary_hike -> Build a prediction model for Salary_hike
#Do the necessary transformations for input variables for getting better R^2 value for the model prepared.

# Package 'moments' is required for Skewness and Kurtosis
install.packages ("moments")
library (moments)

# Package "car" is required for Plotting QQPlot.
install.packages ("car")
library (car)

# Package "ggplot2" is required for Plotting GGPLOT and ACF Plot
install.packages ("ggplot2")
library(ggplot2)

#Loading dataset excel sheet "atdata"
atdata3 <- Salary_Data

#data set has 30 observations for YearsExperience and salary respectively
View(atdata3)

#First step: performing Exploratory data analysis
#Summary of data set
summary(atdata3)

#YearsExperience      Salary      
#Min.   : 1.100   Min.   : 37731  
#1st Qu.: 3.200   1st Qu.: 56721  
#Median : 4.700   Median : 65237  
#Mean   : 5.313   Mean   : 76003  
#3rd Qu.: 7.700   3rd Qu.:100545  
#Max.   :10.500   Max.   :122391

#Descriptive analysis on independent variable YearsExperience
#lower extreme i.e. min = 1.100
#upper extreme i.e. max = 10.500
#Q1 = 3.200
#Q3 = 7.700
#IQR = Q3-Q1 = 4.500
#outlier upper fence = Q3+1.5(IQR) = 14.450
#maximum value in data set is 10.500, lesser than 14.450 so no possible outlier in upper fence
#outlier lower fence = Q1-1.5(IQR) = 157.5
#minimum value in data set is 1.100, greater than -3.55 so no possible outlier in lower fence


#first moment buisness decision: mean, median
mean(atdata3$YearsExperience)
#Mean is 5.313333

median(atdata3$YearsExperience)
#Median is 4.7

#second moment business decision: variance, standard deviation, range
var(atdata3$YearsExperience)
#variance is 8.053609

sd(atdata3$YearsExperience)
#standard deviation is 2.837888

range(atdata3$YearsExperience)
#range: minimum is 1.1 and maximum is 10.5

#third moment buisness decision:skewness
skewness(atdata3$YearsExperience)
#skewness is 0.3603123 means slightly right skewed

#fourth moment buisness decision: kurtosis
kurtosis(atdata3$YearsExperience)
#kurtosis is 1.955248

#boxplot
boxplot(atdata3$YearsExperience)
#confirms data is slightly right skewed, no outliers

#histogram
hist(atdata3$YearsExperience)

#to check data is normally distributted using qqnorm and qqline plots
qqnorm(atdata3$YearsExperience)
qqline(atdata3$YearsExperience)
#qqnorm and qqline confirms data is normal.

#Shapiro-Wilk's method is widely recommended for normality test.
shapiro.test (atdata3$YearsExperience)
#P-value is 0.1034 which is greater than 0.05. Data is assumed to be normal.

#to find correlation between x and y variable using cor() function
cor(atdata3$YearsExperience, atdata3$Salary)
# correlation value is 0.9782416 which means strong correlation between calories consumed
# and weight gained

#scatter plot to check to plot between x and y values
plot(atdata3$YearsExperience, atdata3$Salary)
#strong and positive relation is observed in plot.

#next step: to build liner regression model to determine relationship between dependent and independent variable
#dependent variable- Y: weight gained. Independent variable- x = calories consumed

# Building SLR Model using 'lm' function.
# lm (Y~X, data=<data-set>)
model <- lm(atdata3$Salary~atdata3$YearsExperience,data=atdata3)

#Summary of regression model is displayed
summary(model)

#B(0)-beta 0 value is 25792.2, p value is 51e-12 so value is significant
#B(1)- beta 1 value is 9450.0, P value is  2e-16 so value is significant.
#Coefficient of Determination Value - R square Value is 0.957 (almost 96%).
#since R2 value is above 0.8, strong correlation
#R square Value tells, % of the variation in Y can be explained by X.
#Here 96% variation in salary hike can be explained with years of experience.
#final equation
#Salary Hike = 25792.2 + 9450.0 (YearsExperience)
#Model is built for the following range:"1.1 to 10.5" of Years Experience


#building SLR models using transformations

#log transformation: logarithmic model
logmodel <- lm(atdata3$Salary~log(atdata3$YearsExperience),data=atdata3)
summary(logmodel)

#B(0)-beta 0 value is  14928, p value is 0.00727 so value is significant
#B(1)- beta 1 value is 40582 , P value is 3.25e-13 so value is significant.
#Coefficient of Determination Value - R square Value is 0.8539 (almost 85%).
#since R2 value is above 0.8, strong correlation but not better than vanilla model


#exponential transformation: exponential model
expmodel <- lm(log(atdata3$Salary)~atdata3$YearsExperience,data=atdata3)
summary(expmodel)

#B(0)-beta 0 value is  10.507402, p value is <2e-16 so value is significant
#B(1)- beta 1 value is  0.125453 , P value is <2e-16 so value is significant.
#Coefficient of Determination Value - R square Value is 0.932 (almost 93%).
#since R2 value is above 0.8, strong correlation but not better than vanilla model


#Quadratic model: 2nd degree polynomial model
quadmodel <- lm(atdata3$Salary~atdata3$YearsExperience+I(atdata3$YearsExperience^2),data=atdata3)
summary(quadmodel)

#B(0)-beta 0 value is  26214.93, p value is 4.04e-06 so value is not significant
#B(1)- beta 1 value is  9259.28 , P value is 2.25e-05 so value is not significant.
##B(2)- beta 2 value is 16.39 , P value is 0.915 so value is significant.
#Coefficient of Determination Value - R square Value is 0.957 (almost 96)%.
#since R2 value is above 0.8, strong correlation and identical to vanilla model

#Polynomial model: 3rd degree polynomial model
fourthmodel <- lm(atdata3$Salary~atdata3$YearsExperience+I(atdata3$YearsExperience^2)+I(atdata3$YearsExperience^3),data=atdata3)
summary(fourthmodel)

#B(0)-beta 0 value is  38863.07, p value is 1.21e-05 so value is significant
#B(1)- beta 1 value is -718.71 , P value is 0.8843 so value is significant.
#B(2)- beta 2 value is  2099.35 , P value is 0.0395 so value is significant.
#B(3)- beta 2 value is -122.92 , P value is 0.0389 so value is significant.
#Coefficient of Determination Value - R square Value is 0.9594  (almost 96)%.
#since R2 value is above 0.8, strong correlation and slightly better than vanilla model


# R Squared Values for Various Models
# Vanilla Model : 0.957 - All Coefficients are significant
# Logarithmic Model : 0.8539 - All Coefficients are significant
# Exponential Model : 0.932 - All Coefficients are signigicant
# Quadratic Model : 0.957 - Beta 0 and Beta 1 Intercept Values are not significant, Beta 2 is Significant
# Polynomial Model (3rd Degree Model) : 0.9594  - All Coefficients are significant


# Error Residual analysis on first model: Vanilla model to check below 3 points
# 1. Residuals should be Normally Distributed.
# 2. Homoscedasticity - constant variance - This assumption means that the variance around the 
# regression line is the same for all values of the predictor variable (X).
# 3. Statistical Independence of the Errors - Residuals should not be auto correlated.

#listing residulas or Y hat (Y^) of vanilla model
model$residuals

#Sum of residuals
sum(model$residuals)
# sum of residuals is -7.844392e-12

#mean of residuals:
mean(model$residuals)
# mean of residuals is -2.615537e-13

#to calculate Root Mean square error
sqrt (sum(model$residuals^2)/nrow(atdata3))
#RMSE is 5592.044

# Checking if the Residuals are normally distributed.
shapiro.test (model$residuals)
# p-value is 0.1952 which is greater than 0.05.Can assume normality.
#Point 1 assumption is checked.


# An algorithmic approach to check for heteroscedasticity 
# For this purpose, we have NCV - (Non Constant Error Variance) Test to establish the presence or 
# absence of heteroscedasticity
# Computes a score test of the hypothesis of constant error variance against the alternative that 
# the error variance changes with 
# the level of the response (fitted values), or with a linear combination of predictors.
car::ncvTest(model)
# p-value is 0.63244. This is greater than 0.05. We accept Null Hypothesis i.e we have constant error 
# variance
# Heteroscedasticity is not present. - Assumption 2 is checked

# ConstructingACF (Auto Correlation Function) Plot
acf (model$residuals)
# If the residuals are not autocorrelated, the vertical bars will be near zero value below the dashed 
# blue line (significance level). In our case some vertical bars are going beyond the blue line.
# So there is auto correlation problem. - Assumption 3 is not checked.

##########################################################################################

# Error Residual analysis on fourth model: 3rd Degree Model (Polynomial) to check below 3 points
# 1. Residuals should be Normally Distributed.
# 2. Homoscedasticity - constant variance - This assumption means that the variance around the 
# regression line is the same for all values of the predictor variable (X).
# 3. Statistical Independence of the Errors - Residuals should not be auto correlated.

#listing residulas or Y hat (Y^) of vanilla model
fourthmodel$residuals

#Sum of residuals
sum(fourthmodel$residuals)
# sum of residuals is 2.16005e-12

#mean of residuals:
mean(fourthmodel$residuals)
# mean of residuals is 7.202757e-14

#to calculate Root Mean square error
sqrt (sum(fourthmodel$residuals^2)/nrow(atdata3))
#RMSE is 5142.642

# Checking if the Residuals are normally distributed.
shapiro.test (fourthmodel$residuals)
# p-value is 0.1163, which is greater than 0.05.Can assume normality.
#Point 1 assumption is checked.


# An algorithmic approach to check for heteroscedasticity 
# For this purpose, we have NCV - (Non Constant Error Variance) Test to establish the presence or 
# absence of heteroscedasticity
# Computes a score test of the hypothesis of constant error variance against the alternative that 
# the error variance changes with 
# the level of the response (fitted values), or with a linear combination of predictors.
car::ncvTest(fourthmodel)
# p-value is 0.53687. This is greater than 0.05. We accept Null Hypothesis i.e we have constant error 
# variance
# Heteroscedasticity is not present. - Assumption 2 is checked

# ConstructingACF (Auto Correlation Function) Plot
acf (fourthmodel$residuals)
# If the residuals are not autocorrelated, the vertical bars will be near zero value below the dashed 
# blue line (significance level). In our case some vertical bars are going beyond the blue line.
# So there is auto correlation problem. - Assumption 3 is not checked.

################################################################################################################
#RMSE value of 3rd degree model-Polynomial is 5142.642 is better than Vanilla model RMSE =5592.044

#Finalizing 3rd Degree polynomial model
#final equation
#Salary Hike = 38863.07 - 718.71 (YearsExperience)+ 2099.35 (YearsExperience^2) -122.92 (YearsExperience^3)

# Range for Confidence Interval of 95%.
confint(fourthmodel,level = 0.95)
#output
#                              2.5 %      97.5 %
#(Intercept)                   24032.9470 53693.19673
#atdata3$YearsExperience      -10774.5874  9337.17053
#I(atdata3$YearsExperience^2)    108.8691  4089.83482
#I(atdata3$YearsExperience^3)   -239.0934    -6.73744