# Business Problem
# Predict weight gained using calories consumed

# Package 'moments' is required for Skewness and Kurtosis
install.packages ("moments")
library (moments)

# Package "car" is required for Plotting QQPlot.
install.packages ("car")
library (car)

# Package "ggplot2" is required for Plotting GGPLOT and ACF Plot
install.packages ("ggplot2")
library(ggplot2)

# Load the Data Set.
wtCalData <- read.csv (file.choose ())
# The Data Set has 14 Observations (rows) with 2 Dimensions (columns)

# View the Data Set
View (wtCalData)

# Get the column names
colnames (wtCalData)
# Column 1 - "Weight.gained..grams." - 'Y' - Dependent Variable
# Column 2 - "Calories.Consumed" - 'X' - Independent Variable, Predictor Variable, Input Variable

# Get the Summary of the Data Set
##########################################################################
summary (wtCalData)
# Output
# Weight.gained..grams. Calories.Consumed
# Min.   :  62.0        Min.   :1400     
# 1st Qu.: 114.5        1st Qu.:1728     
# Median : 200.0        Median :2250     
# Mean   : 357.7        Mean   :2341     
# 3rd Qu.: 537.5        3rd Qu.:2775     
# Max.   :1100.0        Max.   :3900  

# For 'Weight.gained..grams.', there is a huge difference between Median and Mean.
# So Outliers are present for 'Weight.gained..grams.' dimension in the Data Set.
##########################################################################

# Perform Descriptive Analysis on the Dimensions
# On Independent Variable - "Calories.Consumed"
##########################################################################
# str Function displays the internal structure.
str (wtCalData$Calories.Consumed)
# The data type is 'int'.

# summary function 
summary (wtCalData$Calories.Consumed)
# On executing the summary, we get the following details
# Minimum Value - 1400
# Maximum Value - 3900
# 1st Quartile - 1728
# Median - 2250
# 3rd Quartile - 2775
# Mean - 2341
# Range is between 1400 to 3900.
# Inter Quartile Range is (2775 - 1728) = 1047

# Suspected Outlier Range on lower side -> 1st Quartile - (1.5) IQR
# 1728 - (1.5) * 1047 = 157.5. Minimum Value in the data set is 1400. So no Outliers on the lower side.

# Suspected Outlier Range on Upper Extreme -> 3rd Quartile + (1.5) IQR
# 2775 + (1.5) * 1047 = 4345.5. Maximum Value in the data set is 3900. So no Outlier on the Upper Side.

# The Data seems to be slightly skewed to the right as (Max Value - Median) > (Median - Min value).

# Get the Parameter Values for First Moment Business Decision (Measures of Central Tendency)
# Mean
mean (wtCalData$Calories.Consumed)
# Mean is 2340.714

# Median
median (wtCalData$Calories.Consumed)
# Median is 2250

# Mode
names (table(wtCalData$Calories.Consumed))[table(wtCalData$Calories.Consumed)==max(table(wtCalData$Calories.Consumed))]
# Mode is 1900

# Get the Parameter Values for Second Moment Business Decision (Measures of Dispersion)
# Variance
var (wtCalData$Calories.Consumed)
# Variance is 565668.7

# Standard Deviation
sd (wtCalData$Calories.Consumed)
# Standard Deviation is 752.1095

# Range
range (wtCalData$Calories.Consumed)
# Range is 1400 3900

# Get the Parameter Values for Third Moment Business Decision (Measure of Symmetry)
skewness (wtCalData$Calories.Consumed)
# Skewness is 0.5825597 -> Implies Slightly Right Skewed Distribution.

# Get the Parameter Values for Fourth Moment Business Decision (Measure of Peakedness)
kurtosis (wtCalData$Calories.Consumed)
# Kurtosis is 2.403367

# Let us plot the boxplot.
boxplot (wtCalData$Calories.Consumed)
# Box Plot confirms the data is slightly skewed to the right.

# Let us plot the histogram.
hist (wtCalData$Calories.Consumed)
# Histogram also confirms the data is slightly skewed to the right.

# Check if the Data is Normally Distributed.
qqnorm (wtCalData$Calories.Consumed)
qqline (wtCalData$Calories.Consumed)
# qqnorm and qqline confirms data is normal.

# Shapiro-Wilk's method is widely recommended for normality test.
# The R function shapiro.test() can be used to perform the Shapiro-Wilk test of normality 
# for one variable (univariate):
shapiro.test (wtCalData$Calories.Consumed)
# p-value is 0.4887, which is greater than 0.05.
# This implies that the distribution of the data are not significantly different from 
# normal distribution. In other words, we can assume the normality.
##########################################################################

# Let us determine the Correlation Between 'X' variable and 'Y' Variable
##########################################################################
# Linear regression requires the relationship between the independent and dependent variables 
# to be linear.

# Function - cor is used to determine the correlation coeffecient between 'X' and 'Y'.
# Function - cor (X value, Y value)
cor (wtCalData$Calories.Consumed, wtCalData$Weight.gained..grams.)
# Correlation value is 0.946991. So there is a strong correlation between 
# gained..grams. and Calories.Consumed

# Function - plot is used to plot the scatter plot between X and Y values
# Function - plot (X value, Y value)
plot (wtCalData$Calories.Consumed, wtCalData$Weight.gained..grams.)
# We see a strong positive linear correlation
##########################################################################

# Let us build a Simple Linear Regression (SLR) Model
##########################################################################
# Let us build a SLR Model using 'lm' function.
# lm (Y~X, data=<data-set>)
slrModel <- lm (wtCalData$Weight.gained..grams.~wtCalData$Calories.Consumed, data=wtCalData)

# View the Summary of the Model.
summary (slrModel)
# Intercept (Beta 0) Value = -625.7536, p-value is 0.00004, this value is significant
# Beta 1 Value = 0.42016, p-value is 0.0000002, this value is significant.
# Coefficient of Determination Value - R square Value is 0.8968 (almost 90%). 
# R square Value tells what percentage of the variation in Y can be explained by X.
# In this case 90% variation in Weight Gained can be explained by Calories Consumed.
# This is a good model.

# so the final equation is 
# SLR Formual -> Y = Beta 0 + Beta 1 * X + Epsilon
# Weight Gained = -625.7536 + 0.42016 (Calories Consumed)

# Note : The Model is built for the following range of Calories Consumed values
# 1400 to 3900. The model is not an extrapolate model.
##########################################################################

# Let us build other Simple Linear Regression (SLR) Models using transformations
##########################################################################
# Log Transformation
# Logarithmic Model
slrLogModel <-  lm (wtCalData$Weight.gained..grams.~log(wtCalData$Calories.Consumed), data=wtCalData)
summary (slrLogModel)
# Intercept (Beta 0) Value = -6955.7, p-value is 0.00002, this value is significant
# Beta 1 Value = 948.4, p-value is 0.00001, this value is significant.
# Coefficient of Determination Value - R square Value is 0.8077 (almost 80%).
# It is not better than the Vanilla Model.

# Exponential Transformation
# Exponential Model
slrExpModel <- lm (log(wtCalData$Weight.gained..grams.)~wtCalData$Calories.Consumed, data=wtCalData)
summary (slrExpModel)
# Intercept (Beta 0) Value = 2.8386724, p-value is 0.000000636, this value is significant
# Beta 1 Value = 0.0011336, p-value is 0.000000802, this value is significant.
# Coefficient of Determination Value - R square Value is 0.8776 (almost 88%).
# It is not better than the Vanilla Model.

# Quadratic Model (2nd Degree Polynomial Model)
slrSqModel <- lm (wtCalData$Weight.gained..grams.~wtCalData$Calories.Consumed+I(wtCalData$Calories.Consumed^2), data=wtCalData)
summary (slrSqModel)
# Intercept (Beta 0) Value = 2.033e+02, p-value is 0.42185, this value is not significant
# Beta 1 Value = -2.919e-01, p-value is 0.17653, this value is not significant.
# Beta 2 Value = 1.395e-04, p-value is 0.00447, this value is significant
# Coefficient of Determination Value - R square Value is 0.9521 (almost 95%).
# The Model is better than the Vanilla Model.

# Polynomial Model (3rd Degree Polynomial Model)
slrThModel <- lm (wtCalData$Weight.gained..grams.~wtCalData$Calories.Consumed+I(wtCalData$Calories.Consumed^2)+I(wtCalData$Calories.Consumed^3), data=wtCalData)
summary (slrThModel)
# Intercept (Beta 0) Value = 2.663e+03, p-value is 0.00208, this value is significant
# Beta 1 Value = -3.451e+00, p-value is 0.00173, this value is significant.
# Beta 2 Value = 1.409e-03, p-value is 0.00145, this value is significant
# Beta 3 Value = -1.608e-07, p-value is 0.00283, this value is significant
# Coefficient of Determination Value - R square Value is 0.9811 (almost 98%).
# The Model is better than the Vanilla Model and the Quadratic Model.
##########################################################################

# R Squared Values for Various Models
# Vanilla Model : 0.8968 - All Coefficients are significant
# Logarithmic Model : 0.8077 - All Coefficients are significant
# Exponential Model : 0.8776 - All Coefficients are signigicant
# Quadratic Model : 0.9521 - Beta 0 and Beta 1 Intercept Values are not significant, Beta 2 is Significant
# Polynomial Model (3rd Degree Model) : 0.9811 - All Coefficients are significant


# Let us consider the Vanilla Model and perform the Error / Residual Analysis
##########################################################################
# 1. Residuals should be Normally Distributed.
# 2. Homoscedasticity - constant variance - This assumption means that the variance around the 
# regression line is the same for all values of the predictor variable (X).
# 3. Statistical Independence of the Errors - Residuals should not be auto correlated.

# List the Residuals / Errors / Y Hat
slrModel$residuals

# Find the Sum of the Residuals / Errors / Y Hat
sum (slrModel$residuals)
# Sum of the Residuals is 6.750156e-14.

# Find the Mean of the Residuals / Errors / Y Hat
mean (slrModel$residuals)
# Mean of the Residuals is 4.822036e-15

# Let us calculate the Root Mean Square Value of Residuals
sqrt (sum(slrModel$residuals^2)/nrow(wtCalData))
# RMSE value is 103.3025

# Let us check if the Residuals are normally distributed.
shapiro.test (slrModel$residuals)
# p-value is 0.155, which is greater than 0.05.
# This implies that the distribution of the data are not significantly different from 
# normal distribution. In other words, we can assume the normality - Assumption 1 is checked.

# To plot 4 Charts in 1 Panel.
par(mfrow=c(2,2))
plot (slrModel)
# The above function displays 4 plots
# Residual Vs Fitted
# Normal QQ Plot  - Residuals are Normally Distributed - Assumption 1 is checked.
# Scale-Location Plot (Fitted (X) Vs Sqrt (Standardized Residuals))
# Residuals Vs Leverage

# The plots we are interested in are at the top-left and bottom-left. 
# The top-left is the chart of residuals vs fitted values, while in the bottom-left one, it is 
# standardised residuals on Y axis. 
# If there is absolutely no heteroscedastity, you should see a completely random, equal distribution of 
# points throughout the range of X axis and a flat red line.

# In our case in Residual Vs Fitted Plot, Residuals are random, equal distributed throughout the 
# range of X axis and flat red line. - Assumption 2 is checked.

# An algorithmic approach to check for heteroscedasticity 
# For this purpose, we have NCV - (Non Constant Error Variance) Test to establish the presence or 
# absence of heteroscedasticity
# Computes a score test of the hypothesis of constant error variance against the alternative that 
# the error variance changes with 
# the level of the response (fitted values), or with a linear combination of predictors.
car::ncvTest(slrModel)
# p-value is 0.8327. This is greater than 0.05. We accept Null Hypothesis i.e we have constant error 
# variance
# Heteroscedasticity is not present. - Assumption 2 is checked.

# Let us construct the ACF (Auto Correlation Function) Plot
acf (slrModel$residuals)
# If the residuals are not autocorrelated, the vertical bars will be near zero value below the dashed 
# blue line (significance level). In our case all the vertical bars are below the blue line.
# So there is no auto correlation problem. - Assumption 3 is checked.
##########################################################################

# Let us consider the 3rd Degree Model (Polynomial) and perform the Error / Residual Analysis
##########################################################################
# 1. Residuals should be Normally Distributed.
# 2. Homoscedasticity - constant variance - This assumption means that the variance around the 
# regression line is the same for all values of the predictor variable (X).
# 3. Statistical Independence of the Errors - Residuals should not be auto correlated.

# List the Residuals / Errors / Y Hat
slrThModel$residuals

# Find the Sum of the Residuals / Errors / Y Hat
sum (slrThModel$residuals)
# Sum of the Residuals is 7.993606e-15.

# Find the Mean of the Residuals / Errors / Y Hat
mean (slrThModel$residuals)
# Mean of the Residuals is 5.712197e-16

# Let us calculate the Root Mean Square Value of Residuals
sqrt (sum(slrThModel$residuals^2)/nrow(wtCalData))
# RMSE value is 44.15011

# Let us check if the Residuals are normally distributed.
shapiro.test (slrThModel$residuals)
# p-value is 0.5755, which is greater than 0.05.
# This implies that the distribution of the data are not significantly different from 
# normal distribution. In other words, we can assume the normality - Assumption 1 is checked.

# To plot 4 Charts in 1 Panel.
par(mfrow=c(2,2))
plot (slrThModel)
# The above function displays 4 plots
# Residual Vs Fitted
# Normal QQ Plot  - Residuals are Normally Distributed - - Assumption 1 is checked.
# Scale-Location Plot (Fitted (X) Vs Sqrt (Standardized Residuals))
# Residuals Vs Leverage

# The plots we are interested in are at the top-left and bottom-left. 
# The top-left is the chart of residuals vs fitted values, while in the bottom-left one, 
# it is standardised residuals on Y axis. 
# If there is absolutely no heteroscedastity, you should see a completely random, equal distribution 
# of points throughout the 
# range of X axis and a flat red line.

# In our case in Residual Vs Fitted Plot, Residuals are random, equal distributed throughout the 
# range of X axis and flat red line.

# An algorithmic approach to check for heteroscedasticity 
# For this purpose, we have NCV Test to establish the presence or absence of heteroscedasticity 
# Computes a score test of the hypothesis of constant error variance against the alternative 
# that the error variance changes with 
# the level of the response (fitted values), or with a linear combination of predictors.
car::ncvTest(slrThModel)
# p-value is 0.73232. This is greater than 0.05. We accept Null Hypothesis i.e we have constant error 
# variance
# Heteroscedasticity is not present - - Assumption 2 is checked.

# Let us construct the ACF (Auto Correlation Function) Plot
acf (slrThModel$residuals)
# If the residuals are not autocorrelated, the vertical bars will be near zero value below the dashed 
# blue line (significance level). In our case all the vertical bars are below the blue line.
# So there is no auto correlation problem. - Assumption 3 is checked.
##########################################################################

# RMSE Value for 3rd Degree Model (Polynomial) is 44.15011 is better than 
# RMSE Value for Vanilla Model - 103.3025.

# So finalizing the 3rd Degree Model (Polynomial)
# Final Equation
# Weight Gained = 2.663e+03 -3.451e+00 (Calories Consumed) + 1.409e-03 (Calories Consumed^2) -1.608e-07 (Calories Consumed^3)

# Range for Confidence Interval of 95%.
confint (slrThModel, level=0.95)
# Output
#                                   2.5 %         97.5 %
#  (Intercept)                      1.223057e+03  4.103715e+03
# wtCalData$Calories.Consumed      -5.267244e+00 -1.634872e+00
# I(wtCalData$Calories.Consumed^2)  6.868757e-04  2.132096e-03
# I(wtCalData$Calories.Consumed^3) -2.519688e-07 -6.958405e-08
