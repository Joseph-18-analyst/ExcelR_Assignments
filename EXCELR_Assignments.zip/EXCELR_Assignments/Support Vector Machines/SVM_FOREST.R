#Buisness Problem
#Prepare support vector machines model for classifying the area under fire for foresfires data

# Install Package - "caret" required for Partitioning / Data Slicing
install.packages ("caret")
library (caret)

install.packages("plyr")
library(plyr)

# Install Package - "kenlab" required for SVM Algorithm.
install.packages ("kernlab")
library (kernlab)

#loading dataset
forest <- read.csv(file.choose())

#viewing data set, it has 517 observations, 31 dimensions/columns
View(forest)

#dropping dummy data columns,as it is not required
forest <- forest[,-c(12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31)]

#view updated dataset
View(forest)

#histogram of area column
hist(forest$area)

# Let us get the Minimum and Maximum Values for the Area Column
min (forest$area)
# Output - 0
max (forest$area)
# Output - 1090.84

# Let us Split the Area into 5.
# 0 - 200 -> VS
# 201 - 400 -> S
# 401 - 600 -> M
# 601 - 800 -> L
# > 801 -> VL
forest$area <- as.double (forest$area)
forest$area[((forest$area > as.double (-1)) & (forest$area <= as.double(30)))] <- 15
forest$area[((forest$area > as.double (30)) & (forest$area <= as.double(60)))] <- 45
forest$area[((forest$area > as.double (60)) & (forest$area <= as.double(90)))] <- 75
forest$area[((forest$area > as.double (90)) & (forest$area < as.double(200)))] <- 150
forest$area[(forest$area > as.double (200))] <- 300

forest$area <- as.character (forest$area)
forest$area[forest$area == '15'] <- 'VS'
forest$area[forest$area == '45'] <- 'S'
forest$area[forest$area == '75'] <- 'M'
forest$area[forest$area == '150'] <- 'L'
forest$area[forest$area == '300'] <- 'VL'

forest$area <- as.factor (forest$area)

# Let us execute the 'table' function on Area Column
table (forest$area)
# L   M   S  VL  VS 
# 7   8  23   5 474 

#structure of forest
str(forest)
# 'data.frame':	517 obs. of  11 variables:
#   $ month: Factor w/ 12 levels "apr","aug","dec",..: 8 11 11 8 8 2 2 2 12 12 ...
# $ day  : Factor w/ 7 levels "fri","mon","sat",..: 1 6 3 1 4 4 2 2 6 3 ...
# $ FFMC : num  86.2 90.6 90.6 91.7 89.3 92.3 92.3 91.5 91 92.5 ...
# $ DMC  : num  26.2 35.4 43.7 33.3 51.3 ...
# $ DC   : num  94.3 669.1 686.9 77.5 102.2 ...
# $ ISI  : num  5.1 6.7 6.7 9 9.6 14.7 8.5 10.7 7 7.1 ...
# $ temp : num  8.2 18 14.6 8.3 11.4 22.2 24.1 8 13.1 22.8 ...
# $ RH   : int  51 33 33 97 99 29 27 86 63 40 ...
# $ wind : num  6.7 0.9 1.3 4 1.8 5.4 3.1 2.2 5.4 4 ...
# $ rain : num  0 0 0 0.2 0 0 0 0 0 0 ...
# $ area : num  0 0 0 0 0 0 0 0 0 0 ...

#column month and day has factor data type
#it needs to be converted using dummy variables

forest$month <-as.numeric(revalue(forest$month, c("jan"="0", "feb"="1", "mar"= "2", "apr"="3", 
                                                  "may"="4", "jun"="5", "jul"="6", "aug"="7",
                                                  "sep"="8", "oct"="9","nov"="10", "dec"= "11")))

forest$day <-as.numeric(revalue(forest$day, c("mon"="0", "tue"="1", "wed"="2", "thu"="3",
                                              "fri"="4", "sat"="5", "sun"="6")))


#view dataset
View(forest)

#structure of updated dataset
str(forest)
# 'data.frame':	517 obs. of  11 variables:
# $ month: num  8 11 11 8 8 2 2 2 12 12 ...
# $ day  : num  1 6 3 1 4 4 2 2 6 3 ...
# $ FFMC : num  86.2 90.6 90.6 91.7 89.3 92.3 92.3 91.5 91 92.5 ...
# $ DMC  : num  26.2 35.4 43.7 33.3 51.3 ...
# $ DC   : num  94.3 669.1 686.9 77.5 102.2 ...
# $ ISI  : num  5.1 6.7 6.7 9 9.6 14.7 8.5 10.7 7 7.1 ...
# $ temp : num  8.2 18 14.6 8.3 11.4 22.2 24.1 8 13.1 22.8 ...
# $ RH   : int  51 33 33 97 99 29 27 86 63 40 ...
# $ wind : num  6.7 0.9 1.3 4 1.8 5.4 3.1 2.2 5.4 4 ...
# $ rain : num  0 0 0 0.2 0 0 0 0 0 0 ...
# $ area : num  0 0 0 0 0 0 0 0 0 0 ...


#need to standardize the values, as values in all columns have different scale
#using normalizing function
normalize <- function(x){return((x-min(x))/(max(x)-min(x)))}

#applying above normalize function to standardize data in forest dataset
#using list apply function: lapply
norm_forest <- as.data.frame(lapply(forest[,1:10], FUN = normalize))

#merge area column to normalized dataset
norm_forest <- cbind(norm_forest, forest$area)

#rename last column in normalized dataset to "area"
names(norm_forest)[11] <- "area"

#view normalized dataset
View(norm_forest)

#preparing training and test dataset
#training = 75%, testing = 25%
datapartition <- createDataPartition(norm_forest$area, p=0.75, list = F)
trainingdata <- norm_forest[datapartition, ]
testingdata <- norm_forest[-datapartition, ]


#creating support vector machine model using ksvm function
#Kernel Value Set to "vanilladot". Default Kernel Parameter.
svm_forest <- ksvm(area ~ ., data = trainingdata, kernel = "vanilladot")

#evaluating model performance
#predicting it on testing dataset
area_predictions <- predict(svm_forest, testingdata)

head(area_predictions)

#construct table using actual values vs predicted values
predicttable <- table(area_predictions, testingdata$area)

predicttable
# 
# area_predictions   L   M   S  VL  VS
#               L    0   0   0   0   0
#               M    0   0   0   0   0
#               S    0   0   0   0   0
#               VL   0   0   0   0   0
#               VS   1   2   5   1 118


#accuracy of model
sum(diag(predicttable)) / sum(predicttable)
#[1] 0.9291339
#accuracy of model is 92.91%

#next build the model using different kernel factor, kernel = rbfdot (gaussian)
svm_forest1 <- ksvm(area ~ ., data = trainingdata, kernel = "rbfdot")

#evaluating model performance
#predicting it on testing dataset
area_predictions1 <- predict(svm_forest1, testingdata)

head(area_predictions1)

#construct table using actual values vs predicted values
predicttable1 <- table(area_predictions1, testingdata$area)

predicttable1
# 
# area_predictions   L   M   S  VL  VS
#               L    0   0   0   0   0
#               M    0   0   0   0   0
#               S    0   0   0   0   0
#               VL   0   0   0   0   0
#               VS   1   2   5   1 118


#accuracy of model
sum(diag(predicttable1)) / sum(predicttable1)
#[1] 0.9291339
#accuracy of model is 92.91%