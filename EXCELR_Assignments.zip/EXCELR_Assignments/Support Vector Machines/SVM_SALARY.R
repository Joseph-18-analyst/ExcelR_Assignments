#Buisness Porblem
#1) Prepare a classification model using SVM for salary data


# Install Package - "caret" required for Partitioning / Data Slicing
install.packages ("caret")
library (caret)

install.packages("plyr")
library(plyr)

# Install Package - "kenlab" required for SVM Algorithm.
install.packages ("kernlab")
library (kernlab)

#loading training data set "SalaryData_Train"
salary_training <- read.csv(file.choose())
#dataset has 30161 rows and 14 dimensions/columns

#view the dataset
View(salary_training)


#structure of dataset
str(salary_training)
# 'data.frame':	30161 obs. of  14 variables:
# $ age          : int  39 50 38 53 28 37 49 52 31 42 ...
# $ workclass    : Factor w/ 7 levels " Federal-gov",..: 6 5 3 3 3 3 3 5 3 3 ...
# $ education    : Factor w/ 16 levels " 10th"," 11th",..: 10 10 12 2 10 13 7 12 13 10 ...
# $ educationno  : int  13 13 9 7 13 14 5 9 14 13 ...
# $ maritalstatus: Factor w/ 7 levels " Divorced"," Married-AF-spouse",..: 5 3 1 3 3 3 4 3 5 3 ...
# $ occupation   : Factor w/ 14 levels " Adm-clerical",..: 1 4 6 6 10 4 8 4 10 4 ...
# $ relationship : Factor w/ 6 levels " Husband"," Not-in-family",..: 2 1 2 1 6 6 2 1 2 1 ...
# $ race         : Factor w/ 5 levels " Amer-Indian-Eskimo",..: 5 5 5 3 3 5 3 5 5 5 ...
# $ sex          : Factor w/ 2 levels " Female"," Male": 2 2 2 2 1 1 1 2 1 2 ...
# $ capitalgain  : int  2174 0 0 0 0 0 0 0 14084 5178 ...
# $ capitalloss  : int  0 0 0 0 0 0 0 0 0 0 ...
# $ hoursperweek : int  40 13 40 40 40 40 16 45 50 40 ...
# $ native       : Factor w/ 40 levels " Cambodia"," Canada",..: 38 38 38 38 5 38 22 38 38 38 ...
# $ Salary       : Factor w/ 2 levels " <=50K"," >50K": 1 1 1 1 1 1 1 2 2 2 ...

#building svm model using kernale value = vanilla dot on training dataset
svm_training <- ksvm(Salary ~ ., data = salary_training, kernel = "vanilladot")

#loading testing dataset "SalaryData_Test"
salary_test <- read.csv(file.choose())
#dataset has 15060 rows and 14 dimensions/columns

#evaluating model performance
#predicting it on testing dataset
salaryprediction <- predict(svm_training, salary_test)

head(salaryprediction)

#construct table using actual values vs predicted values
predict_table <- table(salaryprediction, salary_test$Salary)
predict_table

#getting accuracy of model
sum(diag(predict_table))/sum(predict_table)
#0.8462815, accuracy of model is 84.62%

#next build the model using different kernel factor, kernel = rbfdot (gaussian)
svm_training2 <- ksvm(Salary ~ ., data = salary_training, kernel = "rbfdot")

#evaluating model performance
#predicting it on testing dataset
salary_predictions1 <- predict(svm_training2,salary_test )

head(salary_predictions1)

#construct table using actual values vs predicted values
predicttable1 <- table(salary_predictions1, salary_test$Salary)

predicttable1

#accuracy of model
sum(diag(predicttable1)) / sum(predicttable1)
#[1] 0.8541833
#accuracy of model is 85.42%