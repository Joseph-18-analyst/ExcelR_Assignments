#buisness problem
#1) Extract reviews of any product from ecommerce website like snapdeal and amazon
#2) Perform sentimental analysis

#package to read from html
install.packages("rvest")
library(rvest)

#package required for creation of corpus
install.packages("tm")
library(tm)

#package required for world cloud
install.packages("wordcloud")
library(wordcloud)

#package required for advanced version of word cloud
install.packages("wordcloud2")
library(wordcloud2)

#package required to do n-gram analysis
install.packages("quanteda")
library(quanteda)

#package required for emotional mining
install.packages("syuzhet")
library(syuzhet)

#review of canon dslr camera 1300d model
#https://www.amazon.in/Canon-EOS-1300D-Digital-18-55mm/product-reviews/B01D4EYNUG/ref=dpx_acr_txt?showViewpoints=1

#let us extract first 20 pages reviews from above url for canon product
amazon_url <- "https://www.amazon.in/Canon-EOS-1300D-Digital-18-55mm/product-reviews/B01D4EYNUG/ref=dpx_acr_txt?showViewpoints"
amazon_review <- NULL

#extracting review from 20 pages using html_nodes and html_text
for (i in 1:20){
  murl <- read_html(as.character(paste(amazon_url, i , sep="=")))
  rev <- murl %>% html_nodes(".review-text") %>% html_text()
  amazon_review <- c(amazon_review, rev)
}

#view extracted reviews
View(amazon_review)

#extracting reviews in text form
write.table(amazon_review, "canon_1300d_review.txt")
getwd()
#[1] "C:/Users/Windows/Desktop/DATA SCIENCE/ASSIGNMENTS LMS/TEXT MINING/PRADEEP"

#creating corpus for above extracted reviews
azncan_corpus <- Corpus(VectorSource(amazon_review))

#checking if corpus is created properly
inspect(azncan_corpus[1])

#viewing 200th review
inspect(azncan_corpus[100])

#next is to cleanse the data in corpus using tm_map method
#converting review to lower case
azncan_corpus <- tm_map (azncan_corpus, tolower)
#checking data is converted to lower case
inspect(azncan_corpus[1])

#removing punctuations from reviews
azncan_corpus <- tm_map (azncan_corpus, removePunctuation)
#checking data if punctuation is removed
inspect(azncan_corpus[1])

#removing numbers from reviews
azncan_corpus <- tm_map(azncan_corpus, removeNumbers)
#checking data if numbers is removed
inspect(azncan_corpus[1])

#removing english stopwords
azncan_corpus <- tm_map(azncan_corpus, removeWords, stopwords('english'))
#checking if stopwords are removed
inspect(azncan_corpus[1])

#removing whitespaces in reviews
azncan_corpus <- tm_map(azncan_corpus, stripWhitespace)
#checking if white spaces are removed
inspect(azncan_corpus[1])

#removing common words amazon from all reviews as we are performing analysis on amazon reviews
azncan_corpus <- tm_map(azncan_corpus, removeWords, 'amazon')

#creating term document matric, to convert unstructured data to structured format
# Term Document Matrix will have the below structure
#           Review 1                  Review 2
# Term1   <frequency of Occurences>   <frequency of Occurences> .......
# Term2   <frequency of Occurences>   <frequency of Occurences> .......

tdm_amazoncanon <- TermDocumentMatrix(azncan_corpus)
#viewing tdm
# tdm_amazoncanon
# <<TermDocumentMatrix (terms: 226, documents: 400)>>
# Non-/sparse entries: 14806/75594
# Sparsity           : 84%
# Maximal term length: 1946
# Weighting          : term frequency (tf)

#performing transpose of tdm to get document term matrix
#Document Term Matrix will have the below structure
#               Term1                       Term2
# Review 1    <Frequency of Occurences>    <frequency of Occurences> .........
# Review 2    <Frequency of Occurences>    <frequency of Occurences> .........
#.

dtm_amazoncanon <- t (tdm_amazoncanon)

#converting tdm into matrix format
tdm_amazoncanon <- as.matrix(tdm_amazoncanon)

#let us get rowsums for each row in tdm
#this gives total number of times a term(word) has appeared in all reviews
rowsum_tdm <- rowSums(tdm_amazoncanon)

#printing the output of rowsums
rowsum_tdm

#next getting the terms or words which has repeated more than 25 times in all reviews
rowsum_tdm25 <- subset(rowsum_tdm, rowsum_tdm >= 25)

#printing the output of words appearing more than 25 times in reviews
rowsum_tdm25
# awesome       better       camera        canon        check         dear       decide 
# 120          596          756          239           80           40           80 
# decided      depends         dslr     expected    expensive      explore     features 
# 80          120           80           80           80           40           40 
# first          get        great         know         last        learn    learnings 
# 40           80           40           80          120          120           80 
# photographer         pics      picture        point          pro      quality    reviewing 
# 160          120          160          160          239           80           40 
# sample        shoot        skill       skills       switch         time         tool 
# 80          199           80           40           80          120          120 
# totally          use         user        using         want        years    beginners 
# 80           80           80          120          200           80           80 
# best       change        click         easy          era improvements         just 
# 160           80           40           40           40           40           40 
# mode       option        photo  photography       \U0001f60a\U0001f60a\U0001f60a\U0001f60a\U0001f60d\U0001f44d      \U0001f60d\U0001f60d\U0001f60djust         also 
# 119           40           80           80           40           40          120 
# betterbut         call       cannon      cannoni  clarityeasy        color     confused 
# 40           40           40           40           40           40           40 
# contrast decisionused      equally    excellent        final        happy         hope 
# 40           40           40           40           40           40           40 
# months        nikon       superb         took         usei         able      cameras 
# 40           80           40           40           40           80          278 
# carei      connect     customer      replace       return   workingand   apprentice 
# 40           40           40           40           80           40           40 
# beginner       bought    different         dont         good         less        modes 
# 80           80           40          159          238           80           40 
# one      playing        price  recommended        think userfriendly       \u20b9 
# 40           40           40           40           40           40           40 
# ??????       adding     aperture      average         back        bland      brought 
# 40           79           79           40           40           40           79 
# bucks          buy       buying          can      certain       colour        comes 
# 79          159          158          158           40           79          198 
# comparing   competitor     constant     criteria          day   definitely       doesnt 
# 40           40           80           79           79          158          158 
# end        entry         even        extra         fact         fill         film 
# 158           79          119          119           79           79           79 
# focus    fulfilled    generally         gets      getting        gives         goes 
# 40           79          158           79           79          119           40 
# grainy          iso         kind         lens        level        light       lights 
# 79          199          159           79          158           79           79 
# like         long         look          lot          low       manual      matches 
# 119           40           79           79          158           79           79 
# mean          mid        money          now     ordinary       paying  performance 
# 79           79           79           40          119           40           40 
# photographs        plain       points         poor       prefer      premier       pretty 
# 79           40           40           40           79           79          238 
# process   production      provide        range       really       regret       rupees 
# 79           79           79           79          198           79           40 
# satisfactory       saving          set     settings      shifted       shoots        shots 
# 79           79           79           40           40           79           79 
# since    something    specially        specs        stick      student        thats 
# 40           79           79           79           79           79           40 
# though        trash        trust          two        video       videos        wanna 
# 79           79          158           79          316           79          159 
# whole         wont        worth        wrong       always         felt          got 
# 79           79          158           79           40           40           40 
# osm          spl          bcz       become       cemera         else         flip 
# 40           40           40           40           40           40           40 
# lenses    recommend       screen    searching videographer         vlog      vloggin 
# 40           40           40           40           40           80           40 
# button   experience        month       online      product      shutter        stops 
# 40           40           40           40           40           40           40 
# suddenly         vbad          wid       worked      working         uter 
# 40           40           40           40           40           39

#creating wordcloud for words appearing more than 25 times
windows()
wordcloud(words = names(rowsum_tdm25), freq = rowsum_tdm25)

#adding colour to above wordcloud
windows()
wordcloud(words = names(rowsum_tdm25), freq = rowsum_tdm25, random.order = F, colors = rainbow(20), scale=c(3,1), rot.per = 0.3)

# Let us calculate the Term Frequencies.
# In TDM, we can calculate the row sums. This will tell us Frequency of each term in all the Reviews.
# Frequency of Each Term in all the Reviews Divided by Total Number of Reviews (Columns) will give us 
# Document Frequency (DF).

document_freq <- rowsum_tdm / ncol(tdm_amazoncanon)
document_freq

# Obtained the Positive Word List from URL -
# http://ptrckprry.com/course/ssd/data/positive-words.txt
# Created a text file using the above data - PositiveWordList.txt

# Obtained the Negative Word List from URL -
# http://ptrckprry.com/course/ssd/data/negative-words.txt
# Created a text file using the above data - NegativeWordList.txt

positive_wrdlist <- scan (file.choose(), what="character", comment.char=";")
negative_wrdlist <- scan (file.choose(), what="character", comment.char=";")

#to check positive words in reviews by matching it from positive word list
#If it Matches it is set a TRUE - positive word, else NA - not a positive word.
# Then we convert NA values to FALSE - not a positive word.
positive_match <- match(names(rowsum_tdm), c(positive_wrdlist))
positive_match = !is.na(positive_match)

#getting frequency of only positive words
freq_positiveowrds <- rowsum_tdm[positive_match]

#getting names of only positive words
names_positivematch <- names (freq_positiveowrds)

# Create a word cloud for only the Positive Words.
windows ()
wordcloud (names_positivematch, freq_positiveowrds, scale=c(4,1), colors = rainbow(20))

#to check negative words in reviews by matching it from negative word list
#If it Matches it is set a TRUE - negative word, else NA - not a negative word.
# Then we convert NA values to FALSE - not a negative word.
negative_match <- match(names(rowsum_tdm), c(negative_wrdlist))
negative_match = !is.na(negative_match)

#getting frequency of all negative words
freq_negativewords <- rowsum_tdm[negative_match]

#getting names of only negative words
names_negativematch <- names (freq_negativewords)

# Create a word cloud for only the Positive Words.
windows ()
wordcloud (names_negativematch, freq_negativewords, scale=c(4,1), colors = rainbow(20))

#let us perform n-gram analysis( mostly bi-gram) analysis
# We use the Function - dfm with value '2' for ngrams parameter.
# By varying the ngrams parameter, we can perform n-gram analysis.
# In Case of Bi-Gram Analysis, we consider adjoining 2 word terms.
#Term Document Matrix will have the below structure
#               Review 1                  Review 2
# Term1 Term2  <frequency of Occurences>   <frequency of Occurences> .......
# Term2 Term3  <frequency of Occurences>   <frequency of Occurences> .......
.
.
# DTM for a Bi-Gram
#               Term1  Term2                Term2 Term3
# Review 1    <Frequency of Occurences>    <frequency of Occurences> .........
# Review 2    <Frequency of Occurences>    <frequency of Occurences> .........

#DTM created for bigram analysis
bigram_dtmcanonreviews <- dfm (unlist (azncan_corpus), ngrams = 2, verbose = F)

#transposing DTM to get TDM of bigram
bigram_tdmcanonreviews <- t (bigram_dtmcanonreviews)

#next converting it into matrix format
bigram_tdmcanonreviews < as.matrix (bigram_tdmcanonreviews)

#getting rowsum of each row in bigram_tdmcanonreviews
#gives the frequency of these bigram terms appearing in all reviews
rowsum_bigramtdm <- rowSums(bigram_tdmcanonreviews)

#printing rowsum
rowsum_bigramtdm

#let us create subset of bigram terms which is repeating more than 10 times
rowsum_bigramtdm10 <- subset(rowsum_bigramtdm, rowsum_bigramtdm >= 10)

#printing it out
rowsum_bigramtdm10

#creating word cloud for bigram words appearing more than 10 times using function wordcloud
windows()
wordcloud(words = names (rowsum_bigramtdm10), freq = rowsum_bigramtdm10)

#applying NRC sentiment dictionary to check 8 different emotions in reviews
#and thier values in reviews
#8 different emotions anger anticipation disgust fear joy sadness surprise  trust 
nrcsent_canonreviews <- get_nrc_sentiment(amazon_review)

#displaying first 6 nrc sentiment reviews
head(nrcsent_canonreviews)
#     anger anticipation disgust fear joy sadness surprise trust negative positive
# 1     1            3       0    1   0       0        0     0        1        2
# 2     1            1       0    2   0       0        0     0        1        2
# 3     1            2       0    1   3       0        1     3        1        5
# 4     0            0       0    0   0       0        0     0        0        1
# 5     0            2       0    0   2       0        1     3        0        2
# 6     2            6       1    2   4       2        2    12        5       13

# Create a Bar plot for Various Emotion Scores for Amazon Reviews.
windows()
barplot (colSums (nrcsent_canonreviews), las = 2, col = rainbow(10), ylab = 'Count', main = 'Emotion scores')


# Create the Sentiment Vector
# get_sentiment funtion iterates over the reviews and assigns a numeric value for each review.
# This numeric value specifies the sentiment for that review.
# It uses custom sentiment dictionary to determine the value.
# Lower the value - negative sentiment.
# Higher the value - positive sentiment.
sentvect_canonreviews <- get_sentiment(amazon_review)

#sum of sentiment reviews
sum(sentvect_canonreviews)
#1022

#mean of sentiment reviews
mean(sentvect_canonreviews)
#2.555

#most negtaive reviews
negative_review <- amazon_review [which.min(sentvect_canonreviews)]
#printing it
negative_review
#[1] "The product worked only fr a month and suddenly the shutter button stops working. 
#It was a v.bad experience fr me wid amazon.. do not buy cameras online.\n    

#most positive reviews
positive_review <- amazon_review [which.max(sentvect_canonreviews)]
#printing it oit
positive_review
# [1] "I have been using this camera for a long time now.  I bought this camera back in 
# 2016 from Amazon. This has been a constant since then but then it is not the best constant
# you would wanna have that's why I shifted to cameras like 77d and a6300. You would wanna 
# change the camera after a certain point of time. Because of its poor ISO settings and also 
# picture quality is pretty average. It is plain and kind of bland. The focus points are less 
# comparing to its competitor d3400 even the ISO kind of gives you a better performance in 3400.
# The ISO goes up to 25600 where as its pretty ordinary when it comes to canon. Paying some 
# extra 6000 rupees for a better camera and a lens is definitely worth it. You won't regret 
# on buying it at the end of the day. Because you would wanna stick to what you have with the 
# satisfactory level getting fulfilled. Being a film student I generally shoot a lot of videos
# but trust me this camera is pretty trash when it comes to video and specially in low lights. 
# The colour production is very ordinary. It gets really really grainy when it comes to low 
# light shots because it doesn't provide you with a manual video mode where you can set your 
# iso aperture and all that. Though it shoots at 1080p but trust me the video does not look 
# good when brought down to premier pro. And if you generally prefer canon cameras then you 
# can go for cameras like 1500d 4000d or even 200d I mean 1500d being an entry level doesn't 
# fill up the whole criteria of better video but definitely gives you better photographs than 
# 1300d and the other two kind of matches up to the mid range camera with pretty good specs. 
# In fact better than 1500d. Don't end up buying something wrong in the process of saving money.
# Buy a better camera adding some extra bucks but that will be worth it.\n