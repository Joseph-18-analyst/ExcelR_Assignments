#Buisness problem
#Extract anything you choose from the internet and do some research on how we extract using R
#Programming and perform sentimental analysis.
#package to read from html

install.packages("rvest")
library(rvest)

#package required for creation of corpus
install.packages("tm")
library(tm)

#package required for world cloud
install.packages("wordcloud")
library(wordcloud)

#package required for advanced version of word cloud
install.packages("wordcloud2")
library(wordcloud2)

#package required to do n-gram analysis
install.packages("quanteda")
library(quanteda)

#package required for emotional mining
install.packages("syuzhet")
library(syuzhet)

#analysis of reviews of park hote-fili reviews from booking.com
#https://www.booking.com/reviews/ru/hotel/park-hotel-fili.en-gb.html?aid=357026;label=gog235jc-1DCA0owgFCD3BhcmstaG90ZWwtZmlsaUgzWANobIgBAZgBCbgBF8gBDNgBA-gBAYgCAagCA7gCpsz55QXAAgE;sid=78fb4769b558b494779d176a509b46f7;customer_type=total&hp_nav=0&keep_landing=1&order=featuredreviews&page=1&r_lang=en&rows=75&

#extracting reviews of the hotel from above mentioned URL
hotel_url <- "https://www.booking.com/reviews/ru/hotel/park-hotel-fili.en-gb.html?aid=357026;label=gog235jc-1DCA0owgFCD3BhcmstaG90ZWwtZmlsaUgzWANobIgBAZgBCbgBF8gBDNgBA-gBAYgCAagCA7gCpsz55QXAAgE;sid=78fb4769b558b494779d176a509b46f7;customer_type=total&hp_nav=0&keep_landing=1&order=featuredreviews&page=1&r_lang=en&rows=75&"
hotel_reviews <- NULL 

#extracting positive reviews
for (i in 1:20){
  murl <- read_html(as.character(paste(hotel_url, i , sep="=")))
  rev <- murl %>% html_nodes(".review_pos") %>% html_text()
  hotel_reviews <- c(hotel_reviews, rev)
}

#viewing the positive reviews
View(hotel_reviews)

#extracting negative reviews
for (i in 1:20){
  murl <- read_html(as.character(paste(hotel_url, i , sep="=")))
  rev <- murl %>% html_nodes(".review_neg") %>% html_text()
  hotel_reviews <- c(hotel_reviews, rev)
}

#viewing the combined positive and negative reviews
View(hotel_reviews)

#creating corpus of above extracted reviews
hotel_corpus <- Corpus(VectorSource(hotel_reviews))

#checking if corpus is created properly
inspect(hotel_corpus[1])
#ispecting first record

inspect(hotel_corpus[200])
#inspecting 200th record

#next is to cleanse the corpus using tm_map method

#converting reviews to lowercase
hotel_corpus <- tm_map(hotel_corpus, tolower)

#remove punctuation from reviews
hotel_corpus <- tm_map(hotel_corpus, removePunctuation)

#removing numbers from reviews
hotel_corpus <- tm_map(hotel_corpus, removeNumbers)

#removing english stop words
hotel_corpus <- tm_map(hotel_corpus, removeWords, stopwords('english'))

#remove white spaces in reviews
hotel_corpus <- tm_map(hotel_corpus, stripWhitespace)

#removing words park, fili, parhotelfili
hotel_corpus <- tm_map(hotel_corpus, removeWords, 'park')
hotel_corpus <- tm_map(hotel_corpus, removeWords, 'fili')
hotel_corpus <- tm_map(hotel_corpus, removeWords, 'parkhotelfili')

#creating term document matrix, to convert unstructured data into structured data
# Term Document Matrix will have the below structure
#           Review 1                  Review 2
# Term1   <frequency of Occurences>   <frequency of Occurences> .......
# Term2   <frequency of Occurences>   <frequency of Occurences> .......

tdm_hotel <- TermDocumentMatrix(hotel_corpus)

#viewing tdm of hotel
tdm_hotel
# Non-/sparse entries: 8280/231660
# Sparsity           : 97%
# Maximal term length: 18
# Weighting          : term frequency (tf)

#getting document term matrix by transposing term document matrix of hotel reviews
# Document Term Matrix will have the below structure
#               Term1                       Term2
# Review 1    <Frequency of Occurences>    <frequency of Occurences> .........
# Review 2    <Frequency of Occurences>    <frequency of Occurences> .........
dtm_hotel <- t (tdm_hotel)

#converting tdm_hotel reviews into matrix format
tdm_hotel <- as.matrix(tdm_hotel)

#to calculate rowsum of each term(words)
#gives number of times each term appears in all reviews
rowsum_tdm <- rowSums(tdm_hotel)

#printing it out
rowsum_tdm

#getting rowsum of words which has appeared more than 25 times in all reviews
rowsum_tdm25 <- subset(rowsum_tdm , rowsum_tdm >= 25)

#printing it out
rowsum_tdm25
# breakfast        area        away        city    distance         far    location    walkable 
# 180          80          40          60          40          80         140          40 
# cleaning     nothing       clean comfortable        good       place        room    business 
# 40          80          40          40         120          80         220          60 
# central     english      enough       hotel      modern  restaurant       rooms     russian 
# 40         120          40         280          40          60          80          40 
# speak       staff  everything        kind      really      coffee        like       small 
# 40         140          60          40          60          40          60          80 
# big       close       front       metro       quiet        walk     walking         old 
# 60          40          60         100          40          40          40         120 
# reasonable       price        said        work     morning         bed        dont        need 
# 40          60          40          60          40          60          60          40 
# problem     springs        well        wifi        poor        mins       reach      better 
# 40          40          40          80         120          40          40          60 
# much       smell    bathroom         can      center        take          's      shower 
# 40          40          60          40          40          40          40          40 
# high       sleep 
# 40          40 

#creating word cloud of words which appear more than 25 times in all reviews
windows()
wordcloud(words = names(rowsum_tdm25), freq = rowsum_tdm25)

#another variant of coloured word cloud
windows()
wordcloud(words = names(rowsum_tdm25), freq = rowsum_tdm25, random.order = F, colors = rainbow(20), scale=c(3,1), rot.per = 0.3)

# Obtained the Positive Word List from URL -
# http://ptrckprry.com/course/ssd/data/positive-words.txt
# Created a text file using the above data - PositiveWordList.txt

# Obtained the Negative Word List from URL -
# http://ptrckprry.com/course/ssd/data/negative-words.txt
# Created a text file using the above data - NegativeWordList.txt

positive_wrdlist <- scan (file.choose(), what="character", comment.char=";")
negative_wrdlist <- scan (file.choose(), what="character", comment.char=";")

#to check positive words in reviews by matching it from positive word list
#If it Matches it is set a TRUE - positive word, else NA - not a positive word.
# Then we convert NA values to FALSE - not a positive word.
positive_match <- match(names(rowsum_tdm), c(positive_wrdlist))
positive_match = !is.na(positive_match)

#getting frequency of only positive words
freq_positivewords <- rowsum_tdm[positive_match]

#getting names of only positive words
names_positivematch <- names (freq_positivewords)

# Create a word cloud for only the Positive Words.
windows ()
wordcloud (names_positivematch, freq_positivewords, scale=c(4,1), colors = rainbow(20))

#to check negative words in reviews by matching it from negative word list
#If it Matches it is set a TRUE - negative word, else NA - not a negative word.
# Then we convert NA values to FALSE - not a negative word.
negative_match <- match(names(rowsum_tdm), c(negative_wrdlist))
negative_match = !is.na(negative_match)

#getting frequency of all negative words
freq_negativewords <- rowsum_tdm[negative_match]

#getting names of only negative words
names_negativematch <- names (freq_negativewords)

# Create a word cloud for only the Positive Words.
windows ()
wordcloud (names_negativematch, freq_negativewords, scale=c(4,1), colors = rainbow(20))

#let us perform n-gram analysis( mostly bi-gram) analysis
# We use the Function - dfm with value '2' for ngrams parameter.
# By varying the ngrams parameter, we can perform n-gram analysis.
# In Case of Bi-Gram Analysis, we consider adjoining 2 word terms.
#Term Document Matrix will have the below structure
#               Review 1                  Review 2
# Term1 Term2  <frequency of Occurences>   <frequency of Occurences> .......
# Term2 Term3  <frequency of Occurences>   <frequency of Occurences> .......
.
.
# DTM for a Bi-Gram
#               Term1  Term2                Term2 Term3
# Review 1    <Frequency of Occurences>    <frequency of Occurences> .........
# Review 2    <Frequency of Occurences>    <frequency of Occurences> .........

#DTM created for bigram analysis
bigram_dtmhotelreview <- dfm (unlist (hotel_corpus), ngrams = 2, verbose = F)

#transposing above dtm to get tdm
bigram_tdmhotelreview <- t (bigram_dtmhotelreview)

#converting tdm into matrix format
bigram_tdmhotelreview <- as.matrix(bigram_tdmhotelreview)

#getting rowsums of bigrams of terms appearing in all reviews
#gives frequency or number of times bigrams appearing in all reviews
rowsum_tdmbigram <- rowSums(bigram_tdmhotelreview)

#printing it out
rowsum_tdmbigram

#next get those bigram words which ahs appeared more than 10 times in all reviews
rowsum_tdmbigram10 <- subset(rowsum_tdmbigram, rowsum_tdmbigram >= 10)

#printing it out
rowsum_tdmbigram10

#creating wordcloud of bigram words appearing more than 10 times in all reviews
windows()
wordcloud(words = names(rowsum_tdmbigram10), freq = rowsum_tdmbigram10)

#applying NRC sentiment dictionary to check 8 different emotions in reviews
#and thier values in reviews
#8 different emotions anger anticipation disgust fear joy sadness surprise  trust 
nrcsent_hotelreviews <- get_nrc_sentiment(hotel_reviews)

#displaying first 6 nrc sentiment reviews
head(nrcsent_hotelreviews)
#    anger anticipation disgust fear joy sadness surprise trust negative positive
# 1     0            0       0    0   0       0        0     0        0        1
# 2     0            3       0    0   3       0        1     2        0        4
# 3     0            0       0    0   2       0        0     2        0        3
# 4     0            0       0    0   0       0        0     0        0        0
# 5     0            1       0    1   2       1        2     2        1        2
# 6     0            0       1    0   1       0        0     4        1        2

# Create a Bar plot for Various Emotion Scores for Amazon Reviews.
windows()
barplot (colSums (nrcsent_hotelreviews), las = 2, col = rainbow(10), ylab = 'Count', main = 'Emotion scores')

# Create the Sentiment Vector
# get_sentiment funtion iterates over the reviews and assigns a numeric value for each review.
# This numeric value specifies the sentiment for that review.
# It uses custom sentiment dictionary to determine the value.
# Lower the value - negative sentiment.
# Higher the value - positive sentiment.
sentvect_hotelreviews <- get_sentiment(hotel_reviews)

#sum of sentiment reviews
sum(sentvect_hotelreviews)
#464

#mean of sentiment reviews
mean(sentvect_hotelreviews)
#0.5395349

#most negtaive reviews
negative_review <- hotel_reviews [which.min(sentvect_imdbreviews)]
#printing it
negative_review
# "Bad wifi.\nStaff dont speak English nor can fix the wifi problem.\nBusy road front side.\nPoor breakfast.
# \nRoom outdated, nasty smell in shower."

#most positive reviews
positive_review <- hotel_reviews [which.max(sentvect_hotelreviews)]
#printing it
positive_review
# [1] "The location is excellent. Located in a leafy area and scenic garden not far from Moscow
# River. Very peaceful surrounding and away from the bustles of city. Nicely connected through 
# Public Transport network. The mega electronics market is at a walkable distance."