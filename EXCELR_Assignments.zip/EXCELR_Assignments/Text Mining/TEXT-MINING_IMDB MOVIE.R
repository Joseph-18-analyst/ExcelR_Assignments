# BUISNESS PROBLEM
#1) Extract movie reviews for any movie from IMDB and perform sentimental analysis

#package to read from html
install.packages("rvest")
library(rvest)

#package required for creation of corpus
install.packages("tm")
library(tm)

#package required for world cloud
install.packages("wordcloud")
library(wordcloud)

#package required for advanced version of word cloud
install.packages("wordcloud2")
library(wordcloud2)

#package required to do n-gram analysis
install.packages("quanteda")
library(quanteda)

#package required for emotional mining
install.packages("syuzhet")
library(syuzhet)


#review of english movie Dark Knight
#https://www.imdb.com/title/tt0468569/reviews?ref_=tt_ql_3

#first step: extracting user reviews from imdb website for dark knight
imdburl <- "https://www.imdb.com/title/tt0468569/reviews?ref_=tt_ql_3"
charURL <- read_html (as.character(imdburl))
imdb_review <- charURL %>%
  html_nodes (".show-more__control") %>%
  html_text() 

View(imdb_review)

#creating corpus 

imdb_corpus <- Corpus(VectorSource(imdb_review))

#checking if corpus is created properly
inspect(imdb_corpus[1])

#next cleansing the corpus data using tm_map function

#converting all text in review to lower case
imdb_corpus <- tm_map(imdb_corpus, tolower)

#to check text is converted to lowercase
inspect(imdb_corpus[1])

#removing punctuation from all reviews
imdb_corpus <- tm_map(imdb_corpus, removePunctuation)

#checking if punctuation is removed
inspect(imdb_corpus[1])

#REMOVING NUMBERS FROM all reviews
imdb_corpus <- tm_map(imdb_corpus, removeNumbers)

#checking if numbers are removed
inspect(imdb_corpus[1])

#removing english stop words from reviews
imdb_corpus <- tm_map(imdb_corpus, removeWords, stopwords('english'))

#checking if stopwords are removed
inspect(imdb_corpus[1])

#removing whitespaces in review text
imdb_corpus <- tm_map(imdb_corpus, stripWhitespace)

#to check if white spaces are removed
inspect(imdb_corpus[1])

#next removing common word imdb from all reviews
imdb_corpus <- tm_map(imdb_corpus, removeWords, 'imdb')

#next creating term document matrix to convert unstructured data to structured data
# Term Document Matrix will have the below structure
#           Review 1                  Review 2
# Term1   <frequency of Occurences>   <frequency of Occurences> .......
# Term2   <frequency of Occurences>   <frequency of Occurences> .......

tdmimdb_corpus <- TermDocumentMatrix(imdb_corpus)

#view the tdm
tdmimdb_corpus
# <<TermDocumentMatrix (terms: 2042, documents: 49)>>
#   Non-/sparse entries: 4174/95884
# Sparsity           : 96%
# Maximal term length: 24
# Weighting          : term frequency (tf)

# Let us Transpose the Term Document Matrix to get Document Term Matrix
# Document Term Matrix will have the below structure
#               Term1                       Term2
# Review 1    <Frequency of Occurences>    <frequency of Occurences> .........
# Review 2    <Frequency of Occurences>    <frequency of Occurences> .........

dtmimdb_corpus <- t (tdmimdb_corpus)

#converting reviews to matrix format
tdmimdb_corpus <- as.matrix(tdmimdb_corpus)

#getting rowsums of each row, it gives number of time terms have been repeated in all reviews
rowsum_tdm <- rowSums(tdmimdb_corpus)

#printing rowsum of each row i.e frequency of each terms in all reviews
rowsum_tdm

#getting terms which have been repeated more than 10 times in all reviews
rowsum_tdm10 <- subset(rowsum_tdm, rowsum_tdm >= 10)

#printing words appearing more than 10 times in all reviews
rowsum_tdm10
# acting      action        also      batman         can   character        dark        even 
# 11          36          20         100          20          23          59          19 
# far        film     finally       great       heath       joker        just      knight 
# 14          68          10          23          42          78          28          48 
# ledger     ledgers        like       makes       movie        much       nolan         one 
# 35          15          21          14         110          25          21          51 
# perfect performance         see        seen       thats        time     villain        well 
# 12          31          20          16          17          28          14          24 
# aaron     batmans      begins        best        cant christopher        city        come 
# 10          14          18          36          10          15          14          12 
# comic        dent        dont     eckhart        face        feel         get       going 
# 14          13          18          14          12          16          11          12 
# good      gotham      harvey         hes        long        love        made        mind 
# 23          19          16          15          12          10          22          10 
# movies         new         now      people        real      really         say       still 
# 16          14          21          10          11          17          18          13 
# story       think      though         two         way       wayne        away      better 
# 13          12          13          12          12          10          11          15 
# ever        bale   christian   superhero       films        plot       quite       bruce 
# 19          19          14          13          15          12          13          12 
# every        many         big 
# 15          16          10 

#creating wordcloud for words appearing more than 10 times in all reviews
windows()
wordcloud(words = names(rowsum_tdm10), freq = rowsum_tdm10)

#applying colurs to words in wordcloud
windows()
wordcloud(words = names(rowsum_tdm10), freq = rowsum_tdm10, random.order = F, colors = rainbow(20), scale=c(3,1), rot.per = 0.3)

# Obtained the Positive Word List from URL -
# http://ptrckprry.com/course/ssd/data/positive-words.txt
# Created a text file using the above data - PositiveWordList.txt

# Obtained the Negative Word List from URL -
# http://ptrckprry.com/course/ssd/data/negative-words.txt
# Created a text file using the above data - NegativeWordList.txt

positive_wrdlist <- scan (file.choose(), what="character", comment.char=";")
negative_wrdlist <- scan (file.choose(), what="character", comment.char=";")

#to check positive words in reviews by matching it from positive word list
#If it Matches it is set a TRUE - positive word, else NA - not a positive word.
# Then we convert NA values to FALSE - not a positive word.
positive_match <- match(names(rowsum_tdm), c(positive_wrdlist))
positive_match = !is.na(positive_match)

#getting frequency of only positive words
freq_positiveowrds <- rowsum_tdm[positive_match]

#getting names of only positive words
names_positivematch <- names (freq_positiveowrds)

# Create a word cloud for only the Positive Words.
windows ()
wordcloud (names_positivematch, freq_positiveowrds, scale=c(4,1), colors = rainbow(20))

#to check negative words in reviews by matching it from negative word list
#If it Matches it is set a TRUE - negative word, else NA - not a negative word.
# Then we convert NA values to FALSE - not a negative word.
negative_match <- match(names(rowsum_tdm), c(negative_wrdlist))
negative_match = !is.na(negative_match)

#getting frequency of all negative words
freq_negativewords <- rowsum_tdm[negative_match]

#getting names of only negative words
names_negativematch <- names (freq_negativewords)

# Create a word cloud for only the Positive Words.
windows ()
wordcloud (names_negativematch, freq_negativewords, scale=c(4,1), colors = rainbow(20))

#let us perform n-gram analysis( mostly bi-gram) analysis
# We use the Function - dfm with value '2' for ngrams parameter.
# By varying the ngrams parameter, we can perform n-gram analysis.
# In Case of Bi-Gram Analysis, we consider adjoining 2 word terms.
#Term Document Matrix will have the below structure
#               Review 1                  Review 2
# Term1 Term2  <frequency of Occurences>   <frequency of Occurences> .......
# Term2 Term3  <frequency of Occurences>   <frequency of Occurences> .......
.
.
# DTM for a Bi-Gram
#               Term1  Term2                Term2 Term3
# Review 1    <Frequency of Occurences>    <frequency of Occurences> .........
# Review 2    <Frequency of Occurences>    <frequency of Occurences> .........

#DTM created for bigram analysis

bigram_dtmimdbreview <- dfm (unlist (imdb_corpus), ngrams = 2, verbose = F)

#transposing DTM to get TDM of bigram
bigram_dtmimdbreview <- t (bigram_dtmimdbreview)

#next converting it into matrix format
bigram_dtmimdbreview < as.matrix (bigram_dtmimdbreview)

#getting rowsum of each row in bigram_tdmcanonreviews
#gives the frequency of these bigram terms appearing in all reviews
rowsum_bigramtdm <- rowSums(bigram_dtmimdbreview)

#printing rowsum
rowsum_bigramtdm

#let us create subset of bigram terms which is repeating more than 10 times
rowsum_bigramtdm10 <- subset(rowsum_bigramtdm, rowsum_bigramtdm >= 10)

#printing it out
rowsum_bigramtdm10

#creating word cloud for bigram words appearing more than 10 times using function wordcloud
windows()
wordcloud(words = names (rowsum_bigramtdm10), freq = rowsum_bigramtdm10)

#applying NRC sentiment dictionary to check 8 different emotions in reviews
#and thier values in reviews
#8 different emotions anger anticipation disgust fear joy sadness surprise  trust 
nrcsent_imdbreviews <- get_nrc_sentiment(imdb_review)

#displaying first 6 nrc sentiment reviews
head(nrcsent_imdbreviews)
#   anger anticipation disgust fear joy sadness surprise trust negative positive
# 1     4            9       1    6   8       3        4     9        8       17
# 2     0            0       0    0   0       0        0     0        0        0
# 3     0            0       0    0   0       0        0     0        0        0
# 4    14           16       9   17  16      14       10    16       20       28
# 5     1            6       1    1   1       1        0     1        3        3
# 6     0            0       0    0   0       0        0     0        0        0

# Create a Bar plot for Various Emotion Scores for Amazon Reviews.
windows()
barplot (colSums (nrcsent_imdbreviews), las = 2, col = rainbow(10), ylab = 'Count', main = 'Emotion scores')

# Create the Sentiment Vector
# get_sentiment funtion iterates over the reviews and assigns a numeric value for each review.
# This numeric value specifies the sentiment for that review.
# It uses custom sentiment dictionary to determine the value.
# Lower the value - negative sentiment.
# Higher the value - positive sentiment.
sentvect_imdbreviews <- get_sentiment(imdb_review)

#sum of sentiment reviews
sum(sentvect_imdbreviews)
#179.85

#mean of sentiment reviews
mean(sentvect_imdbreviews)
#3.6704

#most negtaive reviews
negative_review <- imdb_review [which.min(sentvect_imdbreviews)]
#printing it
negative_review
# [1] "The Dark Knight maintained the intensity and overall gunmetal grayish feel that sets 
# this Batman apart. The film takes us to a Gotham City that has grown accustomed to the big 
# bat's crime-fighting crusades, and the last remaining big time criminals have actually grown
# fearful of his wrath. They form an alliance to attempt to keep their illicit business 
# activities alive but are feeling even more pressure from yet a different angle: the 
# passionate and fearless new district attorney, Harvey Dent. Recognizing the crime group's 
# looming extinction, a stranger enters their circle and offers what he thinks is the only 
# solution: kill Batman.The bad guys don't know if they can trust this seemingly demented 
# madman, and they later learn the hard way that they don't really have a choice, for the 
# most disturbing part of the Joker's personality is his motive. He doesn't care about money 
# or power. He just enjoys causing trouble and watching, with pleasure, from the sidelines, 
# as the terrorized city scrambles in mayhem...which leads me to the real star of this film, 
# Heath Ledger.Ledger's performance as the Joker is astounding and consuming. We come face-to-
# face with a villain bearing the coldness of a psychopath and a personality that remains as 
# mysterious and inexplicable as the real reason for the scars on his face. He develops the 
# air of the lone offender quite early on as he nonchalantly kills those who help him commit 
# his crimes. Yet, he has no problem building an army of followers, and the viewers easily 
# find that believable. As insane as he is, he's focused and quite determined. Ledger also 
# brings the Joker's humor to the role, but he does it in a way that is unique to this 
# interpretation...with subtlety and honesty. The very words and mannerisms that made me laugh
# also evoked feelings of sadness in its clarity. The evil is incredibly convincing.Although
# Batman is a character that is often marketed towards kids, this film is definitely not 
# appropriate for young children. In addition to the dark images, the violence, both seen and 
# implied, is sometimes unsettling, and Ledger's Joker is chilling even for adult viewers. 
# Having said that, this is, by far, one of the best films I've ever seen, and it will easily 
# find a place in my personal top ten. I am only disappointed that this Joker, the best villain 
# in a film since Hannibal Lecter, will never be revealed to us again."

#most negtaive reviews
positive_review <- imdb_review [which.max(sentvect_imdbreviews)]
#printing it
positive_review
