#BUISNESS PROBLEM
# 1) Extract tweets for any user (try choosing a user who has more tweets)
# 2) Perform sentimental analysis on the tweets extracted from the above

#to extract news from twitter website
install.packages("twitteR")
library(twitteR)

# This Package is required for Performing Twitter Account Authorization.
# R Interface for OAuth.
install.packages("ROAuth")
library(ROAuth)

# This Package is required for Base 64 encoding
install.packages ("base64enc")
library (base64enc)

# This Packages provides low-level socket and protocol support for handling HTTP and WebSocket 
# requests directly from within R. 
install.packages ("httpuv")
library (httpuv)

#package required for creation of corpus
install.packages("tm")
library(tm)

#package is created for creating word cloud
install.packages("wordcloud")
library(wordcloud)

#this package required for emotional mining
install.packages("syuzhet")
library(syuzhet)

#package is required for LDA
install.packages("topicmodels")
library(topicmodels)

#setting up user credentials
#consumer key and consumer secret is obtained by logging into twitter site: https://developer.twitter.com/
# above mentioned 2 keys are obtained from keys and tokens in twitter developer page
usercred <- OAuthFactory$new(consumerKey='28wWnJfa4mIQdlzA4kkaHYV22', # Consumer Key (API Key)
                             consumerSecret='xFwvmnrDLn7qwt9BbtsiApUzvc7Zc7A8ZQFIc29H8eL65Lw2mt', #Consumer Secret (API Secret)
                             requestURL='https://api.twitter.com/oauth/request_token',
                             accessURL='https://api.twitter.com/oauth/access_token',
                             authURL='https://api.twitter.com/oauth/authorize')

#save the user crdentials
save (usercred, file = "twitter authentication.Rdata")
getwd()

#load the user credentials
load("twitter authentication.Rdata")

#setup twitter O authentication, means setup authentication between R and twitter
setup_twitter_oauth("28wWnJfa4mIQdlzA4kkaHYV22", # Consumer Key (API Key)
                    "xFwvmnrDLn7qwt9BbtsiApUzvc7Zc7A8ZQFIc29H8eL65Lw2mt", #Consumer Secret (API Secret)
                    "725777593-3wmnhjZVuLYYGi7wEyajjNqAG0xYjEn4Pgv8EPR3", #access token from twitter
                    "B0dAlXunhurqSo6Hx0WMi8WJ7x44xuFipNHn4yFSi6y5g") #access token secret from twitter

# Extract 1000 Tweets of tendulkar. The tweets are extracted as List.
tweets <- userTimeline('sachin_rt', n = 1000, includeRts = T)

#converting tweets to dataframe
tweets_df <- twListToDF(tweets)

View(tweets_df)

#writing tweets to csv file
write.csv(tweets_df, "sachin_tweets.csv")

getwd()

#printing first 6 tweets from tweets_df
head(tweets_df$text)

# [1] "Me and @BrianLara, hitting the pitch with budding cricketers! #SelectionDay\n\n@NetflixIndia https://t.co/Rw2KRl2xOH"                            
# [2] "Appreciate the decision taken by @Uni_Mumbai to allow the students who are involved in sporting tournaments to appe. https://t.co/c6aKPiX3FS"    
# [3] "Kids had a lot of fun at the @Tendulkarmga camps in November last year. Our endeavour is to provide the best coachi. https://t.co/KbYXI3deoy"    
# [4] "Tonight's going to be a cracker of a game! Who's your pick? \n#MIvRCB https://t.co/bkQyujcmrF"                                                   
# [5] "Wishing everyone a Happy Baisakhi, Vishu, Poila Boisakh &amp; Rongali Bihu. May the harvest season bring new energy, ho. https://t.co/LFNPW3Z4Iu"
# [6] "It's always fun to catch up with @BrianLara and discuss cricket, golf and more! https://t.co/0MU5YeeuYu" 

#creating a corpus and DTM/TDM of tweets
tweetcorpus <- Corpus(VectorSource(tweets_df$text))

#checking if corpus is created properly
#checking 1st tweet
inspect(tweetcorpus[1])

#inspect 300th tweet
inspect(tweetcorpus[300])

#cleansing the data in corpus using tm_map
#converting tweets to lowercase
tweetcorpus <- tm_map(tweetcorpus, tolower)

#removing punctuations from tweets
tweetcorpus <- tm_map(tweetcorpus, removePunctuation)

#removing numbers from tweets
tweetcorpus <- tm_map(tweetcorpus, removeNumbers)

#removing english stopwords
tweetcorpus <- tm_map(tweetcorpus, removeWords, stopwords('english'))

#rmoving whitespaces
tweetcorpus <- tm_map(tweetcorpus, stripWhitespace)

#create term document matrix
#converting unstructured data to structed form in TDM
#           Tweet 1                  TWeet 2
# Term1   <frequency of Occurences>   <frequency of Occurences> .......
# Term2   <frequency of Occurences>   <frequency of Occurences> .......

tdm_tweets <- TermDocumentMatrix(tweetcorpus)

tdm_tweets
# <<TermDocumentMatrix (terms: 4658, documents: 1000)>>
# Non-/sparse entries: 11478/4646522
# Sparsity           : 100%
# Maximal term length: 2400
# Weighting          : term frequency (tf)

#transposing term document matrix into document term matrix
# Document Term Matrix will have the below structure
#               Term1                       Term2
# Tweet 1    <Frequency of Occurences>    <frequency of Occurences> .........
# Tweet 2    <Frequency of Occurences>    <frequency of Occurences> .........
#.

dtm_tweets <- t(tdm_tweets)

#converting tdm_tweets to matrix format
tdm_tweets <- as.matrix(tdm_tweets)

tdm_tweets[1:10, 1:20]

#getting rowsum of each row in matrix tdm_tweets
#this gives frequency of each term in all tweets
rowsum_tdm <- rowSums(tdm_tweets)

#printing row sums of each rows, frequency of each term(row) in all tweets
rowsum_tdm


#getting the terms(rows) which has repeated more than 50 times
rowsum_tdm50 <- subset(rowsum_tdm, rowsum_tdm >= 50)

#printing the output
rowsum_tdm50
# best            year             amp           happy         wishing          always 
# 73              54              97             158              76              77 
# .           birthday            good           great             day            well 
# 161             131              62             110              56              54 
# thank congratulations             one           india            keep 
# 63              76              73              72              73 

#creating wordcloud for the words which appears more than 50 times
#function used is wordcloud
windows()
wordcloud(words = names(rowsum_tdm50), freq = rowsum_tdm50)

# Apply the NRC sentiment dictionary to calculate the presence of eight different emotions
# and their corresponding Valence in the Tweets 
# Eight Emotions are - anger anticipation disgust fear joy sadness surprise  trust
nrcsent_tweets <- get_nrc_sentiment(tweets_df$text)

#displaying first 6 nrcsentiment tweets
head(nrcsent_tweets)
#   anger anticipation disgust fear joy sadness surprise trust negative positive
# 1     0            0       0    0   0       0        0     0        0        0
# 2     0            0       0    0   0       0        0     0        0        0
# 3     0            1       0    0   1       0        0     1        0        2
# 4     0            0       0    0   0       0        0     0        0        1
# 5     0            2       0    0   2       0        0     1        0        2
# 6     0            1       0    0   1       0        1     0        0        1

#creating barplot nrcsent_tweets
windows()
barplot (colSums (nrcsent_tweets), las = 2, col = rainbow(10), ylab = 'Count', main = 'Emotion scores')

# Create the Sentiment Vector
# get_sentiment funtion iterates over the tweets and assigns a numeric value for each tweet.
# This numeric value specifies the sentiment for that Tweet.
# It uses custom sentiment dictionary to determine the value.
# Lower the value - negative sentiment.
# Higher the value - positive sentiment.
sentvec_tweets <- get_sentiment(tweets_df$text)

sum(sentvec_tweets)
#1589.2

mean(sentvec_tweets)
#1.5892
#getting most neagtive tweet
neg_tweet <- tweets_df$text [which.min(sentvec_tweets)]

#output
neg_tweet
#[1] "Deeply disturbed by the terror attack on #AmarnathYatra pilgrims. 
#Thoughts and prayers go out to all the victims and their families."

#getting positive tweet
pos_tweet <- tweets_df$text [which.max(sentvec_tweets)]

#ouput
pos_tweet
# [1] "Wishing #JayaBachchan ji a very happy birthday. Have a great year ahead. 
# Thanks for all the good wishes over the ye. https://t.co/PgyhAXSyX3"

#performing topic extraction using LDA. extracting 10 topics
lda_tweets <- LDA(dtm_tweets, 10)

#looking at 5 terms in each of 10 topics
term_tweets <- terms(lda_tweets, 5)

term_tweets


